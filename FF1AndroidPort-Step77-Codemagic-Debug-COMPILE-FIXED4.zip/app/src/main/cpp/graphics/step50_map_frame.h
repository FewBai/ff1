#pragma once
#include "chunk_tile_batch_builder.h"
#include "entity_interpolator.h"
#include "frame_time_telemetry.h"
#include "tile_map_render_loop.h"

namespace ff1 {

struct Step50FrameResult {
    TileMapFrameStats render;
    InterpolatedPosition player;
    FrameTimeTelemetry telemetry;
};

class Step50MapFrame {
public:
    explicit Step50MapFrame(ChunkTileLayout layout)
        : builder_(layout) {}

    void updatePlayer(float targetX, float targetY,
                      float deltaSeconds,
                      float moveSpeed);

    Step50FrameResult render(
        const MapChunkManager& chunks,
        const ChunkBounds& visible,
        TileMapRenderLoop& loop,
        const RenderPass& entities,
        const std::function<bool(int)>& bitmapReady,
        const std::function<void(const CanvasDrawCommand&)>& draw,
        size_t maxMapCommands,
        size_t maxEntityCommands,
        double frameMilliseconds);

    InterpolatedPosition player() const {
        return player_.current();
    }

private:
    ChunkTileBatchBuilder builder_;
    TileBatchRenderer mapTiles_;
    EntityInterpolator player_;
    FrameTimeTelemetry telemetry_;
};

} // namespace ff1
