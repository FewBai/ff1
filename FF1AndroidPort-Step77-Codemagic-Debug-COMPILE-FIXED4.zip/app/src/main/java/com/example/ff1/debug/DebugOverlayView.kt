package com.example.ff1.debug

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View

data class DebugOverlaySnapshot(
    val fps: Double = 0.0,
    val frameMs: Double = 0.0,
    val avgFrameMs: Double = 0.0,
    val worstFrameMs: Double = 0.0,
    val drawCalls: Int = 0,
    val cacheHits: Int = 0,
    val cacheMisses: Int = 0,
    val missingTileIds: Int = 0,
    val visibleTiles: Int = 0,
    val submittedTiles: Int = 0,
    val cacheBytes: Long = 0,
    val atlasBytes: Long = 0,
    val overBudget: Boolean = false
)

class DebugOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textSize = 28f
    }
    @Volatile private var snapshot = DebugOverlaySnapshot()
    @Volatile private var debugEnabled: Boolean = true

    fun update(value: DebugOverlaySnapshot) {
        snapshot = value
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!debugEnabled) return
        val s = snapshot
        val lines = arrayOf(
            "FF1 DEBUG",
            "FPS %.1f  Frame %.1f ms".format(s.fps, s.frameMs),
            "Avg %.1f ms  Worst %.1f ms".format(s.avgFrameMs, s.worstFrameMs),
            "Draw %d  Cache H %d  M %d".format(s.drawCalls, s.cacheHits, s.cacheMisses),
            "Tiles %d/%d  Missing %d".format(s.visibleTiles, s.submittedTiles, s.missingTileIds),
            "Cache %.1f MB  Atlas %.1f MB".format(s.cacheBytes / 1048576.0, s.atlasBytes / 1048576.0),
            if (s.overBudget) "FRAME > 16.67 ms" else "Frame budget OK"
        )
        var y = 36f
        for (line in lines) {
            canvas.drawText(line, 18f, y, paint)
            y += 32f
        }
    }
}
