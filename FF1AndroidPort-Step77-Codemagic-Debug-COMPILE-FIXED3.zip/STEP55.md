# Step 55 — Live Android Debug Overlay Bridge

The overlay is now prepared for per-frame live telemetry.

Native:
Renderer counters
→ DebugOverlayBridge
→ DebugOverlayController
→ snapshot

Android:
snapshot
→ DebugOverlayBridge.kt
→ DebugOverlayView

Added:
- per-frame draw/cache/missing-tile counters
- frame budget warning at >16.67 ms
- cache memory bytes
- atlas memory bytes
- Android display of memory counters
- thread-safe Kotlin snapshot storage

Native regression:
STEP55_LIVE_OVERLAY_TEST_OK

Next Step 56:
- wire the actual BitmapCache and TextureAtlas byte counters
- expose native snapshot through JNI into the real Android render loop
- add a runtime debug toggle
