# Step 41 — Texture Atlas / Bitmap Cache / Bounded Resource Loading

Added:
- TextureAtlas region metadata
- byte-budgeted LRU ResourceCache
- bounded AsyncResourceQueue
- native regression test
- CMake integration

Asset-neutral: no commercial FF1 graphics are included.

Native test: STEP41_RESOURCE_CACHE_TEST_OK
