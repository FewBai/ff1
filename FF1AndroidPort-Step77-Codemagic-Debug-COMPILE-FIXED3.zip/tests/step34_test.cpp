#include "gameplay/story_events.h"
#include <cassert>
using namespace ff1;
int main(){
 StoryState s; s.gil=10;
 StoryEventRunner r; r.start({
  {StoryOp::Say,"Hello","",0},
  {StoryOp::SetFlag,"","met_guard",1},
  {StoryOp::GiveGil,"","",25},
  {StoryOp::GiveItem,"","",3},
  {StoryOp::End,"","",0}});
 assert(r.advance(s) && r.waitingForText() && r.text()=="Hello");
 assert(r.advance(s)); assert(s.flags["met_guard"]);
 assert(s.gil==35 && s.items[3]==1); assert(r.finished()); return 0;
}
