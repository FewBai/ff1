#!/usr/bin/env bash
set -euo pipefail
GRADLE_VERSION="${GRADLE_VERSION:-8.13}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if command -v gradle >/dev/null 2>&1; then
  exec gradle --no-daemon assembleDebug "$@"
fi
echo "Gradle is not installed. Codemagic uses ci/codemagic.yaml to download Gradle ${GRADLE_VERSION}."
exit 2
