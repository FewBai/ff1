# Step 15 — Data-Driven World + Four-Character Battle Commands

Added:

- data-driven map/NPC/chest model
- clean-room text data adapter
- four-character battle command slots
- per-character target selection
- ATTACK / ITEM / MAGIC / RUN command enum
- GameEngine battle command API
- JNI/Kotlin battle command API
- CMake integration

The data adapter deliberately uses a small neutral text format rather than
shipping or copying commercial game assets. Authorized decoded data can be
fed into the adapter later.

Example:

    MAP 1 64 64
    OBJ 1 1 10 12 1 100 GUARD
    CHEST 1 1 14 12 3 1 100

Next:
- connect commands to actual battle actors and turn resolution
- load real authorized map/NPC data
- render dialogue and menus from data
- persist full party/equipment state in all save slots
- Android UI target selection and four-character command panels
