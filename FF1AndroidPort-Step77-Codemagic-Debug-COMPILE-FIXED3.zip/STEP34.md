# Step 34 — NPC Dialogue & Story Event System

Added a data-driven story event runner for Android RPG scenes:
- multi-page NPC dialogue
- story flags
- conditional events
- Gil rewards
- item rewards
- event completion state
- UI-neutral event runner suitable for Android dialogue overlays

The implementation uses original placeholder text/data and does not include copyrighted FF1 script or ROM assets.
