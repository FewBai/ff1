# Step 56 — Native Debug Snapshot → Android JNI

The debug overlay now has a concrete native C ABI suitable for JNI binding.

Live path:

Renderer
→ DebugOverlayBridge
→ native snapshot
→ JNI/Kotlin
→ DebugOverlayView

Added:
- native debug API
- native cache/atlas byte counters
- Kotlin JNI bridge
- runtime enable/disable
- F2 toggle
- double-tap toggle hook
- native regression covering all exported metrics

The memory counters are supplied by the real cache/atlas owners in the next
integration step rather than guessed from UI state.

Native regression:
STEP56_NATIVE_JNI_BRIDGE_TEST_OK

Next Step 57:
- bind the actual BitmapCache byte usage
- bind actual TextureAtlas byte usage/region count
- call the native debug begin/end hooks from the real Android frame loop
- remove remaining placeholder metric sources
