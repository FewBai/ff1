# Step 65 — Chunk Preload Radius

Added a preload layer separate from rendering.

Camera viewport is expanded by a configurable preload radius. Chunks inside
the expanded area are scheduled for bitmap loading, but preloading does not
call Canvas.drawBitmap and therefore does not affect Draw Calls.

Pipeline:
Camera → expanded preload viewport → ChunkPreloader → Bitmap load request
→ BitmapCache ready → later visible render lookup.

Regression:
STEP65_CHUNK_PRELOAD_TEST_OK

Next Step 66:
- add a bounded background preload queue
- deduplicate requests
- connect queue completion to BitmapCache
- avoid scheduling work already resident in cache
