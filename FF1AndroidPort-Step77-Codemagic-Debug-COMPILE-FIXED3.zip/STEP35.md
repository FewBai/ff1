# Step 35 — Android Story / Dialogue Integration

Added:
- Android dialogue overlay
- NPC interaction now surfaces native NPC/story text
- Tap-to-continue dialogue dismissal
- Native `npcMessage()` JNI bridge exposed to Kotlin
- Keeps event/story execution in the C++ core while Android only renders/advances UI

The existing StoryEventRunner remains UI-neutral and can be extended with choices and conditional branches without moving game rules into Android.

Validation: source-level integration and JNI symbol consistency checked; Android NDK build was not claimed in this environment.
