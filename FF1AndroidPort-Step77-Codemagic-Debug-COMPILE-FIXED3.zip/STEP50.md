# Step 50 — Real MapChunkManager → TileBatch + Player Interpolation + Frame Telemetry

This stage connects actual MapChunkManager chunk interest to the map tile batch.

Pipeline:

MapChunkManager
→ active chunk selection
→ ChunkTileBatchBuilder
→ visible TileBatchRenderer
→ BitmapCache readiness
→ Texture Atlas
→ Camera transform
→ Canvas.drawBitmap()

Also added:

- player/NPC-style position interpolation
- frame-time telemetry
- average/worst frame time
- over-16.67ms frame count

Native regression:
STEP50_MAP_CHUNK_TILE_BATCH_TEST_OK

Next Step 51:
- populate tile IDs from real map data instead of the deterministic tile placeholder
- connect player/NPC render entities to the same map frame
- add camera follow/dead-zone logic
- expose frame telemetry to Android debug overlay
