# Step 44 — Android/JNI Resource Bridge

Added:
- C++ AndroidResourceBridge exposing prioritized chunk resource requests
- Kotlin Step44ResourceManager using BitmapFactory
- background decode executor (2 workers)
- duplicate-load suppression via in-flight IDs
- Android LruCache with byte-based sizing
- ComponentCallbacks2 memory-pressure trimming
- native bridge regression test

The Kotlin resource manager is asset-neutral: supply authorized/user-owned
asset paths to request(). No commercial FF1 graphics are included.

Native test:
STEP44_ANDROID_BRIDGE_TEST_OK

Next:
- real JNI bindings from native bridge to Kotlin
- camera-frame callback integration
- active-chunk pinning
- visible/prefetch bitmap requests
- Canvas atlas rendering against the cache
