# Step 21 — Battle Rewards and Level-Up Settlement

Added a real post-battle reward pipeline:
- EXP and Gil are committed to the party/save state.
- EXP is tracked per living character.
- Multiple level-ups are supported in one reward.
- Level-up count is exposed to Android.
- Per-character EXP and level-up counts are exposed to Android.
- A reward-pending state lets the UI show a settlement screen before dismissing it.
- Existing PartySystem growth updates HP/MP caps, attack/defense, and restores HP/MP on level-up.

Native regression: STEP21_REWARD_TEST_OK.

Note: this validates the native reward layer. A full Android APK build still depends on the local Android SDK/Gradle environment.
