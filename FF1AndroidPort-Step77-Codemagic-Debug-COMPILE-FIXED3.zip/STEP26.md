# Step 26 — Map Events and Scene Transitions

Added a UI-neutral scene transition state machine (fade-out/loading/fade-in),
interaction state for dialogue/chests/warps, and a regression test for map warps.
The existing event system remains data-driven and compatible with the Android UI.
