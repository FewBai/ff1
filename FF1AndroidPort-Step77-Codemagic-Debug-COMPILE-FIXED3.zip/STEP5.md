# Step 5 — Data/Runtime Migration Layer

This milestone connects the engine to data-oriented interfaces instead of
hard-coding all battle definitions inside the battle loop.

## Added

- `data_tables.*`
  - weapon interface
  - armor interface
  - enemy interface
  - encounter-group interface
- `battle_formations.*`
  - converts a formation into runtime battle actors
- `encounter_system.*`
  - movement-step encounter hook
  - deterministic seed support
- `map_format.*`
  - validates decoded map arrays
  - converts them into the runtime TileMap
- CMake updated for all modules
- JNI exposes encounter stepping
- Android movement now checks for an encounter

## Important

The numeric values in these tables are deliberately small placeholder values.
They are not presented as an extraction of the commercial game data.

The public FF1Disassembly repository documents the original game's RAM map,
tile attributes and battle formation format, and its build system produces an
NES ROM. This Step 5 layer is the adapter where legally usable/authorized
decoded data can be plugged in without changing the Android runtime.

Reference:
https://github.com/Entroper/FF1Disassembly

## Next

- Implement the exact map decoder against a user-provided/authorized data set.
- Port exact encounter selection and battle formulas from the documented source.
- Add NPC/event scripting.
- Add item/equipment inventory.
- Add magic/spell system.
- Add party creation and progression.
- Add Android lifecycle save/restore.
