#include "bitmap_cache_store.h"
#include "renderer_bitmap_cache.h"
#include <cassert>
#include <iostream>
using namespace ff1;
int main() {
    BitmapCacheStore store;
    RendererBitmapCache cache(store);
    assert(!cache.contains(7));
    store.publish(7, 4096);
    assert(cache.contains(7));
    assert(cache.ready(7));
    store.publish(12, 8192);
    assert(cache.contains(12));
    assert(store.size() == 2);
    std::cout << "STEP68_RENDERER_BITMAP_CACHE_TEST_OK\n";
}
