package com.ff1.android.graphics

import android.graphics.Bitmap
import android.graphics.BitmapFactory

object BitmapDecodeReuseOptions {
    fun prepare(pool: BitmapPool, width: Int, height: Int): BitmapFactory.Options {
        val options = BitmapFactory.Options()
        options.inPreferredConfig = Bitmap.Config.ARGB_8888
        val reuse = pool.acquire(width, height, Bitmap.Config.ARGB_8888)
        if (reuse != null) {
            options.inMutable = true
            options.inBitmap = reuse
        }
        return options
    }
}
