package com.ff1.android.graphics

/** Stable size classes avoid creating a unique pool bucket for every texture size. */
enum class BitmapSizeClass(val maxBytes: Int) {
    TINY(64 * 1024),
    SMALL(256 * 1024),
    MEDIUM(1024 * 1024),
    LARGE(4 * 1024 * 1024);

    companion object {
        fun of(bytes: Int): BitmapSizeClass? = values().firstOrNull { bytes <= it.maxBytes }
    }
}
