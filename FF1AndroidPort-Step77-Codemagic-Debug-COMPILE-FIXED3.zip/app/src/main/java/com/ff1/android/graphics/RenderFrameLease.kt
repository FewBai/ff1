package com.ff1.android.graphics

import android.graphics.Bitmap
import java.util.IdentityHashMap

/**
 * Frame-scoped borrow set. A bitmap remains protected from eviction/recycling
 * until the frame is closed.
 */
class RenderFrameLease {
    private val borrowed = IdentityHashMap<Bitmap, Int>()
    private var closed = false

    @Synchronized
    fun borrow(bitmap: Bitmap): Boolean {
        if (closed || bitmap.isRecycled) return false
        borrowed[bitmap] = (borrowed[bitmap] ?: 0) + 1
        return true
    }

    @Synchronized
    fun release(bitmap: Bitmap) {
        val n = borrowed[bitmap] ?: return
        if (n <= 1) borrowed.remove(bitmap) else borrowed[bitmap] = n - 1
    }

    @Synchronized
    fun isBorrowed(bitmap: Bitmap): Boolean = (borrowed[bitmap] ?: 0) > 0

    @Synchronized
    fun close() {
        closed = true
        borrowed.clear()
    }

    @Synchronized
    fun borrowedCount(): Int = borrowed.values.sum()
}
