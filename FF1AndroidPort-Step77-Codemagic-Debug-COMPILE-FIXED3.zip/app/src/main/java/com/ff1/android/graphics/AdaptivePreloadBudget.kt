package com.ff1.android.graphics

class AdaptivePreloadBudget(
    private val minBudget: Int = 1,
    private val normalBudget: Int = 4,
    private val maxBudget: Int = 8
) {
    var budget: Int = normalBudget
        private set

    fun update(frameMs: Double, queueDepth: Int, cacheHitRate: Double) {
        budget = when {
            frameMs > 22.0 || queueDepth >= 12 -> (budget - 2).coerceAtLeast(minBudget)
            frameMs > 18.0 || queueDepth >= 8 -> (budget - 1).coerceAtLeast(minBudget)
            frameMs < 14.0 && queueDepth <= 3 && cacheHitRate < 0.98 ->
                (budget + 1).coerceAtMost(maxBudget)
            else -> budget.coerceIn(minBudget, maxBudget)
        }
    }
}
