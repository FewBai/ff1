package com.ff1.android.graphics

import android.graphics.Canvas

class RenderFrameCoordinator(
    private val cache: AndroidBitmapCache,
    private val renderer: LayeredCanvasRenderer
) {
    fun renderFrame(canvas: Canvas, build: (RenderFrameBatch) -> Unit): Int {
        val lease=cache.beginFrame()
        val batch=RenderFrameBatch(cache,lease)
        return try {
            build(batch)
            renderer.render(canvas,batch)
        } finally {
            batch.clear()
            cache.endFrame(lease)
        }
    }
}
