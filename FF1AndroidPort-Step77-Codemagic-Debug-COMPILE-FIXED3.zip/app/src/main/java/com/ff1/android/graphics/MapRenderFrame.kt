package com.ff1.android.graphics

data class MapCamera(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float
)

data class MapChunk(
    val id: Int,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val bitmapIds: List<Int>
)

data class MapTileDraw(
    val bitmapId: Int,
    val source: android.graphics.Rect?,
    val destination: android.graphics.RectF
)

data class MapFrameResult(
    val chunksTested: Int,
    val chunksVisible: Int,
    val visibleTiles: Int,
    val cacheHits: Int,
    val cacheMisses: Int,
    val preloadSubmitted: Int,
    val drawn: Int
)
