package com.ff1.android.graphics

import android.graphics.Bitmap
import java.util.ArrayDeque

/**
 * Bounded handoff queue between decode workers and the frame/render owner.
 * The queue owns a decoded Bitmap until it is drained or rejected.
 */
class BitmapPublicationQueue(
    private val capacity: Int = 8
) {
    private val queue = ArrayDeque<BitmapDecodeResult>()

    @Synchronized
    fun offer(result: BitmapDecodeResult): Boolean {
        if (queue.size >= capacity.coerceAtLeast(1)) return false
        queue.addLast(result)
        return true
    }

    @Synchronized
    fun drain(maxCount: Int, maxBytes: Long): List<BitmapDecodeResult> {
        if (maxCount <= 0 || maxBytes <= 0L) return emptyList()
        val out = ArrayList<BitmapDecodeResult>(maxCount)
        var bytes = 0L
        while (out.size < maxCount && queue.isNotEmpty()) {
            val next = queue.peekFirst()
            val nextBytes = next.byteCount.toLong().coerceAtLeast(0L)
            if (out.isNotEmpty() && bytes + nextBytes > maxBytes) break
            queue.removeFirst()
            out += next
            bytes += nextBytes
        }
        return out
    }

    @Synchronized
    fun size(): Int = queue.size

    @Synchronized
    fun clearAndRecycle(): Int {
        var count = 0
        while (queue.isNotEmpty()) {
            queue.removeFirst().bitmap.recycleIfSafe()
            count++
        }
        return count
    }

    private fun Bitmap.recycleIfSafe() {
        if (!isRecycled && !(config == Bitmap.Config.HARDWARE && !isMutable)) recycle()
    }
}
