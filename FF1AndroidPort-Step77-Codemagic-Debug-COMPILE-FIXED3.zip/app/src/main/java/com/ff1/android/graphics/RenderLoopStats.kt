package com.ff1.android.graphics

data class RenderLoopStats(
    val visibleCount: Int,
    val cacheHits: Int,
    val cacheMisses: Int,
    val preloadRequests: Int
)
