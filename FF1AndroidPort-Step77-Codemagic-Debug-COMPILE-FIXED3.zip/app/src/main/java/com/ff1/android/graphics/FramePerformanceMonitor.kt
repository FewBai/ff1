package com.ff1.android.graphics

class FramePerformanceMonitor(
    private val targetFrameMs: Double = 16.67
) {
    private var lastFrameMs = 0.0
    private var smoothedFrameMs = targetFrameMs
    private var frames = 0L
    private var slowFrames = 0L
    private var cacheHits = 0L
    private var cacheMisses = 0L
    private var preloadRequests = 0L

    fun record(
        frameMs: Double,
        hits: Int,
        misses: Int,
        preload: Int
    ) {
        lastFrameMs = frameMs
        smoothedFrameMs = smoothedFrameMs * 0.9 + frameMs * 0.1
        frames++
        if (frameMs > targetFrameMs) slowFrames++
        cacheHits += hits
        cacheMisses += misses
        preloadRequests += preload
    }

    fun snapshot(): Snapshot = Snapshot(
        frames = frames,
        lastFrameMs = lastFrameMs,
        smoothedFrameMs = smoothedFrameMs,
        fps = if (smoothedFrameMs > 0.0) 1000.0 / smoothedFrameMs else 0.0,
        slowFrameRate = if (frames == 0L) 0.0 else slowFrames.toDouble() / frames,
        cacheHitRate = if (cacheHits + cacheMisses == 0L) 1.0
        else cacheHits.toDouble() / (cacheHits + cacheMisses),
        preloadRequests = preloadRequests
    )

    data class Snapshot(
        val frames: Long,
        val lastFrameMs: Double,
        val smoothedFrameMs: Double,
        val fps: Double,
        val slowFrameRate: Double,
        val cacheHitRate: Double,
        val preloadRequests: Long
    )
}
