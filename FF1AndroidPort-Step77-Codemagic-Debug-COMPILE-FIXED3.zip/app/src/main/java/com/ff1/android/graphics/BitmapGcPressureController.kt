package com.ff1.android.graphics

import android.content.ComponentCallbacks2
import android.content.res.Configuration

/**
 * Coordinates Android memory pressure with both the decoded Bitmap cache and pool.
 */
class BitmapGcPressureController(
    private val cache: AndroidBitmapCache,
    private val pool: BitmapPool
) : ComponentCallbacks2 {

    override fun onTrimMemory(level: Int) {
        when {
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> {
                pool.clear()
                cache.trimToBytes(cache.bytes() / 2L)
            }
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                pool.trimTo(0L)
                cache.trimToBytes(cache.bytes() * 2L / 3L)
            }
            level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                pool.trimTo(pool.bytes() / 2L)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) = Unit
    override fun onLowMemory() {
        pool.clear()
        cache.trimToBytes(0L)
    }
}
