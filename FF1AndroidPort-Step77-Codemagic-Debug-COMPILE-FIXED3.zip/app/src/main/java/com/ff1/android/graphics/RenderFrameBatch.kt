package com.ff1.android.graphics

/**
 * Collects all draw items first, then acquires each unique Bitmap once for the
 * frame. Drawing is sorted by layer and z, while Bitmap references are released
 * together at frame end.
 */
class RenderFrameBatch(
    private val cache: AndroidBitmapCache,
    private val frame: RenderFrameLease
) {
    private val items = ArrayList<RenderBatchItem>()
    private val acquired = HashMap<Int, android.graphics.Bitmap>()

    fun add(item: RenderBatchItem) { items += item }

    fun acquireAll(): Int {
        var count=0
        for (id in items.asSequence().map { it.bitmapId }.distinct()) {
            if (acquired.containsKey(id)) continue
            val bitmap=cache.acquireForFrame(id,frame) ?: continue
            acquired[id]=bitmap
            count++
        }
        return count
    }

    fun itemsInDrawOrder(): List<RenderBatchItem> =
        items.sortedWith(compareBy<RenderBatchItem> { it.layer.order }.thenBy { it.z })

    fun bitmap(id: Int): android.graphics.Bitmap? = acquired[id]

    fun clear() {
        acquired.forEach { (_, bitmap) -> frame.release(bitmap) }
        acquired.clear()
        items.clear()
    }

    fun acquiredCount(): Int = acquired.size
    fun itemCount(): Int = items.size
}
