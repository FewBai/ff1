package com.ff1.android.graphics

enum class RenderLayer(val order: Int) {
    MAP(0), OBJECTS(10), ACTORS(20), EFFECTS(30), UI(40)
}
