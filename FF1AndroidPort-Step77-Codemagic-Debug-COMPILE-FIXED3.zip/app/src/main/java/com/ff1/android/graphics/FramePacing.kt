package com.ff1.android.graphics

enum class FrameRateTarget(val fps: Int, val frameBudgetMs: Double) {
    FPS_60(60, 16.67),
    FPS_90(90, 11.11),
    FPS_120(120, 8.33)
}

data class FrameTiming(
    val totalMs: Double,
    val renderMs: Double,
    val preloadMs: Double,
    val decodeMs: Double
)

class FramePacingController(
    var target: FrameRateTarget = FrameRateTarget.FPS_60
) {
    private var last = FrameTiming(0.0, 0.0, 0.0, 0.0)
    private var overBudgetFrames = 0
    private var healthyFrames = 0

    fun record(timing: FrameTiming) {
        last = timing
        if (timing.totalMs > target.frameBudgetMs) {
            overBudgetFrames++
            healthyFrames = 0
        } else {
            healthyFrames++
            overBudgetFrames = 0
        }
    }

    fun shouldThrottlePreload(): Boolean =
        overBudgetFrames >= 2 ||
        last.preloadMs > target.frameBudgetMs * 0.20 ||
        last.decodeMs > target.frameBudgetMs * 0.35

    fun shouldRecoverPreload(): Boolean =
        healthyFrames >= 6 &&
        last.totalMs < target.frameBudgetMs * 0.80

    fun timing(): FrameTiming = last
}
