package com.ff1.android.graphics

class ChunkPreloadScheduler(
    private val bridge: AndroidBitmapPreloadBridge,
    private val cache: AndroidBitmapCache,
    private val budgetController: AdaptivePreloadBudget = AdaptivePreloadBudget(),
    private val pacing: FramePacingController = FramePacingController()
) {
    private var submittedCount = 0
    private var queued = 0

    fun lastSubmittedCount(): Int = submittedCount
    fun queueDepth(): Int = queued
    fun currentBudget(): Int = budgetController.budget

    fun updateBudget(frameMs: Double, cacheHitRate: Double) {
        budgetController.update(frameMs, queued, cacheHitRate)
    }

    fun updatePacing(timing: FrameTiming) {
        pacing.record(timing)
        if (pacing.shouldThrottlePreload()) {
            budgetController.update(timing.totalMs + 4.0, queued + 8, cacheHitRate = 1.0)
        } else if (pacing.shouldRecoverPreload()) {
            budgetController.update(timing.totalMs, queued, cacheHitRate = 0.80)
        }
    }

    fun pacing(): FramePacingController = pacing

    fun submitFrame(visibleBitmapIds: List<Int>, preloadBitmapIds: List<Int>) {
        var budget = budgetController.budget
        submittedCount = 0
        queued = 0

        val seen = HashSet<Int>()
        for (id in visibleBitmapIds + preloadBitmapIds) {
            if (!seen.add(id)) continue
            if (cache.contains(id)) continue
            queued++
        }

        // Visible content has strict priority.
        for (id in visibleBitmapIds.distinct()) {
            if (budget <= 0) break
            if (!cache.contains(id)) {
                bridge.request(id)
                submittedCount++
                budget--
            }
        }

        // Remaining budget warms nearby chunks.
        for (id in preloadBitmapIds.distinct()) {
            if (budget <= 0) break
            if (!cache.contains(id) && !visibleBitmapIds.contains(id)) {
                bridge.request(id)
                submittedCount++
                budget--
            }
        }

        queued = (queued - submittedCount).coerceAtLeast(0)
    }
}
