package com.ff1.android

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect

data class Step46DrawCommand(
    val resourceId: Int,
    val atlasX: Int, val atlasY: Int,
    val atlasWidth: Int, val atlasHeight: Int,
    val screenX: Int, val screenY: Int,
    val dstWidth: Int, val dstHeight: Int
)

class Step46CanvasRenderer(private val resources: Step44ResourceManager) {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = Rect()

    fun draw(canvas: Canvas, commands: List<Step46DrawCommand>) {
        for (c in commands) {
            val bitmap: Bitmap = resources.get(c.resourceId) ?: continue
            src.set(c.atlasX,c.atlasY,c.atlasX+c.atlasWidth,c.atlasY+c.atlasHeight)
            dst.set(c.screenX,c.screenY,c.screenX+c.dstWidth,c.screenY+c.dstHeight)
            canvas.drawBitmap(bitmap,src,dst,paint)
        }
    }
}
