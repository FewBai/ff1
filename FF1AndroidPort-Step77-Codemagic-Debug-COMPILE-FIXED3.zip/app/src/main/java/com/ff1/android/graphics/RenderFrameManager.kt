package com.ff1.android.graphics

/**
 * Owns the set of active render frames. Cache eviction can consult this
 * manager before recycling a Bitmap.
 */
class RenderFrameManager {
    private val active=LinkedHashSet<RenderFrameLease>()

    @Synchronized fun beginFrame(): RenderFrameLease {
        val lease=RenderFrameLease()
        active.add(lease)
        return lease
    }

    @Synchronized fun endFrame(lease: RenderFrameLease) {
        lease.close()
        active.remove(lease)
    }

    @Synchronized fun leases(): List<RenderFrameLease> = active.toList()
    @Synchronized fun activeFrameCount(): Int = active.size
}
