package com.ff1.android.graphics

import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF

class CanvasBitmapRenderer(
    private val provider: AndroidBitmapProvider
) {
    fun drawBitmap(
        canvas: Canvas,
        id: Int,
        src: Rect?,
        dst: RectF,
        paint: android.graphics.Paint
    ): Boolean {
        val bitmap = provider.get(id) ?: return false
        canvas.drawBitmap(bitmap, src, dst, paint)
        return true
    }
}
