package com.ff1.android.graphics

class BitmapDecodeMetrics {
    data class Snapshot(
        val decodedCount: Long,
        val decodedBytes: Long,
        val rejectedPublications: Long
    )

    private var decodedCount = 0L
    private var decodedBytes = 0L
    private var rejectedPublications = 0L

    @Synchronized fun onDecoded(bytes: Int) { decodedCount++; decodedBytes += bytes.toLong().coerceAtLeast(0L) }
    @Synchronized fun onRejected() { rejectedPublications++ }
    @Synchronized fun snapshot(): Snapshot = Snapshot(decodedCount, decodedBytes, rejectedPublications)
}
