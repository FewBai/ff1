package com.ff1.android

import android.graphics.Canvas

class Step47GameFrameRenderer(
    private val nativeBridge: Step45NativeResourceBridge,
    private val cache: Step44ResourceManager
) {
    data class Camera(val left: Int, val top: Int, val right: Int, val bottom: Int)

    data class Sprite(
        val resourceId: Int,
        val atlasX: Int,
        val atlasY: Int,
        val atlasWidth: Int,
        val atlasHeight: Int,
        val worldX: Int,
        val worldY: Int,
        val width: Int,
        val height: Int
    )

    private val canvasRenderer = Step46CanvasRenderer(cache)

    fun drawFrame(
        canvas: Canvas,
        camera: Camera,
        dx: Int,
        dy: Int,
        sprites: List<Sprite>
    ) {
        nativeBridge.onCameraFrame(
            camera.left, camera.top, camera.right, camera.bottom,
            dx, dy
        )

        val commands = ArrayList<Step46DrawCommand>(sprites.size)
        for (s in sprites) {
            val x = s.worldX - camera.left
            val y = s.worldY - camera.top

            if (x + s.width <= 0 || y + s.height <= 0 ||
                x >= camera.right - camera.left ||
                y >= camera.bottom - camera.top) continue

            if (cache.get(s.resourceId) == null) continue

            commands += Step46DrawCommand(
                s.resourceId,
                s.atlasX, s.atlasY, s.atlasWidth, s.atlasHeight,
                x, y, s.width, s.height
            )
        }

        canvasRenderer.draw(canvas, commands)
    }
}
