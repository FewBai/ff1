package com.ff1.android.graphics

/** Frame-boundary publication budget. It is deliberately conservative. */
class BitmapPublicationBudget(
    private val normalCount: Int = 2,
    private val normalBytes: Long = 1024L * 1024L
) {
    data class Budget(val maxCount: Int, val maxBytes: Long)

    fun forPacing(pacing: FramePacingController): Budget {
        return when {
            pacing.shouldThrottlePreload() -> Budget(1, 256L * 1024L)
            pacing.shouldRecoverPreload() -> Budget(normalCount.coerceAtLeast(2), 2L * 1024L * 1024L)
            else -> Budget(normalCount.coerceAtLeast(1), normalBytes.coerceAtLeast(64L * 1024L))
        }
    }
}
