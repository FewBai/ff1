package com.ff1.android.graphics

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF

class SafeCanvasBitmapRenderer(
    private val cache: AndroidBitmapCache,
    private val paint: Paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
) {
    fun draw(
        canvas: Canvas,
        frame: RenderFrameLease,
        id: Int,
        src: Rect,
        dst: RectF
    ): Boolean {
        val bitmap=cache.acquireForFrame(id,frame) ?: return false
        if (bitmap.isRecycled) {
            frame.release(bitmap)
            return false
        }
        canvas.drawBitmap(bitmap,src,dst,paint)
        frame.release(bitmap)
        return true
    }
}
