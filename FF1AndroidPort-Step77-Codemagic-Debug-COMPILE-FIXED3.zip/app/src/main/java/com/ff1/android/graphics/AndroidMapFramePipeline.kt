package com.ff1.android.graphics

import android.graphics.Canvas

class AndroidMapFramePipeline(
    private val renderLoop: AndroidVisibleAreaRenderLoop,
    private val provider: AndroidBitmapProvider,
    private val scheduler: ChunkPreloadScheduler,
    private val performance: FramePerformanceMonitor = FramePerformanceMonitor(),
    private val pacing: FramePacingController = FramePacingController(),
    private val velocity: CameraVelocityPredictor = CameraVelocityPredictor(),
    private val publicationBudget: BitmapPublicationBudget = BitmapPublicationBudget(),
    private val publicationController: BitmapPublicationController? = null
) {
    fun render(
        canvas: Canvas,
        camera: MapCamera,
        chunks: List<MapChunk>,
        tilesByChunk: Map<Int, List<MapTileDraw>>,
        frameMsHint: Double = performance.snapshot().smoothedFrameMs
    ): MapFrameResult {
        publicationController?.let {
            val budget = publicationBudget.forPacing(pacing)
            it.drainForFrame(budget.maxCount, budget.maxBytes)
        }

        val velocityNow = velocity.update(camera)
        val predictedChunkIds = velocity.predictChunkIds(camera, chunks)
        val visibleChunks = chunks.filter { intersects(camera, it) }

        val visibleTiles = ArrayList<MapTileDraw>()
        val preloadIds = LinkedHashSet<Int>()

        for (chunk in visibleChunks) {
            visibleTiles += tilesByChunk[chunk.id].orEmpty()
            preloadIds += chunk.bitmapIds
        }

        for (chunk in chunks) {
            if (!visibleChunks.contains(chunk) && near(camera, chunk)) {
                preloadIds += chunk.bitmapIds
            }
            if (predictedChunkIds.contains(chunk.id)) {
                preloadIds += chunk.bitmapIds
            }
        }

        var hits = 0
        var misses = 0
        for (tile in visibleTiles) {
            if (provider.contains(tile.bitmapId)) hits++ else misses++
        }

        scheduler.updateBudget(frameMsHint, performance.snapshot().cacheHitRate)
        pacing.record(FrameTiming(
            totalMs = frameMsHint,
            renderMs = frameMsHint * 0.65,
            preloadMs = frameMsHint * 0.10,
            decodeMs = frameMsHint * 0.25
        ))
        scheduler.updatePacing(pacing.timing())
        val visibleDraws = visibleTiles.map { tile ->
            VisibleBitmapDraw(
                bitmapId = tile.bitmapId,
                source = tile.source,
                destination = tile.destination
            )
        }
        val drawn = renderLoop.drawFrame(canvas, visibleDraws, preloadIds.toList())

        performance.record(
            frameMs = frameMsHint,
            hits = hits,
            misses = misses,
            preload = scheduler.lastSubmittedCount()
        )

        return MapFrameResult(
            chunksTested = chunks.size,
            chunksVisible = visibleChunks.size,
            visibleTiles = visibleTiles.size,
            cacheHits = hits,
            cacheMisses = misses,
            preloadSubmitted = scheduler.lastSubmittedCount(),
            drawn = drawn
        )
    }

    fun pacingController(): FramePacingController = pacing

    fun performanceSnapshot(): FramePerformanceMonitor.Snapshot =
        performance.snapshot()

    private fun intersects(c: MapCamera, k: MapChunk) =
        c.x < k.right && c.x + c.width > k.left &&
        c.y < k.bottom && c.y + c.height > k.top

    private fun near(c: MapCamera, k: MapChunk): Boolean {
        val mx = c.width
        val my = c.height
        return c.x - mx < k.right &&
            c.x + c.width + mx > k.left &&
            c.y - my < k.bottom &&
            c.y + c.height + my > k.top
    }
}
