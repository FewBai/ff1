package com.ff1.android.graphics

import android.graphics.Canvas
import android.graphics.Paint

class LayeredCanvasRenderer(
    private val cache: AndroidBitmapCache,
    private val paint: Paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
) {
    fun render(canvas: Canvas, batch: RenderFrameBatch): Int {
        batch.acquireAll()
        var drawn=0
        for (item in batch.itemsInDrawOrder()) {
            val bitmap=batch.bitmap(item.bitmapId) ?: continue
            if (bitmap.isRecycled) continue
            canvas.drawBitmap(bitmap,item.src,item.dst,paint)
            drawn++
        }
        return drawn
    }
}
