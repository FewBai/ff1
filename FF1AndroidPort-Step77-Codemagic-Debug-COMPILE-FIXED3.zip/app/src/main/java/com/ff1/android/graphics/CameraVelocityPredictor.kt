package com.ff1.android.graphics

import kotlin.math.abs
import kotlin.math.roundToInt

data class CameraVelocity(
    val vx: Float,
    val vy: Float
)

class CameraVelocityPredictor(
    private val lookAheadFrames: Int = 4
) {
    private var previous: MapCamera? = null

    fun update(camera: MapCamera): CameraVelocity {
        val old = previous
        previous = camera
        if (old == null) return CameraVelocity(0f, 0f)
        return CameraVelocity(camera.x - old.x, camera.y - old.y)
    }

    fun predictChunkIds(
        camera: MapCamera,
        chunks: List<MapChunk>
    ): List<Int> {
        val old = previous ?: return emptyList()
        val vx = camera.x - old.x
        val vy = camera.y - old.y

        val future = camera.copy(
            x = camera.x + vx * lookAheadFrames,
            y = camera.y + vy * lookAheadFrames
        )

        return chunks.filter {
            future.x < it.right && future.x + future.width > it.left &&
            future.y < it.bottom && future.y + future.height > it.top
        }.map { it.id }
    }
}
