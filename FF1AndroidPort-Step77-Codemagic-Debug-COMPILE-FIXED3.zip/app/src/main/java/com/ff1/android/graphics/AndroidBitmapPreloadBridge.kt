package com.ff1.android.graphics

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore

data class BitmapDecodeResult(
    val id: Int,
    val bitmap: Bitmap,
    val byteCount: Int
)

class AndroidBitmapPreloadBridge(
    private val context: Context,
    private val cache: AndroidBitmapCache,
    private val resourceIds: Map<Int, Int>,
    maxConcurrentDecodes: Int = 2
) {
    private val executor = Executors.newFixedThreadPool(maxConcurrentDecodes.coerceAtLeast(1))
    private val pending = ConcurrentHashMap.newKeySet<Int>()
    private val permits = Semaphore(maxConcurrentDecodes.coerceAtLeast(1))
    private var publicationQueue: BitmapPublicationQueue? = null
    private val metrics = BitmapDecodeMetrics()

    fun attachPublicationQueue(queue: BitmapPublicationQueue) {
        publicationQueue = queue
    }

    fun request(id: Int): Boolean {
        if (cache.contains(id) || !pending.add(id)) return false
        val resId = resourceIds[id] ?: run {
            pending.remove(id)
            return false
        }

        executor.execute {
            permits.acquire()
            try {
                val bitmap = BitmapFactory.decodeResource(context.resources, resId)
                if (bitmap != null) {
                    val result = BitmapDecodeResult(id, bitmap, bitmap.allocationByteCount)
                    metrics.onDecoded(result.byteCount)
                    val queue = publicationQueue
                    if (queue != null && queue.offer(result)) {
                        // Ownership moves to the bounded publication queue.
                    } else {
                        metrics.onRejected()
                        result.bitmap.recycleIfSafe()
                        pending.remove(id)
                    }
                } else {
                    pending.remove(id)
                }
            } finally {
                permits.release()
            }
        }
        return true
    }

    fun pendingCount(): Int = pending.size

    fun metrics(): BitmapDecodeMetrics.Snapshot = metrics.snapshot()

    fun markPublished(id: Int) { pending.remove(id) }

    fun shutdown() {
        executor.shutdownNow()
        pending.clear()
        publicationQueue?.clearAndRecycle()
    }

    private fun Bitmap.recycleIfSafe() {
        if (!isRecycled && !(config == Bitmap.Config.HARDWARE && !isMutable)) recycle()
    }
}
