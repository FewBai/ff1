package com.ff1.android.graphics

import android.graphics.Rect
import android.graphics.RectF

data class RenderBatchItem(
    val bitmapId: Int,
    val layer: RenderLayer,
    val src: Rect,
    val dst: RectF,
    val z: Int = 0
)
