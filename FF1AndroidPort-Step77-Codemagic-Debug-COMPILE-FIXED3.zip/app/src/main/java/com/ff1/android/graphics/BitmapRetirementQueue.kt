package com.ff1.android.graphics

import android.graphics.Bitmap
import java.util.ArrayDeque

/**
 * Evicted bitmaps are retired first and physically recycled only after no
 * active RenderFrameLease protects them.
 */
class BitmapRetirementQueue {
    private data class Entry(val bitmap: Bitmap, val bytes: Long)
    private val retired=ArrayDeque<Entry>()

    @Synchronized
    fun retire(bitmap: Bitmap, activeLeases: List<RenderFrameLease>): Boolean {
        if (bitmap.isRecycled) return false
        if (activeLeases.any { it.isBorrowed(bitmap) }) {
            retired.addLast(Entry(bitmap, bitmap.allocationByteCount.toLong().coerceAtLeast(0L)))
            return false
        }
        bitmap.recycle()
        return true
    }

    @Synchronized
    fun drain(activeLeases: List<RenderFrameLease>): Int {
        var recycled=0
        val keep=ArrayDeque<Entry>()
        while(retired.isNotEmpty()){
            val e=retired.removeFirst()
            if(activeLeases.any { it.isBorrowed(e.bitmap) }) keep.addLast(e)
            else { if(!e.bitmap.isRecycled) e.bitmap.recycle(); recycled++ }
        }
        retired.addAll(keep)
        return recycled
    }

    @Synchronized fun pending(): Int = retired.size
}
