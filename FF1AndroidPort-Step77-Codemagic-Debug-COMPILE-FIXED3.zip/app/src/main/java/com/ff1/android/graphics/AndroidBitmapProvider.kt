package com.ff1.android.graphics

import android.graphics.Bitmap

/** Renderer-facing lookup of the actual decoded Bitmap. */
class AndroidBitmapProvider(
    private val cache: AndroidBitmapCache
) {
    fun get(id: Int): Bitmap? {
        val bitmap = cache.get(id)
        return bitmap?.takeUnless { it.isRecycled }
    }

    fun contains(id: Int): Boolean = get(id) != null
}
