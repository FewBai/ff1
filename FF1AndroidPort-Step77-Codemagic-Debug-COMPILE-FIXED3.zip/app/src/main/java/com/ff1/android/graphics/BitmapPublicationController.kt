package com.ff1.android.graphics

/**
 * Spreads decoded Bitmap publication across frames instead of posting every
 * decode directly to the main Looper.
 */
class BitmapPublicationController(
    private val queue: BitmapPublicationQueue,
    private val cache: AndroidBitmapCache,
    private val bridge: AndroidBitmapPreloadBridge
) {
    data class Stats(
        val publishedCount: Int,
        val publishedBytes: Long,
        val pendingPublications: Int
    )

    private var lastStats = Stats(0, 0L, 0)

    fun drainForFrame(maxCount: Int, maxBytes: Long): Stats {
        var count = 0
        var bytes = 0L
        for (result in queue.drain(maxCount, maxBytes)) {
            if (cache.contains(result.id)) {
                result.bitmap.recycleIfSafe()
                bridge.markPublished(result.id)
                continue
            }
            cache.put(result.id, result.bitmap)
            bridge.markPublished(result.id)
            count++
            bytes += result.byteCount.toLong().coerceAtLeast(0L)
        }
        lastStats = Stats(count, bytes, queue.size())
        return lastStats
    }

    fun stats(): Stats = lastStats

    private fun android.graphics.Bitmap.recycleIfSafe() {
        if (!isRecycled && !(config == android.graphics.Bitmap.Config.HARDWARE && !isMutable)) recycle()
    }
}
