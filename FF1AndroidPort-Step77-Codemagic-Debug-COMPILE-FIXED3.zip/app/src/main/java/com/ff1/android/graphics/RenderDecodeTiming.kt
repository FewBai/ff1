package com.ff1.android.graphics

class RenderDecodeTiming {
    private var decodeStartNs = 0L
    private var decodeMs = 0.0

    fun beginDecode() {
        decodeStartNs = System.nanoTime()
    }

    fun endDecode() {
        if (decodeStartNs != 0L) {
            decodeMs += (System.nanoTime() - decodeStartNs) / 1_000_000.0
            decodeStartNs = 0L
        }
    }

    fun consumeDecodeMs(): Double {
        val value = decodeMs
        decodeMs = 0.0
        return value
    }
}
