package com.ff1.android

import android.graphics.Canvas
import android.view.Choreographer

class Step49RenderFrame(private val renderer: Step47GameFrameRenderer)
    : Choreographer.FrameCallback {
    private var canvas: Canvas? = null
    private var camera: Step47GameFrameRenderer.Camera? = null
    private var sprites: List<Step47GameFrameRenderer.Sprite> = emptyList()
    private var dx = 0
    private var dy = 0
    private var scheduled = false

    fun submit(
        target: Canvas,
        nextCamera: Step47GameFrameRenderer.Camera,
        nextSprites: List<Step47GameFrameRenderer.Sprite>,
        cameraDx: Int,
        cameraDy: Int
    ) {
        canvas=target; camera=nextCamera; sprites=nextSprites
        dx=cameraDx; dy=cameraDy
        if (!scheduled) {
            scheduled=true
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        scheduled=false
        val target=canvas
        val currentCamera=camera
        if (target!=null && currentCamera!=null)
            renderer.drawFrame(target,currentCamera,dx,dy,sprites)
        canvas=null; camera=null; sprites=emptyList()
    }
}
