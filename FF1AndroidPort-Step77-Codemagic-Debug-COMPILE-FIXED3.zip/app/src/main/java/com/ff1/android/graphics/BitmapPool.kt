package com.ff1.android.graphics

import android.graphics.Bitmap
import java.util.ArrayDeque
import java.util.EnumMap

/**
 * Size-class Bitmap pool. Only mutable, software bitmaps with a compatible
 * configuration are accepted, so pooled objects are safe to hand to BitmapFactory.
 */
class BitmapPool(
    private val maxBytes: Long = 4L * 1024L * 1024L,
    private val perClassLimit: Int = 3
) {
    private val buckets = EnumMap<BitmapSizeClass, ArrayDeque<Bitmap>>(BitmapSizeClass::class.java)
    private var bytes = 0L

    @Synchronized
    fun acquire(width: Int, height: Int, config: Bitmap.Config = Bitmap.Config.ARGB_8888): Bitmap? {
        if (config == Bitmap.Config.HARDWARE) return null
        val needed = width.toLong() * height.toLong() * 4L
        val cls = BitmapSizeClass.of(needed.toInt()) ?: return null
        val bucket = buckets[cls] ?: return null
        while (bucket.isNotEmpty()) {
            val b = bucket.removeFirst()
            bytes -= b.allocationByteCount.toLong().coerceAtLeast(0L)
            if (!b.isRecycled && b.width >= width && b.height >= height && b.config == config) {
                b.eraseColor(0)
                return b
            }
            if (!b.isRecycled) b.recycle()
        }
        return null
    }

    @Synchronized
    fun release(bitmap: Bitmap): Boolean {
        if (bitmap.isRecycled ||
            bitmap.config == Bitmap.Config.HARDWARE ||
            !bitmap.isMutable
        ) {
            return false
        }

        val bitmapBytes =
            bitmap.allocationByteCount.toLong().coerceAtLeast(0L)

        val cls = BitmapSizeClass.of(bitmap.allocationByteCount)
            ?: return false

        val bucket = buckets.getOrPut(cls) { ArrayDeque() }

        while (
            bucket.size >= perClassLimit ||
            bytes + bitmapBytes > maxBytes
        ) {
            if (bucket.isEmpty()) {
                return false
            }

            val old = bucket.removeFirst()

            bytes -= old.allocationByteCount
                .toLong()
                .coerceAtLeast(0L)

            if (!old.isRecycled) {
                old.recycle()
            }
        }

        if (bytes + bitmapBytes > maxBytes) {
            return false
        }

        bucket.addLast(bitmap)
        bytes += bitmapBytes

        return true
    }

    @Synchronized
    fun trimTo(targetBytes: Long) {
        while (bytes > targetBytes) {
            val cls = buckets.keys.firstOrNull { buckets[it]?.isNotEmpty() == true } ?: break
            val bucket = buckets[cls]!!
            val b = bucket.removeFirst()
            bytes -= b.allocationByteCount.toLong().coerceAtLeast(0L)
            if (!b.isRecycled) b.recycle()
        }
    }

    @Synchronized fun bytes(): Long = bytes

    @Synchronized
    fun clear() {
        buckets.values.forEach { bucket ->
            while (bucket.isNotEmpty()) {
                val b = bucket.removeFirst()
                if (!b.isRecycled) b.recycle()
            }
        }
        buckets.clear()
        bytes = 0L
    }
}
