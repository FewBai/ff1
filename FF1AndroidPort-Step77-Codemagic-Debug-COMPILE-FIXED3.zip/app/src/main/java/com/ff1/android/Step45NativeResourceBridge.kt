package com.ff1.android

class Step45NativeResourceBridge(
    private val resources: Step44ResourceManager,
    private val assetPathForId: (Int) -> String
) {
    external fun nativeCreate(): Long
    external fun nativeUpdate(
        handle: Long,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int,
        dx: Int,
        dy: Int
    ): Int

    external fun nativePoll(
        handle: Long,
        maxRequests: Int
    ): IntArray

    external fun nativeDestroy(handle: Long)

    private var handle: Long = 0

    fun start() {
        check(handle == 0L)
        handle = nativeCreate()
    }

    fun onCameraFrame(
        left: Int, top: Int, right: Int, bottom: Int,
        dx: Int, dy: Int,
        maxRequests: Int = 32
    ) {
        check(handle != 0L)
        nativeUpdate(handle, left, top, right, bottom, dx, dy)
        val requests = nativePoll(handle, maxRequests)

        var i = 0
        while (i + 1 < requests.size) {
            val id = requests[i]
            val priority = requests[i + 1]
            resources.request(
                id = id,
                priority = priority,
                assetPath = assetPathForId(id)
            )
            i += 2
        }
    }

    fun stop() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }
}
