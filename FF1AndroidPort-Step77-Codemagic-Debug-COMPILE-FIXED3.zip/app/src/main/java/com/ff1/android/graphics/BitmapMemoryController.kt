package com.ff1.android.graphics

import android.content.ComponentCallbacks2
import android.content.res.Configuration

/**
 * Bridges Android memory pressure to the bitmap LRU.
 * Recycling is performed only for entries removed from the cache.
 */
class BitmapMemoryController(
    private val cache: AndroidBitmapCache,
    private val normalBudgetBytes: Long
) : ComponentCallbacks2 {

    override fun onTrimMemory(level: Int) {
        when {
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ->
                cache.trimToBytes(normalBudgetBytes / 4)
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ->
                cache.trimToBytes(normalBudgetBytes / 2)
            level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND ->
                cache.trimToBytes(normalBudgetBytes / 2)
            level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN ->
                cache.trimToBytes(normalBudgetBytes / 2)
        }
    }

    override fun onLowMemory() {
        cache.trimToBytes(normalBudgetBytes / 4)
    }

    override fun onConfigurationChanged(newConfig: Configuration) = Unit
}
