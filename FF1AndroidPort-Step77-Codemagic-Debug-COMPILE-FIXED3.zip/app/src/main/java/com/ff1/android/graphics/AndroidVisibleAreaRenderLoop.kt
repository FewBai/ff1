package com.ff1.android.graphics

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF

data class VisibleBitmapDraw(
    val bitmapId: Int,
    val source: Rect?,
    val destination: RectF
)

class AndroidVisibleAreaRenderLoop(
    private val renderer: CanvasBitmapRenderer,
    private val provider: AndroidBitmapProvider,
    private val scheduler: ChunkPreloadScheduler,
    private val paint: Paint = Paint(Paint.FILTER_BITMAP_FLAG)
) {
    fun drawFrame(
        canvas: Canvas,
        visible: List<VisibleBitmapDraw>,
        preloadBitmapIds: List<Int>
    ): Int {
        val visibleIds = visible.map { it.bitmapId }
        scheduler.submitFrame(visibleIds, preloadBitmapIds)

        var drawn = 0
        for (tile in visible) {
            // Actual cache hit -> Canvas.drawBitmap().
            if (provider.contains(tile.bitmapId) &&
                renderer.drawBitmap(canvas, tile.bitmapId, tile.source, tile.destination, paint)
            ) {
                drawn++
            }
        }
        return drawn
    }
}
