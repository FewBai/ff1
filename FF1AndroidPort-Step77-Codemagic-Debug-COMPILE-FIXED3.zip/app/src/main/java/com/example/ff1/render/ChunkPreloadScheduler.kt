package com.example.ff1.render
class ChunkPreloadScheduler(private val preloadRadiusPx: Float = 128f) {
    fun radius(): Float = preloadRadiusPx
}
