package com.example.ff1.render
import android.view.View
data class AndroidViewport(val width:Int,val height:Int)
fun View.androidViewport():AndroidViewport = AndroidViewport(width,height)
