package com.example.ff1.debug
import android.view.Choreographer

class DebugFrameDriver(private val overlay: DebugOverlayView) : Choreographer.FrameCallback {
    private var running=false
    fun start(){ if(!running){running=true; Choreographer.getInstance().postFrameCallback(this)} }
    fun stop(){ running=false; Choreographer.getInstance().removeFrameCallback(this) }
    override fun doFrame(frameTimeNanos: Long){
        if(!running)return
        if(NativeDebugOverlayBridge.nativeIsEnabled()) overlay.update(NativeDebugOverlayBridge.snapshot())
        Choreographer.getInstance().postFrameCallback(this)
    }
}
