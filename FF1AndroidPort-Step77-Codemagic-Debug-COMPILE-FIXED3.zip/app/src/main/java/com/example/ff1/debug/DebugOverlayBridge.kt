package com.example.ff1.debug

import android.os.SystemClock
import java.util.concurrent.atomic.AtomicReference

class DebugOverlayBridge {
    private val snapshot = AtomicReference(DebugOverlaySnapshot())
    private var lastFrameNs = 0L

    fun beginFrame() {
        if (lastFrameNs == 0L) lastFrameNs = System.nanoTime()
    }

    fun publish(
        drawCalls: Int,
        cacheHits: Int,
        cacheMisses: Int,
        missingTileIds: Int,
        visibleTiles: Int,
        submittedTiles: Int
    ) {
        val now = System.nanoTime()
        val frameMs = if (lastFrameNs == 0L) 0.0 else (now-lastFrameNs)/1_000_000.0
        lastFrameNs = now
        val old = snapshot.get()
        val avg = if (old.avgFrameMs == 0.0) frameMs else old.avgFrameMs + (frameMs-old.avgFrameMs)*0.1
        val worst = maxOf(old.worstFrameMs, frameMs)
        val fps = if (frameMs > 0.001) 1000.0/frameMs else 0.0
        snapshot.set(DebugOverlaySnapshot(
            fps, frameMs, avg, worst, drawCalls, cacheHits, cacheMisses,
            missingTileIds, visibleTiles, submittedTiles
        ))
    }

    fun snapshot(): DebugOverlaySnapshot = snapshot.get()
}
