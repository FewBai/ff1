package com.example.ff1.debug

import android.view.KeyEvent
import android.view.MotionEvent

class DebugOverlayToggle(
    private val onChanged: (Boolean) -> Unit
) {
    var enabled: Boolean = true
        private set

    fun toggle() {
        enabled = !enabled
        NativeDebugOverlayBridge.nativeSetEnabled(enabled)
        onChanged(enabled)
    }

    fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_F2) {
            toggle()
            return true
        }
        return false
    }

    fun onDoubleTap(): Boolean {
        toggle()
        return true
    }
}
