package com.example.ff1.render
import android.os.Handler
import android.os.Looper
import java.util.concurrent.ConcurrentHashMap
class AndroidBitmapPreloadBridge(private val decoder:BitmapDecodeWorker,private val publish:(BitmapDecodeResult)->Unit){
 private val pending=ConcurrentHashMap.newKeySet<Int>()
 private val mainHandler=Handler(Looper.getMainLooper())
 fun request(id:Int,resourceId:Int){
  if(!pending.add(id))return
  decoder.decodeAsync(id,resourceId){result->
   pending.remove(id);mainHandler.post{publish(result)}
  }
 }
 fun isPending(id:Int)=pending.contains(id)
}
