package com.example.ff1.render

import android.content.Context
import android.graphics.Canvas
import android.view.View
import com.example.ff1.debug.DebugOverlayView
import com.example.ff1.debug.NativeDebugOverlayBridge

class DebugGameView(
    context: Context,
    private val mapLoop: AndroidMapRenderLoop,
    private val overlay: DebugOverlayView
) : View(context) {
    private var lastNs = 0L

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val frameMs = if (lastNs == 0L) 0.0 else (now-lastNs)/1_000_000.0
        lastNs = now

        mapLoop.draw(canvas, frameMs)

        if (NativeDebugOverlayBridge.nativeIsEnabled()) {
            overlay.update(NativeDebugOverlayBridge.snapshot())
        }
        postInvalidateOnAnimation()
    }
}
