package com.example.ff1.render
import android.graphics.Bitmap
data class BitmapDecodeResult(val id:Int,val bitmap:Bitmap,val byteCount:Long)
