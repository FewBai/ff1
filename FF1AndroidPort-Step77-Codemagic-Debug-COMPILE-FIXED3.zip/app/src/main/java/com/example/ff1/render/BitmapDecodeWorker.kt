package com.example.ff1.render
import android.content.Context
import android.graphics.BitmapFactory
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
class BitmapDecodeWorker(private val context:Context,private val executor:ExecutorService=Executors.newFixedThreadPool(2)){
 fun decodeAsync(id:Int,resourceId:Int,onReady:(BitmapDecodeResult)->Unit){
  executor.execute{
   val bitmap=BitmapFactory.decodeResource(context.resources,resourceId) ?: return@execute
   onReady(BitmapDecodeResult(id,bitmap,bitmap.allocationByteCount.toLong()))
  }
 }
 fun shutdown(){executor.shutdown()}
}
