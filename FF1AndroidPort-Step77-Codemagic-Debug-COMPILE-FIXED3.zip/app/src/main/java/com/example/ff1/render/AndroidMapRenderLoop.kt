package com.example.ff1.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View

class AndroidMapRenderLoop(
    private val renderer: NativeMapRenderer
) {
    fun draw(canvas: Canvas, frameMs: Double) {
        renderer.render(canvas, frameMs)
    }
}

interface NativeMapRenderer {
    fun render(canvas: Canvas, frameMs: Double)
}
