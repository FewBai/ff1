package com.example.ff1.debug

object NativeDebugOverlayBridge {
    init {
        try { System.loadLibrary("ff1") } catch (_: UnsatisfiedLinkError) {}
    }

    external fun nativeSetEnabled(enabled: Boolean)
    external fun nativeIsEnabled(): Boolean
    external fun nativeBeginFrame()
    external fun nativeEndFrame(frameMs: Double)
    external fun nativeSetMemory(bitmapBytes: Long, atlasBytes: Long)
    external fun nativeRecordDraw()
    external fun nativeRecordCacheHit()
    external fun nativeRecordCacheMiss()
    external fun nativeRecordMissingTile()
    external fun nativeSetTiles(visible: Long, submitted: Long)

    external fun nativeFps(): Double
    external fun nativeFrameMs(): Double
    external fun nativeAvgMs(): Double
    external fun nativeWorstMs(): Double
    external fun nativeDrawCalls(): Long
    external fun nativeCacheHits(): Long
    external fun nativeCacheMisses(): Long
    external fun nativeMissingTiles(): Long
    external fun nativeVisibleTiles(): Long
    external fun nativeSubmittedTiles(): Long
    external fun nativeCacheBytes(): Long
    external fun nativeAtlasBytes(): Long
    external fun nativeOverBudget(): Boolean

    fun snapshot(): DebugOverlaySnapshot = DebugOverlaySnapshot(
        fps = nativeFps(),
        frameMs = nativeFrameMs(),
        avgFrameMs = nativeAvgMs(),
        worstFrameMs = nativeWorstMs(),
        drawCalls = nativeDrawCalls().toInt(),
        cacheHits = nativeCacheHits().toInt(),
        cacheMisses = nativeCacheMisses().toInt(),
        missingTileIds = nativeMissingTiles().toInt(),
        visibleTiles = nativeVisibleTiles().toInt(),
        submittedTiles = nativeSubmittedTiles().toInt(),
        cacheBytes = nativeCacheBytes(),
        atlasBytes = nativeAtlasBytes(),
        overBudget = nativeOverBudget()
    )
}
