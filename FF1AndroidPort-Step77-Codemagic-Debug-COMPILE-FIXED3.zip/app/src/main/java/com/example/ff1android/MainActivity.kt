package com.example.ff1android

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var gameView: GameView
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable { override fun run() { NativeGame.update(); gameView.invalidate(); handler.postDelayed(this, 100L) } }

    private fun slot(name: String) = "${filesDir.absolutePath}/$name"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        gameView = GameView(this) { slot(it) }
        setContentView(gameView)
        NativeGame.init()
        // Prefer autosave only when it exists; otherwise start a new game.
        NativeGame.load(slot("autosave.dat"))
    }
    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { NativeGame.save(slot("autosave.dat")); handler.removeCallbacks(ticker); super.onPause() }
}
