package com.example.ff1android

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Step 25: camera-based tile renderer + touch D-pad + world interaction. */

/**
 * Step 40: asset-neutral Android Canvas renderer.
 * The native core supplies world-space actor state; Android owns actual
 * Bitmap/Canvas resources so no commercial game art is bundled.
 */
private class Step40CanvasRenderer {
    data class Actor(
        val x: Float,
        val y: Float,
        val size: Float = 32f,
        val visible: Boolean = true
    )

    fun drawWorld(canvas: android.graphics.Canvas, cameraX: Float, cameraY: Float,
                  actors: List<Actor>) {
        for (actor in actors) {
            if (!actor.visible) continue
            val sx = actor.x - cameraX
            val sy = actor.y - cameraY
            // Placeholder silhouette: replace with authorized Bitmap frames.
            canvas.drawRect(sx, sy, sx + actor.size, sy + actor.size, paint)
        }
    }

    private val paint = android.graphics.Paint(
        android.graphics.Paint.ANTI_ALIAS_FLAG
    )
}

class GameView(context: Context, private val path: (String) -> String) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = android.graphics.Typeface.MONOSPACE }
    private var cameraX = 0f
    private var cameraY = 0f
    private var toast = ""
    private var toastUntil = 0L
    private var battleActor = 0
    private var battleTarget = 0
    private var battleSub = 0
    private var selectedSpell = 1
    private var dialogVisible = false
    private var dialogText = ""

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float = 18f) {
        paint.textSize = size; paint.color = Color.WHITE; c.drawText(s, x, y, paint)
    }
    private fun box(c: Canvas, l: Float, t: Float, r: Float, b: Float, selected: Boolean = false) {
        paint.color = if (selected) Color.rgb(65, 90, 145) else Color.rgb(45, 48, 58)
        c.drawRoundRect(RectF(l, t, r, b), 10f, 10f, paint)
    }
    private fun say(s: String) { toast = s; toastUntil = System.currentTimeMillis() + 1400 }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        when (NativeGame.getGameMode()) {
            2 -> drawBattle(c)
            3 -> drawMenu(c)
            else -> drawWorld(c)
        }
        if (System.currentTimeMillis() < toastUntil) {
            box(c, 18f, height - 58f, width - 18f, height - 16f)
            text(c, toast, 30f, height - 31f, 15f)
            postInvalidateDelayed(100)
        }
        drawDialog(c)
    }

    private fun drawWorld(c: Canvas) {
        val panelW = min(250f, width * .28f)
        val viewW = width - panelW
        val tile = min(viewW / 12f, height / 9f)
        val mapW = 32; val mapH = 24
        val px = NativeGame.getX().toFloat(); val py = NativeGame.getY().toFloat()
        cameraX = (px + .5f) * tile - viewW / 2f
        cameraY = (py + .5f) * tile - height / 2f
        cameraX = cameraX.coerceIn(0f, max(0f, mapW * tile - viewW))
        cameraY = cameraY.coerceIn(0f, max(0f, mapH * tile - height))

        c.drawColor(Color.rgb(20, 45, 28))
        val startX = max(0, (cameraX / tile).toInt() - 1); val endX = min(mapW - 1, ((cameraX + viewW) / tile).toInt() + 1)
        val startY = max(0, (cameraY / tile).toInt() - 1); val endY = min(mapH - 1, ((cameraY + height) / tile).toInt() + 1)
        for (y in startY..endY) for (x in startX..endX) {
            val sx = x * tile - cameraX; val sy = y * tile - cameraY
            paint.color = when {
                x == 0 || y == 0 || x == mapW - 1 || y == mapH - 1 -> Color.rgb(65, 70, 68)
                x == 8 && y in 5..17 || y == 10 && x in 12..22 -> Color.rgb(72, 72, 72)
                (x + y) % 9 == 0 -> Color.rgb(46, 100, 55)
                else -> Color.rgb(38, 86, 45)
            }
            c.drawRect(sx, sy, sx + tile + 1, sy + tile + 1, paint)
            paint.color = Color.argb(35, 255, 255, 255); c.drawRect(sx, sy, sx + tile, sy + 1, paint)
        }
        // Player sprite placeholder, kept separate from tile rendering.
        val sx = (px * tile - cameraX); val sy = (py * tile - cameraY)
        paint.color = Color.WHITE; c.drawCircle(sx + tile / 2, sy + tile / 2, tile * .28f, paint)
        paint.color = Color.rgb(45, 55, 95); c.drawRect(sx + tile*.25f, sy + tile*.52f, sx + tile*.75f, sy + tile*.9f, paint)

        paint.color = Color.rgb(12, 14, 18); c.drawRect(viewW, 0f, width.toFloat(), height.toFloat(), paint)
        text(c, "WORLD", viewW + 20f, 34f, 22f)
        text(c, "MAP 0", viewW + 20f, 62f, 14f)
        text(c, "${NativeGame.getX()}, ${NativeGame.getY()}", viewW + 20f, 84f, 14f)
        text(c, "GIL ${NativeGame.getGil()}", viewW + 20f, 112f, 15f)
        text(c, "PARTY ${NativeGame.livingPartyCount()}/4", viewW + 20f, 136f, 15f)
        box(c, viewW + 18f, 158f, width - 18f, 202f); text(c, "INTERACT", viewW + 34f, 185f, 14f)
        box(c, viewW + 18f, 210f, width - 18f, 254f); text(c, "MENU", viewW + 34f, 237f, 14f)
        box(c, viewW + 18f, 262f, width - 18f, 306f); text(c, "SAVE", viewW + 34f, 289f, 14f)

        val cx = viewW - 78f; val cy = height - 105f; val s = 54f
        box(c, cx, cy-s, cx+s, cy); text(c, "↑", cx+19f, cy-18f, 24f)
        box(c, cx-s, cy, cx, cy+s); text(c, "←", cx-36f, cy+36f, 24f)
        box(c, cx, cy, cx+s, cy+s); text(c, "→", cx+18f, cy+36f, 24f)
        box(c, cx, cy+s, cx+s, cy+2*s); text(c, "↓", cx+19f, cy+90f, 24f)
    }

    private fun drawBattle(c: Canvas) {
        c.drawColor(Color.rgb(8, 8, 18)); text(c, "BATTLE", 20f, 30f, 22f)
        for (i in 0 until 4) {
            val x = 16f + (i % 2) * 250f; val y = 42f + (i / 2) * 58f
            box(c, x, y, x+235f, y+48f, i == battleActor)
            text(c, "${i+1} HP ${NativeGame.getPartyHp(i)}/${NativeGame.getPartyMaxHp(i)} MP ${NativeGame.partyMp(i)}/${NativeGame.partyMaxMp(i)}", x+8f, y+29f, 12f)
        }
        if (battleSub == 0) {
            val labels = listOf("ATTACK", "ITEM", "MAGIC", "RUN")
            labels.forEachIndexed { i, s -> val x=16f+(i%2)*145f; val y=175f+(i/2)*48f; box(c,x,y,x+132f,y+38f); text(c,s,x+15f,y+25f,14f) }
            text(c, "TARGET", 320f, 190f, 15f)
            for (i in 0 until 2) { val y=205f+i*44f; box(c,320f,y,600f,y+36f,i==battleTarget); text(c,"${i+1} ${NativeGame.getEnemyName(i)} HP ${NativeGame.getEnemyHp(i)}",332f,y+24f,12f) }
        } else if (battleSub == 1) {
            text(c,"ITEMS",18f,185f,20f); box(c,18f,205f,290f,248f); text(c,"POTION x${NativeGame.getItemCount(0x20)}",32f,232f,15f)
            text(c,"TARGET",320f,185f,15f)
            for (i in 0 until 4) { val y=205f+i*44f; box(c,320f,y,600f,y+36f); text(c,"${i+1} HP ${NativeGame.getPartyHp(i)}",335f,y+24f,13f) }
        } else {
            text(c,"MAGIC",18f,185f,20f)
            for (i in 0 until 4) { val id=i+1; val y=205f+i*40f; box(c,18f,y,290f,y+34f,id==selectedSpell); text(c,"SPELL $id  MP ${NativeGame.spellMpCost(id)}",32f,y+22f,13f) }
            text(c,"TARGET",320f,185f,15f)
            for (i in 0 until 2) { val y=205f+i*44f; box(c,320f,y,600f,y+36f,i==battleTarget); text(c,"${i+1} ${NativeGame.getEnemyName(i)}",335f,y+24f,13f) }
        }
    }

    private var menuCharacter = 0
    private var menuItemId = 0x20
    private var menuEquipId = 1

    private fun drawMenu(c: Canvas) {
        c.drawColor(Color.rgb(10,12,16))
        text(c,"MENU",22f,34f,24f)
        text(c,"GIL ${NativeGame.getGil()}",width-170f,34f,16f)
        val tabs=listOf("STATUS","ITEMS","MAGIC","EQUIP")
        tabs.forEachIndexed { i,s -> box(c,18f,52f+i*48f,190f,90f+i*48f, NativeGame.getMenuState()==i+1); text(c,s,38f,77f+i*48f,15f) }
        // Character selector is shared by all four menu pages.
        for (i in 0 until 4) {
            val x=215f+i*max(1f,(width-230f)/4f)
            val r=min(width-8f,x+105f)
            box(c,x,52f,r,90f,i==menuCharacter)
            text(c,"${i+1} ${NativeGame.getPartyName(i)}",x+7f,71f,11f)
            text(c,NativeGame.getPartyJob(i),x+7f,84f,10f)
        }
        when (NativeGame.getMenuState()) {
            1 -> drawStatusPage(c)
            2 -> drawItemsPage(c)
            3 -> drawMagicPage(c)
            4 -> drawEquipmentPage(c)
            else -> drawStatusPage(c)
        }
        text(c,"Tap a tab or character • Android Back returns to map",18f,height-18f,12f)
    }

    private fun drawStatusPage(c:Canvas) {
        val i=menuCharacter
        text(c,"${NativeGame.getPartyName(i)}  /  ${NativeGame.getPartyJob(i)}",215f,125f,21f)
        text(c,"LV ${NativeGame.getPartyLevel(i)}   EXP ${NativeGame.getPartyXp(i)}",215f,153f,15f)
        text(c,"HP ${NativeGame.getPartyHp(i)} / ${NativeGame.getPartyMaxHp(i)}",215f,183f,16f)
        text(c,"MP ${NativeGame.partyMp(i)} / ${NativeGame.partyMaxMp(i)}",215f,211f,16f)
        text(c,"ATK ${NativeGame.getPartyAttack(i)}   DEF ${NativeGame.getPartyDefense(i)}",215f,239f,16f)
        text(c,"WEAPON ${NativeGame.getPartyWeapon(i)}   ARMOR ${NativeGame.getPartyArmor(i)}",215f,267f,14f)
    }

    private fun drawItemsPage(c:Canvas) {
        text(c,"ITEMS",215f,125f,21f)
        box(c,215f,145f,width-20f,193f,true); text(c,"POTION    x${NativeGame.getItemCount(0x20)}",230f,176f,16f)
        text(c,"Select a character above, then tap the item to use it.",215f,222f,13f)
    }

    private fun drawMagicPage(c:Canvas) {
        text(c,"MAGIC  •  ${NativeGame.getPartyName(menuCharacter)}",215f,125f,20f)
        for(i in 1..4) { val y=145f+(i-1)*43f; box(c,215f,y,width-20f,y+36f,i==menuItemId); text(c,"SPELL $i   MP ${NativeGame.spellMpCost(i)}   POWER ${NativeGame.spellPower(i)}",230f,y+23f,13f) }
        text(c,"Learned-spell data is read-only here; casting is available in battle.",215f,330f,12f)
    }

    private fun drawEquipmentPage(c:Canvas) {
        text(c,"EQUIPMENT  •  ${NativeGame.getPartyName(menuCharacter)}",215f,125f,19f)
        text(c,"Current weapon: ${NativeGame.getPartyWeapon(menuCharacter)}",215f,153f,14f)
        text(c,"Current armor:  ${NativeGame.getPartyArmor(menuCharacter)}",215f,179f,14f)
        box(c,215f,198f,width-20f,246f,menuEquipId==1); text(c,"EQUIP WEAPON #1",230f,228f,15f)
        box(c,215f,255f,width-20f,303f,menuEquipId==2); text(c,"EQUIP ARMOR #2",230f,285f,15f)
        text(c,"Only owned items and valid job restrictions are accepted by native core.",215f,330f,12f)
    }

    private fun drawDialog(c:Canvas) {
        if (!dialogVisible) return
        val l=18f; val r=width-18f; val b=height-24f; val t=b-150f
        box(c,l,t,r,b,true)
        text(c,dialogText,l+18f,t+36f,17f)
        text(c,"Tap to continue",r-145f,b-18f,12f)
    }

override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        if (dialogVisible) { dialogVisible=false; invalidate(); return true }
        val x=e.x; val y=e.y
        when (NativeGame.getGameMode()) {
            0,1 -> {
                val panelW=min(250f,width*.28f); val cx=width-panelW-78f; val cy=height-105f; val s=54f
                when {
                    RectF(cx,cy-s,cx+s,cy).contains(x,y) -> NativeGame.move(0,-1)
                    RectF(cx-s,cy,cx,cy+s).contains(x,y) -> NativeGame.move(-1,0)
                    RectF(cx,cy,cx+s,cy+s).contains(x,y) -> NativeGame.move(1,0)
                    RectF(cx,cy+s,cx+s,cy+2*s).contains(x,y) -> NativeGame.move(0,1)
                    x>=width-panelW && y in 158f..202f -> { val ok=NativeGame.interact(); dialogText=NativeGame.npcMessage(); dialogVisible=ok && dialogText.isNotEmpty(); if(!dialogVisible) say(if(ok) "Event triggered" else "Nothing here") }
                    x>=width-panelW && y in 210f..254f -> NativeGame.openMenu()
                    x>=width-panelW && y in 262f..306f -> { NativeGame.save(path("autosave.dat")); say("Saved") }
                }
            }
            2 -> touchBattle(x,y)
            3 -> touchMenu(x,y)
        }
        invalidate(); return true
    }

    private fun touchBattle(x:Float,y:Float) {
        if (battleSub==0) {
            if (y in 42f..158f) battleActor=((y-42f)/58f).toInt().coerceIn(0,3)
            else if (x>=320f && y in 205f..300f) battleTarget=((y-205f)/44f).toInt().coerceIn(0,1)
            else if (y in 175f..263f) {
                val col=if(x<150f)0 else 1; val row=if(y<223f)0 else 1
                when(row*2+col){
                    0 -> { NativeGame.selectBattleActor(battleActor); NativeGame.selectBattleEnemy(battleTarget); NativeGame.attack() }
                    1 -> battleSub=1
                    2 -> battleSub=2
                    3 -> NativeGame.runBattle()
                }
            }
        } else if (battleSub==1) {
            if (x>=320f && y>=205f) { val target=((y-205f)/44f).toInt().coerceIn(0,3); NativeGame.selectBattleActor(battleActor); NativeGame.battleUseItem(target); battleSub=0 }
        } else {
            if (x<300f && y>=205f) selectedSpell=((y-205f)/40f).toInt().coerceIn(0,3)+1
            else if (x>=320f && y>=205f) { battleTarget=((y-205f)/44f).toInt().coerceIn(0,1); NativeGame.selectBattleEnemy(battleTarget); NativeGame.battleCommandMagic(battleActor,selectedSpell,battleTarget); battleSub=0 }
        }
    }

    private fun touchMenu(x:Float,y:Float) {
        // Character cards
        if (y in 52f..92f && x >= 205f) {
            val slot=((x-205f)/max(1f,(width-230f)/4f)).toInt().coerceIn(0,3)
            menuCharacter=slot; invalidate(); return
        }
        if (x<205f && y in 52f..282f) {
            NativeGame.menuSelect(((y-52f)/48f).toInt()+1); invalidate(); return
        }
        when (NativeGame.getMenuState()) {
            2 -> if (x>=210f && y in 145f..193f) {
                if (NativeGame.useItem(menuCharacter,menuItemId)) say("Potion used on ${NativeGame.getPartyName(menuCharacter)}") else say("Cannot use item")
            }
            3 -> if (x>=210f && y in 145f..317f) menuItemId=((y-145f)/43f).toInt()+1
            4 -> if (x>=210f && y in 198f..310f) {
                if (y<250f) { menuEquipId=1; say(if(NativeGame.equipWeapon(menuCharacter,1)) "Weapon equipped" else "Weapon unavailable") }
                else { menuEquipId=2; say(if(NativeGame.equipArmor(menuCharacter,2)) "Armor equipped" else "Armor unavailable") }
            }
        }
        if (y>height-50) NativeGame.closeMenu()
    }
}
