package com.example.ff1android

object NativeGame {
    init { System.loadLibrary("ff1core") }
    external fun init(); external fun update(); external fun move(dx:Int,dy:Int)
    external fun getX():Int; external fun getY():Int; external fun getGil():Int
    external fun getGameMode():Int; external fun getMenuState():Int
    external fun getPartyHp(i:Int):Int; external fun getPartyMaxHp(i:Int):Int
    external fun getPartyLevel(i:Int):Int; external fun getPartyName(i:Int):String; external fun getPartyJob(i:Int):String; external fun getPartyAttack(i:Int):Int; external fun getPartyDefense(i:Int):Int; external fun getPartyWeapon(i:Int):Int; external fun getPartyArmor(i:Int):Int; external fun getPartyXp(i:Int):Int; external fun partyMp(i:Int):Int; external fun partyMaxMp(i:Int):Int; external fun spellMpCost(id:Int):Int; external fun spellPower(id:Int):Int; external fun spellIsHealing(id:Int):Boolean
    external fun getItemCount(id:Int):Int; external fun livingPartyCount():Int
    external fun startBattle(seed:Int); external fun selectBattleActor(i:Int); external fun selectBattleEnemy(i:Int)
    external fun getBattleState():Int; external fun getBattleActor():Int; external fun getSelectedEnemy():Int
    external fun battleFxType():Int; external fun battleFxValue():Int; external fun battleFxTarget():Int; external fun battleFxText():String
    external fun battleRewardExp():Int; external fun battleRewardGil():Int; external fun clearBattleFx(); external fun rewardLevelUps():Int; external fun rewardCharacterXp(i:Int):Int; external fun rewardCharacterLevels(i:Int):Int; external fun rewardPending():Boolean; external fun clearReward()
    external fun getEnemyHp(i:Int):Int; external fun getEnemyName(i:Int):String
    external fun attack():Int; external fun battleUseItem(i:Int):Int; external fun battleCommandMagic(caster:Int,spellId:Int,target:Int):Int; external fun runBattle():Boolean
    external fun openMenu(); external fun closeMenu(); external fun menuNext(); external fun menuPrevious(); external fun menuSelect(i:Int)
    external fun useItem(i:Int,id:Int):Boolean; external fun equipWeapon(i:Int,id:Int):Boolean; external fun equipArmor(i:Int,id:Int):Boolean
    external fun interact():Boolean; external fun npcMessage():String; external fun save(path:String):Boolean; external fun load(path:String):Boolean
}
// Step 24 exploration integration
