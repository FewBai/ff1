#pragma once
#include "ff1_types.h"
#include "data_tables.h"
#include <cstdint>

namespace ff1 {

Battle makeBattleFromFormation(uint8_t formationId, const SaveData& save);

} // namespace ff1
