#include "battle_formations.h"

namespace ff1 {

Battle makeBattleFromFormation(uint8_t formationId, const SaveData& save) {
    Battle b{};
    b.state = BattleState::PlayerCommand;

    for (int i = 0; i < 4; ++i) {
        const auto& p = save.party[i];
        b.party[i] = {
            p.name,
            p.stats.hp,
            p.stats.maxHp,
            p.stats.attack,
            p.stats.defense,
            p.alive
        };
    }

    const auto& f = kEncounters[formationId % kEncounters.size()];
    b.enemyCount = f.count;

    for (int i = 0; i < f.count; ++i) {
        const EnemyData* e = findEnemy(f.enemyIds[i]);
        if (!e) continue;
        b.enemies[i] = {
            std::string(e->name),
            e->hp,
            e->hp,
            e->damage,
            e->absorb,
            true
        };
        b.gilReward += e->gil;
        b.expReward += e->exp;
    }
    return b;
}

} // namespace ff1
