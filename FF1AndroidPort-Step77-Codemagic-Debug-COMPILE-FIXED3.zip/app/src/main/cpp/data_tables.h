#pragma once
#include <array>
#include <cstdint>
#include <string_view>

namespace ff1 {

struct WeaponData {
    uint8_t id;
    std::string_view name;
    uint16_t price;
    uint8_t damage;
    uint8_t hit;
};

struct ArmorData {
    uint8_t id;
    std::string_view name;
    uint16_t price;
    uint8_t absorb;
};

struct EnemyData {
    uint8_t id;
    std::string_view name;
    uint16_t hp;
    uint8_t absorb;
    uint8_t damage;
    uint8_t hit;
    uint16_t exp;
    uint16_t gil;
};

struct EncounterGroup {
    uint8_t id;
    std::array<uint8_t, 4> enemyIds{};
    uint8_t count;
};

extern const std::array<WeaponData, 4> kWeapons;
extern const std::array<ArmorData, 4> kArmors;
extern const std::array<EnemyData, 4> kEnemies;
extern const std::array<EncounterGroup, 2> kEncounters;

const EnemyData* findEnemy(uint8_t id);

} // namespace ff1
