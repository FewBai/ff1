#pragma once
#include "ff1_types.h"
#include <cstdint>
#include <vector>

namespace ff1 {

/*
 * Adapter for the documented NES map-data formats.
 *
 * This layer intentionally does not embed proprietary ROM bytes. It accepts
 * decoded tile/collision data and converts it into the runtime TileMap.
 */
struct DecodedMap {
    int id = 0;
    int width = 0;
    int height = 0;
    std::vector<uint8_t> tiles;
    std::vector<uint8_t> collision;
};

bool validateMap(const DecodedMap& map);
TileMap makeRuntimeMap(const DecodedMap& map);

} // namespace ff1
