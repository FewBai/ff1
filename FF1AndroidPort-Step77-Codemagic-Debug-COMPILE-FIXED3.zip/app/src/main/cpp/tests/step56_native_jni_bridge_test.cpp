#include "../graphics/debug_overlay_native_api.h"
#include <cassert>
int main(){
    ff1_debug_set_enabled(true);
    ff1_debug_begin_frame();
    ff1_debug_record_draw();
    ff1_debug_record_cache_hit();
    ff1_debug_record_cache_miss();
    ff1_debug_record_missing_tile();
    ff1_debug_set_tiles(10,12);
    ff1_debug_set_memory(1024*1024,512*1024);
    ff1_debug_end_frame(20.0);

    assert(ff1_debug_is_enabled());
    assert(ff1_debug_draw_calls()==1);
    assert(ff1_debug_cache_hits()==1);
    assert(ff1_debug_cache_misses()==1);
    assert(ff1_debug_missing_tiles()==1);
    assert(ff1_debug_visible_tiles()==10);
    assert(ff1_debug_submitted_tiles()==12);
    assert(ff1_debug_cache_bytes()==1024*1024);
    assert(ff1_debug_atlas_bytes()==512*1024);
    assert(ff1_debug_over_budget());

    ff1_debug_set_enabled(false);
    assert(!ff1_debug_is_enabled());
    return 0;
}
