#include "../graphics/sprite_manager.h"
#include "../graphics/animation_player.h"
#include "../graphics/render_actor.h"
#include "../graphics/effect_animation.h"
#include <cassert>
#include <vector>

int main() {
    ff1::SpriteManager manager;

    ff1::SpriteAnimation walk;
    walk.id = 1;
    walk.name = "walk";
    walk.loop = true;
    walk.frames = {
        {10, 16, 16, 100},
        {11, 16, 16, 100},
        {12, 16, 16, 100}
    };
    assert(manager.registerAnimation(walk));

    std::vector<uint8_t> rgba(16 * 16 * 4, 255);
    assert(manager.registerResource(10, rgba, 16, 16));

    ff1::AnimationPlayer player;
    player.setAnimation(manager, 1);
    assert(player.frameIndex() == 0);
    player.update(100, manager);
    assert(player.frameIndex() == 1);
    player.update(200, manager);
    assert(player.frameIndex() == 0);

    ff1::RenderActorSystem actors;
    actors.add({7, ff1::RenderActorType::Player, {}, "Hero"});
    assert(actors.setAnimation(7, manager, 1));
    actors.update(100, manager);
    assert(actors.frameIndex(7) == 1);

    return 0;
}
