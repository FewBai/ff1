#include "../gameplay/exploration_runtime.h"
#include <cassert>
int main(){
    ff1::ExplorationRuntime r; r.reset(); ff1::SaveData s; s.playerX=2;s.playerY=2;s.gil=0; ff1::Inventory inv; std::string msg;
    assert(r.move(s,1,0)); assert(s.mapId==100);
    s.playerX=4;s.playerY=4; assert(r.interact(s,inv,msg)); assert(r.chestOpened()); assert(s.gil==100); assert(inv.count(0x20)==2);
    s.playerX=8;s.playerY=4; assert(r.interact(s,inv,msg)); assert(msg.find("Welcome")!=std::string::npos);
    r.clearEncounter(); s.playerX=2;s.playerY=2; bool trig=false; for(int i=0;i<4;++i){r.move(s,1,0); trig|=r.encounterTriggered(); r.clearEncounter();} assert(trig);
    return 0;
}
