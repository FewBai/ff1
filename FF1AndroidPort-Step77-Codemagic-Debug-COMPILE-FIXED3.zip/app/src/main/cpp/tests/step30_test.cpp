#include "../gameplay/character_menu.h"
#include <cassert>
int main(){
    ff1::PartySystem p; p.reset();
    auto s=ff1::CharacterMenu::snapshot(p,0);
    assert(s.index==0 && s.level==1 && s.maxHp>0);
    assert(s.job=="Fighter");
    assert(ff1::CharacterMenu::canEquip(p.at(0),0,0));
    p.at(2).job=ff1::CharacterClass::BlackBelt;
    assert(!ff1::CharacterMenu::canEquip(p.at(2),1,0));
    return 0;
}
