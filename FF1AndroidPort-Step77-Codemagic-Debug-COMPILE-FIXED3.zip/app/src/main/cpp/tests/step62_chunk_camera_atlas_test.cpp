#include "../graphics/atlas_crop_renderer.h"
#include <cassert>
struct Bitmap{};
struct Canvas{int draws=0;ff1::RectF src{},dst{};void drawBitmap(const Bitmap&,ff1::RectF s,ff1::RectF d){++draws;src=s;dst=d;}};
struct Provider{Bitmap b;Bitmap*lookup(int id){return id==7?&b:nullptr;}};
int main(){
 ff1::DebugRuntimeBridge d; ff1::CanvasAtlasRenderer r(d); ff1::AtlasCropRenderer a(r);
 ff1::ChunkTile t[]={{7,32,16,16,16,100,50,16,16},{99,0,0,16,16,120,50,16,16}};
 ff1::VisibleChunk c{t,2};ff1::Camera cam{92,42,2};Provider p;Canvas cv;
 r.beginFrame();auto n=a.renderChunk(cv,c,cam,p);r.setVisibleTiles(2,2);r.endFrame(16);
 auto&s=d.overlay().stats();
 assert(n==1&&cv.draws==1);assert(cv.src.left==32&&cv.src.top==16&&cv.src.right==48&&cv.src.bottom==32);
 assert(cv.dst.left==16&&cv.dst.top==16&&cv.dst.right==48&&cv.dst.bottom==48);
 assert(s.drawCalls==1&&s.cacheHits==1&&s.cacheMisses==1&&s.missingTileIds==1);return 0;
}
