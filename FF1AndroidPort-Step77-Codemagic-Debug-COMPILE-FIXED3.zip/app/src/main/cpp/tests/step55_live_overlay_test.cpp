#include "../graphics/debug_overlay_bridge.h"
#include <cassert>
int main(){
    ff1::DebugOverlayBridge b;
    b.beginFrame();
    b.recordDrawCall(); b.recordDrawCall();
    b.recordCacheHit(); b.recordCacheMiss(); b.recordMissingTile();
    b.setTileCounts(80,96);
    b.endFrame(20.0);
    const auto& s=b.stats();
    assert(s.drawCalls==2 && s.cacheHits==1 && s.cacheMisses==1);
    assert(s.missingTileIds==1 && s.visibleTiles==80 && s.submittedTiles==96);
    assert(s.overBudget);
    b.beginFrame(); b.endFrame(10.0);
    assert(b.stats().frameMs==10.0);
    return 0;
}
