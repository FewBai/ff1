#include "../gameplay/battle_turn_executor.h"
#include <cassert>
int main() {
    ff1::PartySystem party; party.reset();
    ff1::BattleTurns turns; turns.reset();
    for (int i=0;i<4;++i) assert(turns.setCommand(i,ff1::BattleCommand::Attack,0));
    ff1::BattleTurnExecutor exec; exec.reset();
    std::array<ff1::EnemyActor,4> enemies{};
    enemies[0].hp=10; enemies[0].defense=0;
    for(int i=1;i<4;++i) enemies[i].alive=false;
    exec.setEnemies(enemies);
    assert(exec.execute(turns,party));
    assert(exec.phase()==ff1::BattlePhase::Victory || exec.phase()==ff1::BattlePhase::Input);
    assert(!exec.presentation().log().empty());
    assert(!exec.presentation().damage().empty());
    return 0;
}
