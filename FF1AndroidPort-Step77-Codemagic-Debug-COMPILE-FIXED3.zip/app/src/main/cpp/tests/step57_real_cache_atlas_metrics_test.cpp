#include "../graphics/debug_runtime_bridge.h"
#include <cassert>
int main(){
    ff1::DebugRuntimeBridge r;
    r.memory().bitmapLoaded(1024*1024);
    r.memory().bitmapLoaded(512*1024);
    r.memory().atlasBytes(256*1024);
    r.memory().atlasRegionAdded();
    r.memory().atlasRegionAdded();
    auto m=r.memory().snapshot();
    assert(m.bitmapCacheBytes==1536*1024 && m.bitmapCacheEntries==2);
    assert(m.atlasBytes==256*1024 && m.atlasRegions==2);
    r.memory().bitmapEvicted(512*1024);
    m=r.memory().snapshot();
    assert(m.bitmapCacheBytes==1024*1024 && m.bitmapCacheEntries==1);
    return 0;
}
