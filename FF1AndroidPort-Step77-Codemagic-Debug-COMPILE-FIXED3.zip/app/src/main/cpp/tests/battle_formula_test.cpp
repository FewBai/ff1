#include "../gameplay/battle_formula.h"
#include <cassert>

int main() {
    auto normal = ff1::BattleFormula::physical({10, 4, false, true});
    assert(normal.hit);
    assert(normal.damage == 6);

    auto crit = ff1::BattleFormula::physical({10, 4, true, true});
    assert(crit.critical);
    assert(crit.damage > normal.damage);

    auto miss = ff1::BattleFormula::physical({10, 4, false, false});
    assert(!miss.hit);
    assert(miss.damage == 0);
    return 0;
}
