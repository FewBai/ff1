#include "../gameplay/reward_system.h"
#include <cassert>
int main(){
 ff1::PartySystem p; p.reset(); int gil=100;
 auto r=ff1::RewardSystem::apply({80,25},p,gil);
 assert(gil==125); assert(r.totalXp==320); assert(r.totalGil==25);
 for(int i=0;i<4;++i) assert(r.characterXp[i]==80);
 assert(r.levelUps>=4); assert(p.at(0).level>=2); assert(p.at(0).hp==p.at(0).maxHp);
 return 0;
}
