#include "../graphics/android_resource_bridge.h"
#include <cassert>

int main() {
    ff1::AndroidResourceBridge bridge;
    bridge.update({0,0,512,512}, 1, 0);

    assert(bridge.pending() > 0);

    ff1::AndroidResourceRequest req{};
    assert(bridge.poll(req));
    assert(req.priority == static_cast<int>(ff1::ResourcePriority::Visible));

    size_t count = 1;
    while (bridge.poll(req)) ++count;
    assert(count >= 4);

    bridge.clear();
    assert(bridge.pending() == 0);
    return 0;
}
