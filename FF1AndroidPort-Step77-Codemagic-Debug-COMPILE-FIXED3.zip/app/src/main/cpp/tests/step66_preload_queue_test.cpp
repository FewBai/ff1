#include "../graphics/background_preload_worker.h"
#include <cassert>
#include <vector>
int main(){
 ff1::PreloadQueue q(2);assert(q.request(7));assert(!q.request(7));assert(q.request(8));assert(!q.request(8));
 int id;assert(q.pop(id)&&id==7);assert(!q.request(7));
 std::vector<int> decoded;ff1::BackgroundPreloadWorker w;
 size_t n=w.drain(q,[&](int x){decoded.push_back(x);},[&](int){},2);
 assert(n==1&&decoded.size()==1&&decoded[0]==8);assert(q.resident(8));assert(!q.request(8));
 assert(q.request(9)&&q.request(10));assert(q.size()==2);
 assert(q.request(11)); assert(q.size()==2); return 0;
}
