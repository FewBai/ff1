#include "../graphics/debug_runtime_bridge.h"
#include "../graphics/bitmap_cache_debug.h"
#include "../graphics/texture_atlas_debug.h"
#include "../graphics/debug_render_frame.h"
#include <cassert>
#include <thread>
#include <chrono>
int main(){
    ff1::DebugRuntimeBridge runtime;
    ff1::BitmapCacheDebug cache(&runtime.memory());
    ff1::TextureAtlasDebug atlas(&runtime.memory());

    {
        ff1::DebugRenderFrame frame(runtime);
        cache.onDecodeSuccess(2*1024*1024);
        atlas.setStorageBytes(1024*1024);
        atlas.onRegionAdded();
        frame.recordDraw();
        frame.recordCacheHit();
        frame.setTiles(64,80);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    const auto& s=runtime.overlay().stats();
    assert(s.drawCalls==1);
    assert(s.cacheHits==1);
    assert(s.cacheBytes==2*1024*1024);
    assert(s.atlasBytes==1024*1024);
    assert(s.visibleTiles==64 && s.submittedTiles==80);
    assert(s.frameMs>0.0);
    return 0;
}
