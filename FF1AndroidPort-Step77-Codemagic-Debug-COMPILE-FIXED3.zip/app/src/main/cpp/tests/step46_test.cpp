#include "../graphics/canvas_atlas_renderer.h"
#include "../graphics/android_canvas_bridge.h"
#include <cassert>
int main(){
 ff1::TextureAtlas atlas;
 assert(atlas.define(7,32,48,16,24));
 ff1::CanvasAtlasRenderer r;
 r.setAtlas(100,std::move(atlas));
 r.setCamera({100,200,356,456});
 ff1::SpriteDraw s{100,7,120,230,32,48};
 ff1::CanvasDrawCommand c;
 assert(r.buildCommand(s,c));
 assert(c.screenX==20 && c.screenY==30);
 assert(c.src.x==32 && c.src.height==24);
 ff1::AndroidCanvasBridge b; b.setRenderer(std::move(r));
 size_t drawn=0;
 assert(b.render({s},[](int id){return id==100;},[&](const ff1::CanvasDrawCommand&x){++drawn;assert(x.screenX==20);})==1);
 assert(drawn==1);
 assert(b.render({s},[](int){return false;},[](const ff1::CanvasDrawCommand&){})==0);
 return 0;
}
