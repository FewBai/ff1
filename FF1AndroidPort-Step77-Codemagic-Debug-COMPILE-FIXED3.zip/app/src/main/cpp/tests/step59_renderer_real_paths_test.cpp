#include "../graphics/debug_runtime_bridge.h"
#include "../graphics/canvas_atlas_renderer_debug.h"
#include "../graphics/canvas_draw_debug.h"
#include <cassert>
#include <map>
#include <string>
struct FakeBitmap{};
struct FakeCanvas { int draws=0; void drawBitmap(const FakeBitmap&,float,float){++draws;} };
struct FakeCache {
    std::map<std::string,FakeBitmap> m{{"grass",FakeBitmap{}}};
    FakeBitmap* find(const std::string& k){ auto i=m.find(k); return i==m.end()?nullptr:&i->second; }
};
int main(){
    ff1::DebugRuntimeBridge runtime;
    ff1::CanvasAtlasRendererDebug renderer(runtime);
    FakeCache cache; FakeCanvas canvas; FakeBitmap bitmap;
    renderer.beginFrame();
    auto a=cache.find("grass");
    if(a) renderer.recordCacheHit(); else renderer.recordCacheMiss();
    auto b=cache.find("missing");
    if(b) renderer.recordCacheHit(); else renderer.recordCacheMiss();
    ff1::CanvasDrawDebug draw(runtime);
    draw.drawBitmap(canvas,bitmap,10,20);
    draw.drawBitmap(canvas,bitmap,26,20);
    renderer.setTiles(80,96);
    renderer.endFrame();
    const auto& s=runtime.overlay().stats();
    assert(canvas.draws==2);
    assert(s.drawCalls==2);
    assert(s.cacheHits==1 && s.cacheMisses==1);
    assert(s.visibleTiles==80 && s.submittedTiles==96);
    assert(s.frameMs>=0.0);
    return 0;
}
