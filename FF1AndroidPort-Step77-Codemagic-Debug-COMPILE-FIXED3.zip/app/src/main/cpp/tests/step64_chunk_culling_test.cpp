#include "../graphics/chunk_render_loop.h"
#include <cassert>
struct Bitmap{};
struct Canvas{int draws=0;void drawBitmap(const Bitmap&,ff1::RectF,ff1::RectF){++draws;}};
struct Provider{Bitmap b;Bitmap*lookup(int id){return id==7?&b:nullptr;}};
int main(){
 ff1::DebugRuntimeBridge d;ff1::CanvasAtlasRenderer r(d);ff1::AtlasCropRenderer a(r);ff1::CulledAtlasRenderer ca(a);ff1::ChunkRenderLoop loop(ca);
 ff1::ChunkTile in[]={{7,0,0,16,16,8,8,16,16}};ff1::ChunkTile out[]={{7,0,0,16,16,200,200,16,16}};
 std::vector<ff1::ChunkRef> chunks={
  {{1,0,0,32,32},{in,1}},{{2,200,200,32,32},{out,1}}};
 Provider p;Canvas cv;size_t v=0,s=0;r.beginFrame();auto n=loop.render(cv,chunks,{0,0,1},64,64,p,v,s);r.setVisibleTiles(v,s);r.endFrame(16);
 auto&st=d.overlay().stats();assert(n==1&&cv.draws==1&&v==1&&s==1);assert(st.drawCalls==1&&st.visibleTiles==1);return 0;
}
