#include "../gameplay/scene_transition.h"
#include "../gameplay/map_transition.h"
#include <cassert>
int main(){ff1::SceneTransition s; ff1::SceneState a{},b{}; b.mapId=2;b.x=3;b.y=4;s.start(a,b); for(int i=0;i<10 && s.active();++i)s.tick(); assert(s.target().mapId==2); assert(s.phase()==ff1::TransitionPhase::None || s.phase()==ff1::TransitionPhase::FadeIn); ff1::MapTransitionSystem m;m.add({1,5,5,2,1,1});int om,ox,oy;assert(m.tryWarp(1,5,5,om,ox,oy));assert(om==2&&ox==1&&oy==1);return 0;}
