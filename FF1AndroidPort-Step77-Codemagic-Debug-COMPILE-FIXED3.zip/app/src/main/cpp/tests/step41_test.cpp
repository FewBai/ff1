#include "../graphics/texture_atlas.h"
#include "../graphics/resource_cache.h"
#include "../graphics/async_resource_queue.h"
#include <cassert>
int main(){
 ff1::TextureAtlas a; assert(a.define(1,0,0,16,16)); assert(a.region(1)->width==16);
 ff1::ResourceCache c(128);
 assert(c.put({1,4,4,std::vector<uint8_t>(64,1)}));
 assert(c.put({2,4,4,std::vector<uint8_t>(64,2)}));
 assert(c.bytesUsed()<=128);
 assert(c.put({3,4,4,std::vector<uint8_t>(64,3)}));
 assert(c.bytesUsed()<=128);
 ff1::AsyncResourceQueue q;
 q.enqueue({4,2,2,std::vector<uint8_t>(16,7)});
 auto loader=[](const ff1::ResourceRequest&r,ff1::CachedBitmap&o){o={r.id,r.width,r.height,r.rgba};return true;};
 assert(q.pump(c,loader,1)==1); assert(c.contains(4));
 return 0;
}
