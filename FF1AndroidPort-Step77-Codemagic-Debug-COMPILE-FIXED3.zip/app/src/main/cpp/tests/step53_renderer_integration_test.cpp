#include "../graphics/step52_map_renderer.h"
#include "../graphics/tile_map_render_loop.h"
#include "../graphics/map_tile_data.h"
#include "../graphics/tile_atlas_mapper.h"
#include "../graphics/texture_atlas.h"
#include "../graphics/canvas_atlas_renderer.h"
#include <cassert>

int main() {
    ff1::MapTileGrid grid(2, 1);
    grid.at(0, 0).tileId = 10;
    grid.at(1, 0).tileId = 20;

    ff1::TileAtlasMapper mapper;
    mapper.set(10, 1);
    mapper.set(20, 2);

    ff1::TextureAtlas atlas;
    assert(atlas.define(1, 0, 0, 16, 16));
    assert(atlas.define(2, 16, 0, 16, 16));

    ff1::CanvasAtlasRenderer renderer;
    renderer.setAtlas(100, std::move(atlas));
    renderer.setCamera({0, 0, 32, 16});

    ff1::TileMapRenderLoop loop;
    loop.setRenderer(renderer);

    ff1::RenderPass entities;
    entities.add({
        ff1::RenderPassLayer::Actor,
        0,
        {100, 1, 8, 0, 16, 16}
    });

    ff1::Step52MapRenderer mapRenderer(grid, mapper, 16, 16, 100);

    int drawCalls = 0;
    int mapAtlasX1 = -1;
    int mapAtlasX2 = -1;

    auto result = mapRenderer.render(
        {0, 0, 32, 16},
        loop,
        entities,
        [](int resourceId) { return resourceId == 100; },
        [&](const ff1::CanvasDrawCommand& command) {
            ++drawCalls;
            if (command.screenX == 0) mapAtlasX1 = command.src.x;
            if (command.screenX == 16) mapAtlasX2 = command.src.x;
        },
        16,
        16);

    assert(result.missingTileIds == 0);
    assert(result.tiles.submitted == 2);
    assert(result.tiles.visible == 2);
    assert(result.tiles.drawn == 2);
    assert(result.tiles.cacheMisses == 0);

    // Two map tiles plus one actor are emitted through the SAME loop-owned renderer.
    assert(drawCalls == 3);
    assert(mapAtlasX1 == 0);
    assert(mapAtlasX2 == 16);

    return 0;
}
