#include "../graphics/map_chunk_manager.h"
#include "../graphics/chunk_tile_batch_builder.h"
#include "../graphics/entity_interpolator.h"
#include "../graphics/frame_time_telemetry.h"
#include <cassert>
#include <cmath>

int main() {
    ff1::MapChunkManager chunks(64, 64);
    ff1::ResourcePriorityQueue requests;
    chunks.updateInterest({0, 0, 64, 64}, 0, 0, requests);

    assert(chunks.isActive({0,0}));

    ff1::ChunkTileBatchBuilder builder({
        16, 16, 4, 4, 100, 1
    });
    ff1::TileBatchRenderer tiles;
    builder.build(chunks, {0,0,64,64}, tiles);

    // Four-by-four tiles in the active chunk.
    assert(tiles.tiles().size() == 16);

    ff1::EntityInterpolator player;
    player.snap(0.0f, 0.0f);
    player.setTarget(32.0f, 0.0f);
    auto p = player.update(0.5f, 32.0f);
    assert(std::fabs(p.x - 16.0f) < 0.01f);

    p = player.update(1.0f, 32.0f);
    assert(std::fabs(p.x - 32.0f) < 0.01f);

    ff1::FrameTimeTelemetry telemetry;
    telemetry.record(10.0);
    telemetry.record(20.0);
    assert(telemetry.frameCount == 2);
    assert(telemetry.overBudgetFrames == 1);
    assert(telemetry.worstMs == 20.0);

    return 0;
}
