#include "../graphics/camera_resource_controller.h"
#include "../graphics/jni_resource_bridge.h"
#include <cassert>

int main() {
    ff1::CameraResourceController controller;
    controller.update(0, 0, 512, 512, 1, 0);

    ff1::JniResourceBridge bridge(controller.bridge());
    size_t visible = 0;
    size_t prefetch = 0;

    const size_t sent = bridge.dispatch(
        [&](int, int priority) {
            if (priority == static_cast<int>(ff1::ResourcePriority::Visible))
                ++visible;
            if (priority == static_cast<int>(ff1::ResourcePriority::Prefetch))
                ++prefetch;
        }, 1024);

    assert(sent > 0);
    assert(visible >= 4);
    assert(prefetch > 0);
    return 0;
}
