#include "../graphics/preload_publication.h"
#include <cassert>
int main(){
 ff1::DebugRuntimeBridge d;ff1::BitmapCacheStore c;ff1::PreloadPublication p(c,d);
 assert(!c.ready(7));assert(p.publishDecoded(7,4096));assert(c.ready(7));
 assert(c.contains(7)&&c.bytes()==4096);assert(p.publishDecoded(8,2048));
 assert(c.size()==2&&c.bytes()==6144);return 0;
}
