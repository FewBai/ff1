#include "../graphics/game_frame_pipeline.h"
#include <cassert>
#include <vector>

int main() {
    ff1::TextureAtlas atlas;
    assert(atlas.define(1, 0, 0, 16, 16));

    ff1::CanvasAtlasRenderer renderer;
    renderer.setAtlas(100, std::move(atlas));

    ff1::GameFramePipeline pipeline;
    pipeline.setRenderer(std::move(renderer));

    std::vector<ff1::SpriteDraw> sprites{
        {100, 1, 20, 30, 16, 16}
    };

    int requested = 0;
    int drawn = 0;

    auto frame1 = pipeline.renderFrame(
        {0,0,320,240}, 1, 0, sprites,
        [&](int, int) { ++requested; return false; },
        [&](const ff1::CanvasDrawCommand&) { ++drawn; });

    assert(frame1.requested > 0);
    assert(frame1.drawn == 0);
    assert(drawn == 0);

    // Simulate a cache hit on the next frame.
    auto frame2 = pipeline.renderFrame(
        {0,0,320,240}, 0, 0, sprites,
        [&](int, int) { return true; },
        [&](const ff1::CanvasDrawCommand&) { ++drawn; });

    assert(frame2.requested > 0);
    assert(frame2.drawn == 1);
    assert(drawn == 1);

    return 0;
}
