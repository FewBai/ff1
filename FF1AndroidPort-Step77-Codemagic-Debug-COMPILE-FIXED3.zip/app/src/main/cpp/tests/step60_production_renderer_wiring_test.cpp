#include "../graphics/canvas_atlas_renderer.h"
#include <cassert>
struct Bitmap{};
struct Canvas { int draws=0; void drawBitmap(const Bitmap&,float,float){++draws;} };
int main(){
    ff1::DebugRuntimeBridge debug;
    ff1::CanvasAtlasRenderer renderer(debug);
    Canvas canvas; Bitmap bitmap;
    renderer.beginFrame();
    renderer.cacheHit();
    renderer.drawBitmap(canvas,bitmap,10,10);
    renderer.drawBitmap(canvas,bitmap,26,10);
    renderer.cacheMiss();
    renderer.missingTile();
    renderer.setVisibleTiles(32,40);
    renderer.endFrame(12.5);
    const auto& s=debug.overlay().stats();
    assert(canvas.draws==2);
    assert(s.drawCalls==2 && s.cacheHits==1 && s.cacheMisses==1);
    assert(s.missingTileIds==1 && s.visibleTiles==32 && s.submittedTiles==40);
    assert(s.frameMs==12.5);
    return 0;
}
