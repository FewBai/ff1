#include "../graphics/canvas_scene.h"
#include <cassert>

int main() {
    ff1::CanvasScene scene;

    ff1::CanvasActorState player;
    player.actorId = 1;
    player.worldX = 48;
    player.worldY = 64;
    player.direction = ff1::Direction::Right;
    player.moving = true;
    player.animationId = ff1::CanvasScene::animationFor(
        player.direction, player.moving);
    scene.setActor(player);

    assert(scene.actors().size() == 1);
    assert(scene.actors()[0].animationId == 121);
    assert(ff1::CanvasScene::animationFor(
        ff1::Direction::Up, false) == 130);
    assert(ff1::CanvasScene::animationFor(
        ff1::Direction::Down, true, true) == 900);

    return 0;
}
