#include "../graphics/culled_atlas_renderer.h"
#include <cassert>
struct Bitmap{};
struct Canvas{int draws=0;void drawBitmap(const Bitmap&,ff1::RectF,ff1::RectF){++draws;}};
struct Provider{Bitmap b;Bitmap*lookup(int id){return id==7?&b:nullptr;}};
int main(){
 ff1::DebugRuntimeBridge d;ff1::CanvasAtlasRenderer r(d);ff1::AtlasCropRenderer a(r);ff1::CulledAtlasRenderer c(a);
 ff1::ChunkTile t[]={{7,0,0,16,16,0,0,16,16},{7,0,0,16,16,100,0,16,16},{99,0,0,16,16,8,8,16,16}};
 ff1::VisibleChunk chunk{t,3};ff1::Camera cam{0,0,1};Provider p;Canvas cv;size_t visible=0,submitted=0;
 r.beginFrame();c.render(cv,chunk,cam,32,32,p,visible,submitted);r.setVisibleTiles(visible,submitted);r.endFrame(16);
 auto&s=d.overlay().stats();
 assert(visible==2&&submitted==2&&cv.draws==1);
 assert(s.drawCalls==1&&s.cacheHits==1&&s.cacheMisses==1&&s.missingTileIds==1);
 assert(s.visibleTiles==2&&s.submittedTiles==2);return 0;
}
