#include "../game_engine.h"
#include "../gameplay/character_menu.h"
#include <cassert>
int main(){
    ff1::GameEngine e; e.reset();
    assert(e.state().save.party[0].name.size() > 0);
    assert(e.partyAttack(0) >= 0 && e.partyDefense(0) >= 0);
    e.openMenu();
    e.menuSelect(1); assert(e.state().menu==ff1::MenuState::Status);
    e.menuSelect(2); assert(e.state().menu==ff1::MenuState::Items);
    e.menuSelect(3); assert(e.state().menu==ff1::MenuState::Magic);
    e.menuSelect(4); assert(e.state().menu==ff1::MenuState::Equipment);
    e.closeMenu();
    assert(ff1::CharacterMenu::canEquip(e.party().at(0),0,0));
    return 0;
}
