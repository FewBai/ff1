#include "../game_engine.h"
#include <cassert>
#include <cstdio>
#include <string>
int main(){
 ff1::GameEngine g; assert(g.state().save.mapId==100); assert(g.state().save.playerX==3);
 assert(g.move(1,0)); std::string msg; assert(g.interact(msg)); assert(g.chestOpened()); assert(g.state().save.gil==500); assert(g.itemCount(0x20)>=5);
 const std::string path="/tmp/ff1_step24_save.dat"; assert(g.save(path));
 ff1::GameEngine h; assert(h.load(path)); assert(h.state().save.mapId==100); assert(h.state().save.playerX==4 && h.state().save.playerY==4);
 assert(!h.interact(msg));
 std::remove(path.c_str()); return 0;
}
