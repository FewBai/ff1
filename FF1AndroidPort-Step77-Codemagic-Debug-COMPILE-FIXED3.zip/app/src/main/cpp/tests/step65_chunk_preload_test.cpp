#include "../graphics/chunk_preload.h"
#include <cassert>
#include <vector>
int main(){
 ff1::ChunkPreloader p;ff1::Camera cam{0,0,1};
 std::vector<ff1::PreloadChunk> chunks={{1,0,0,32,32},{2,80,0,32,32},{3,300,0,32,32}};
 std::vector<int> loaded;
 size_t n=p.schedule(chunks,cam,64,64,64,[&](int id){loaded.push_back(id);});
 assert(n==2);assert(loaded.size()==2&&loaded[0]==1&&loaded[1]==2);
 return 0;
}
