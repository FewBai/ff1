#include "../graphics/map_chunk_manager.h"
#include "../graphics/chunk_lifecycle.h"
#include "../graphics/resource_priority_queue.h"
#include <cassert>

int main() {
    ff1::MapChunkManager chunks(256, 256);

    assert((chunks.worldToChunk(0, 0) == ff1::ChunkCoord{0, 0}));
    assert((chunks.worldToChunk(255, 255) == ff1::ChunkCoord{0, 0}));
    assert((chunks.worldToChunk(256, 0) == ff1::ChunkCoord{1, 0}));
    assert((chunks.worldToChunk(-1, 0) == ff1::ChunkCoord{-1, 0}));

    ff1::ChunkBounds visible{0, 0, 512, 512};
    ff1::ResourcePriorityQueue queue;
    chunks.updateInterest(visible, 1, 0, queue);

    assert(chunks.active().size() == 4);
    assert(chunks.prefetch().size() > 0);

    ff1::PrioritizedResourceRequest first;
    assert(queue.pop(first));
    assert(first.priority == ff1::ResourcePriority::Visible);

    ff1::ChunkLifecycle lifecycle;
    lifecycle.sync(chunks);
    assert(lifecycle.activeCount() == 4);
    assert(lifecycle.prefetchCount() > 0);

    ff1::MapChunkManager moved(256, 256);
    moved.updateInterest({256, 0, 768, 512}, 1, 0, queue);
    lifecycle.sync(moved);

    assert(lifecycle.state({0, 0}) == ff1::ChunkState::Cold ||
           lifecycle.state({0, 0}) == ff1::ChunkState::Prefetch);
    return 0;
}
