#include "../game_engine.h"
#include <cassert>
#include <cstdio>

int main(){
    ff1::GameEngine g;
    assert(g.livingPartyCount()==4);
    const std::string path="/tmp/ff1_step14_save.dat";
    assert(g.save(path));
    int x=g.state().save.playerX,y=g.state().save.playerY,gil=g.state().save.gil;
    g.move(1,0);
    g.startBattle(1);
    g.selectBattleEnemy(0);
    for(int i=0;i<20 && g.state().mode==ff1::GameMode::Battle;++i){
        g.battleCommandAttack();
        if(g.state().battle.state==ff1::BattleState::Victory)g.update();
        else if(g.state().battle.state==ff1::BattleState::Defeat)break;
    }
    assert(g.save(path));
    assert(g.load(path));
    assert(g.state().save.gil>=gil);
    (void)x;(void)y;
    std::remove(path.c_str());
    return 0;
}
