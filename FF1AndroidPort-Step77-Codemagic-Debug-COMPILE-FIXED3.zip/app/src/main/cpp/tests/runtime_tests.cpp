#include "../gameplay/inventory.h"
#include "../gameplay/equipment_system.h"
#include "../gameplay/progression.h"
#include "../gameplay/status_system.h"
#include "../gameplay/map_transition.h"
#include "../gameplay/chest_system.h"
#include "../gameplay/party_system.h"
#include <cassert>

int main() {
    ff1::Inventory inv;
    assert(inv.add(1, 2));
    assert(inv.count(1) == 2);
    assert(inv.remove(1, 1));
    assert(inv.count(1) == 1);

    ff1::Equipment eq;
    assert(ff1::EquipmentSystem::equip(eq, 0, 1));
    assert(ff1::EquipmentSystem::attackBonus(eq.weapon) > 0);

    ff1::LevelStats level;
    assert(ff1::Progression::addXp(level, 100));
    assert(level.level > 1);

    ff1::Status status = ff1::Status::Normal;
    ff1::StatusSystem::apply(status, ff1::Status::Poison);
    assert(!ff1::StatusSystem::canAct(ff1::Status::Paralyzed));

    ff1::MapTransitionSystem maps;
    maps.add({1, 3, 4, 2, 7, 8});
    int map = 1, x = 3, y = 4;
    assert(maps.tryWarp(map, x, y, map, x, y));
    assert(map == 2 && x == 7 && y == 8);

    ff1::PartySystem party;
    party.reset();
    assert(party.livingCount() == 4);
    return 0;
}
