#include "../graphics/tile_batch_renderer.h"
#include "../graphics/render_pass.h"
#include "../graphics/tile_map_render_loop.h"
#include <cassert>
int main(){
 ff1::TextureAtlas atlas;
 assert(atlas.define(1,0,0,16,16));
 assert(atlas.define(2,16,0,16,16));
 ff1::CanvasAtlasRenderer renderer;
 renderer.setAtlas(100,std::move(atlas));
 renderer.setCamera({0,0,128,128});

 ff1::TileBatchRenderer map;
 map.add({100,1,0,0,16,16});
 map.add({100,1,16,0,16,16});
 map.add({100,1,200,200,16,16});

 int mapDraws=0;
 auto ms=map.buildVisible(renderer,[](int){return true;},
   [&](const ff1::CanvasDrawCommand&){++mapDraws;},8);
 assert(ms.submitted==3 && ms.visible==2 && ms.drawn==2 && mapDraws==2);

 ff1::RenderPass entities;
 entities.add({ff1::RenderPassLayer::Effect,0,{100,2,32,32,16,16}});
 entities.add({ff1::RenderPassLayer::Actor,0,{100,2,24,24,16,16}});
 int entityDraws=0;
 auto ec=entities.draw(renderer,[](int){return true;},
   [&](const ff1::CanvasDrawCommand&){++entityDraws;},8);
 assert(ec==2 && entityDraws==2);

 ff1::TileMapRenderLoop loop;
 loop.setRenderer(renderer);
 int total=0;
 auto fs=loop.render(map,entities,[](int){return true;},
   [&](const ff1::CanvasDrawCommand&){++total;},8,8);
 assert(fs.map.drawn==2 && fs.totalDrawn==4 && total==4);
 return 0;
}
