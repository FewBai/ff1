#include "../gameplay/data_loader.h"
#include "../gameplay/battle_turns.h"
#include <cassert>

int main() {
    ff1::WorldData world;
    assert(ff1::DataLoader::loadWorldText(
        "MAP 1 16 16\nOBJ 1 1 2 3 1 10 GUARD\nCHEST 2 1 4 5 3 1 100\n",
        world));
    assert(world.map(1));
    assert(world.objectAt(1,2,3));

    ff1::BattleTurns turns;
    turns.reset();
    for (int i=0;i<4;++i)
        assert(turns.setCommand(i, ff1::BattleCommand::Attack, i));
    assert(turns.ready());
    assert(turns.command(2).target == 2);
    return 0;
}
