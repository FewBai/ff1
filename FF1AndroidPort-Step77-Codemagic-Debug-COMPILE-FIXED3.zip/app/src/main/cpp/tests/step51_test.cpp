#include "../graphics/map_tile_data.h"
#include "../graphics/map_tile_source.h"
#include "../graphics/player_collision.h"
#include "../graphics/camera_follow.h"
#include <cassert>
#include <cmath>
int main(){
    ff1::MapTileGrid grid(4,4);
    grid.at(1,0).collision=1;
    ff1::MapTileSource source(grid);
    ff1::PlayerCollision collision;
    ff1::PlayerPosition p{0,0};
    p=collision.move(p,16,0,source,16,16);
    assert(std::fabs(p.x-0.0f)<0.01f);
    p=collision.move(p,0,16,source,16,16);
    assert(std::fabs(p.y-16.0f)<0.01f);

    ff1::CameraFollow camera;
    camera.setDeadZone(10,10,30,30);
    auto c=camera.update(0,0,50,20);
    assert(std::fabs(c.x-20)<0.01f);
    assert(std::fabs(c.y)<0.01f);

    ff1::MapTile t;
    assert(source.tileAtWorld(16,0,16,16,t));
    assert(t.collision==1);
    return 0;
}
