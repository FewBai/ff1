#include "../graphics/map_tile_data.h"
#include "../graphics/tile_atlas_mapper.h"
#include "../graphics/real_tile_batch_builder.h"
#include "../graphics/texture_atlas.h"
#include "../graphics/canvas_atlas_renderer.h"
#include <cassert>

int main(){
    ff1::MapTileGrid grid(3,2);
    grid.at(0,0).tileId=10;
    grid.at(1,0).tileId=20;
    grid.at(2,0).tileId=10;
    grid.at(0,1).tileId=30;
    grid.at(1,1).tileId=20;
    grid.at(2,1).tileId=999;

    ff1::TileAtlasMapper mapper;
    mapper.set(10,1);
    mapper.set(20,2);
    mapper.set(30,3);

    ff1::RealTileBatchBuilder builder(grid,mapper,16,16,100);
    ff1::TileBatchRenderer batch;
    int missing=0;
    builder.build({0,0,48,32},batch,&missing);

    assert(batch.tiles().size()==5);
    assert(missing==1);
    assert(batch.tiles()[0].atlasRegionId==1);
    assert(batch.tiles()[1].atlasRegionId==2);
    assert(batch.tiles()[3].atlasRegionId==3);

    ff1::TextureAtlas atlas;
    assert(atlas.define(1,0,0,16,16));
    assert(atlas.define(2,16,0,16,16));
    assert(atlas.define(3,32,0,16,16));

    ff1::CanvasAtlasRenderer renderer;
    renderer.setAtlas(100,std::move(atlas));
    renderer.setCamera({0,0,48,32});

    int draws=0;
    auto stats=batch.buildVisible(renderer,[](int id){return id==100;},
        [&](const ff1::CanvasDrawCommand&){++draws;},32);
    assert(stats.drawn==5);
    assert(draws==5);
    return 0;
}
