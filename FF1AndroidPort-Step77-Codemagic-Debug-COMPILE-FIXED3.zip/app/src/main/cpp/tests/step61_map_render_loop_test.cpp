#include "../graphics/map_render_loop.h"
#include <cassert>
#include <map>
struct Bitmap{};
struct Canvas{int draws=0; void drawBitmap(const Bitmap&,float,float){++draws;}};
struct Provider{
    Bitmap b;
    Bitmap* lookup(int id){return id==1?&b:nullptr;}
};
int main(){
    ff1::DebugRuntimeBridge debug;
    ff1::CanvasAtlasRenderer renderer(debug);
    ff1::MapRenderLoop loop(renderer);
    ff1::MapRenderItem items[]={{1,0,0,10,20,true},{99,0,0,30,20,false}};
    loop.setItems(items,2);
    Provider provider; Canvas canvas;
    loop.render(canvas,provider,2,2,16.0);
    const auto&s=debug.overlay().stats();
    assert(canvas.draws==1 && loop.lastDrawn()==1);
    assert(s.drawCalls==1);
    assert(s.cacheHits==1 && s.cacheMisses==1);
    assert(s.missingTileIds==1);
    assert(s.visibleTiles==2 && s.submittedTiles==2);
    assert(s.frameMs==16.0);
    return 0;
}
