#include "../gameplay/battle_actions.h"
#include "../gameplay/battle_turn_executor.h"
#include <cassert>

int main() {
    ff1::PartySystem party;
    party.reset();

    party.at(0).hp = 10;
    auto item = ff1::BattleActions::useItem(
        party, 0, 0, {0x20, 30, false});
    assert(item.executed);
    assert(party.at(0).hp == 30);

    party.at(0).mp = 5;
    std::array<ff1::EnemyActor,4> enemies{};
    enemies[0].hp = 20;
    enemies[0].defense = 0;
    for (int i = 1; i < 4; ++i) enemies[i].alive = false;

    ff1::BattlePresentation presentation;
    auto magic = ff1::BattleActions::castMagic(
        party, 0, 0, {3, false}, enemies, presentation);

    assert(magic.executed);
    assert(party.at(0).mp == 1);
    assert(enemies[0].hp < 20);
    assert(!presentation.damage().empty());

    party.at(1).hp = 5;
    party.at(1).mp = 5;
    auto heal = ff1::BattleActions::castMagic(
        party, 1, 1, {1, true}, enemies, presentation);
    assert(heal.executed);
    assert(party.at(1).hp > 5);
    assert(party.at(1).mp == 3);

    return 0;
}
