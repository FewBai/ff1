#include "../graphics/debug_overlay_controller.h"
#include <cassert>
#include <string>
int main() {
    ff1::DebugOverlayController overlay;
    overlay.update(16.666, 42, 100, 3, 1, 80, 96);
    const auto& s=overlay.stats();
    assert(s.drawCalls==42);
    assert(s.cacheHits==100);
    assert(s.cacheMisses==3);
    assert(s.missingTileIds==1);
    assert(s.visibleTiles==80);
    assert(s.submittedTiles==96);
    assert(s.fps>59.0 && s.fps<61.0);
    const std::string text=overlay.text();
    assert(text.find("FPS")!=std::string::npos);
    assert(text.find("Cache H")!=std::string::npos);
    assert(text.find("Missing")!=std::string::npos);
    overlay.setEnabled(false);
    assert(overlay.text().empty());
    return 0;
}
