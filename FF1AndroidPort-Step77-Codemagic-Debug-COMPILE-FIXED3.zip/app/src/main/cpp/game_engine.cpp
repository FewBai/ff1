#include "game_engine.h"
#include <algorithm>
#include "gameplay/spell_system.h"

namespace ff1 {

GameEngine::GameEngine(){ reset(); }

void GameEngine::reset(){
    state_=GameState{}; clearBattleFx(); battleRewardExp_=0; battleRewardGil_=0; rewardLevelUps_=0; rewardPending_=false; for(int i=0;i<4;++i){rewardCharacterXp_[i]=0;rewardCharacterLevels_[i]=0;}
    party_.reset();
    party_.at(0).equipment.weapon=1;
    party_.at(0).equipment.armor=2;
    syncPartyToSave();
    inventory_.add(0x20,3);
    syncInventoryToSave();
    map_.load(100);
    state_.save.mapId=100; state_.save.playerX=3; state_.save.playerY=4;
    exploration_.reset();
    encounter_.reset(1);
}

void GameEngine::syncPartyToSave(){ party_.toSave(state_.save.party); }
void GameEngine::syncSaveToParty(){ party_.fromSave(state_.save.party); }
void GameEngine::syncInventoryToSave(){ state_.save.inventory=inventory_.snapshotCounts(); }
void GameEngine::syncSaveToInventory(){ inventory_.restoreCounts(state_.save.inventory); }

void GameEngine::syncBattleToParty(){
    for(int i=0;i<4;++i){
        auto& c=party_.at(i); const auto& b=state_.battle.party[i];
        c.hp=b.hp; c.active=b.alive && b.hp>0;
        if(!c.active)c.status=Status::Dead;
    }
}

void GameEngine::update(){
    if(state_.mode==GameMode::Battle && state_.battle.state==BattleState::Victory){
        battleFxType_=5; battleFxValue_=state_.battle.expReward; battleFxText_="VICTORY"; battleRewardExp_=state_.battle.expReward; battleRewardGil_=state_.battle.gilReward;
        syncBattleToParty();
        auto reward = RewardSystem::apply({state_.battle.expReward,state_.battle.gilReward},party_,state_.save.gil);
        rewardLevelUps_=reward.levelUps;
        for(int i=0;i<4;++i){rewardCharacterXp_[i]=reward.characterXp[i];rewardCharacterLevels_[i]=reward.characterLevelUps[i];}
        rewardPending_=true;
        syncPartyToSave();
        syncInventoryToSave();
        state_.mode=GameMode::World;
        if(!savePath_.empty()) save(savePath_);
    }else if(state_.mode==GameMode::Battle && state_.battle.state==BattleState::Escaped){ battleFxType_=3; battleFxText_="ESCAPED";
        syncBattleToParty();
        syncPartyToSave();
        state_.mode=GameMode::World;
        if(!savePath_.empty()) save(savePath_);
    }
}

bool GameEngine::move(int dx,int dy){
    if(state_.mode!=GameMode::World&&state_.mode!=GameMode::Map)return false;
    if(state_.save.mapId==100){
        const bool moved=exploration_.move(state_.save,dx,dy);
        if(moved && exploration_.encounterTriggered()) startBattle(static_cast<uint32_t>(state_.save.playerX*31+state_.save.playerY));
        syncPartyToSave(); syncInventoryToSave();
        return moved;
    }
    const bool moved=map_.move(state_.save,dx,dy);
    if(moved)stepEncounter();
    return moved;
}

bool GameEngine::interact(std::string& message){
    if(state_.mode!=GameMode::World&&state_.mode!=GameMode::Map) return false;
    if(state_.save.mapId!=100) return false;
    bool ok=exploration_.interact(state_.save,inventory_,message);
    if(ok){ syncInventoryToSave(); }
    return ok;
}

bool GameEngine::stepEncounter(){
    if(state_.mode!=GameMode::World&&state_.mode!=GameMode::Map)return false;
    if(!encounter_.step())return false;
    startBattle(static_cast<uint32_t>(state_.save.playerX*31+state_.save.playerY));
    return true;
}

void GameEngine::startBattle(uint32_t seed){ syncPartyToSave(); battle_.start(state_.battle,state_.save,seed); state_.mode=GameMode::Battle; }
void GameEngine::selectBattleActor(int actor){ if(actor>=0&&actor<4)state_.battle.currentActor=actor; }
void GameEngine::selectBattleEnemy(int enemy){ if(enemy>=0&&enemy<state_.battle.enemyCount)state_.battle.selectedEnemy=enemy; }

int GameEngine::battleCommandAttack(){
    if(state_.mode!=GameMode::Battle)return static_cast<int>(state_.battle.state);
    int target=state_.battle.selectedEnemy; int before=state_.battle.enemies[target].hp;
    battle_.attack(state_.battle,state_.battle.currentActor,target);
    int after=state_.battle.enemies[target].hp; battleFxType_=1; battleFxValue_=before-after; battleFxTarget_=target; battleFxText_=(before-after)>0?"ATTACK":"MISS";
    if(!state_.battle.enemies[target].alive){ battleFxType_=4; battleFxText_="DEFEATED"; }
    syncBattleToParty();
    syncPartyToSave();
    return static_cast<int>(state_.battle.state);
}

int GameEngine::battleCommandItem(int partyIndex){
    if(state_.mode!=GameMode::Battle||partyIndex<0||partyIndex>=4)return static_cast<int>(state_.battle.state);
    int hp[4]{},mx[4]{};
    for(int i=0;i<4;++i){ hp[i]=state_.battle.party[i].hp; mx[i]=state_.battle.party[i].maxHp; }
    if(inventory_.usePotion(partyIndex,hp,mx)){
        int before=state_.battle.party[partyIndex].hp; state_.battle.party[partyIndex].hp=hp[partyIndex];
        battleFxType_=2; battleFxValue_=hp[partyIndex]-before; battleFxTarget_=partyIndex; battleFxText_="POTION";
        syncInventoryToSave();
        battle_.enemyTurn(state_.battle);
    }
    syncBattleToParty();
    syncPartyToSave();
    return static_cast<int>(state_.battle.state);
}

int GameEngine::battleCommandMagic(int caster, int spellId, int target){
    if(state_.mode!=GameMode::Battle || caster<0 || caster>=4 || target<0 || target>=4) return static_cast<int>(state_.battle.state);
    auto* spell = SpellSystem::find(static_cast<uint8_t>(spellId));
    if(!spell) return static_cast<int>(state_.battle.state);
    auto& c = state_.battle.party[caster];
    auto& pc = party_.at(caster);
    if(!c.alive || pc.mp < spell->mpCost) return static_cast<int>(state_.battle.state);
    pc.mp -= spell->mpCost;
    if(spell->healing){
        int before=c.hp; c.hp = std::min(c.maxHp, c.hp + static_cast<int>(spell->power));
        battleFxType_=2; battleFxValue_=c.hp-before; battleFxTarget_=caster; battleFxText_="MAGIC HEAL";
    } else {
        auto& e = state_.battle.enemies[target];
        if(!e.alive) return static_cast<int>(state_.battle.state);
        int before=e.hp; e.hp = std::max(0, e.hp - static_cast<int>(spell->power));
        battleFxType_=1; battleFxValue_=before-e.hp; battleFxTarget_=target; battleFxText_="MAGIC";
        if(e.hp==0){ e.alive=false; battleFxType_=4; battleFxText_="DEFEATED"; }
    }
    syncBattleToParty();
    syncPartyToSave();
    battle_.enemyTurn(state_.battle);
    return static_cast<int>(state_.battle.state);
}

bool GameEngine::battleRun(){
    if(state_.mode!=GameMode::Battle)return false;
    state_.battle.state=BattleState::Escaped;
    syncBattleToParty();
    syncPartyToSave();
    state_.mode=GameMode::World;
    return true;
}

void GameEngine::openMenu(){ state_.mode=GameMode::Menu; state_.menu=MenuState::Main; }
void GameEngine::closeMenu(){ state_.mode=GameMode::World; }
void GameEngine::menuNext(){ int n=static_cast<int>(state_.menu); state_.menu=static_cast<MenuState>((n+1)%6); }
void GameEngine::menuPrevious(){ int n=static_cast<int>(state_.menu); state_.menu=static_cast<MenuState>((n+5)%6); }
void GameEngine::menuSelect(int menuIndex){ if(menuIndex>=0&&menuIndex<6)state_.menu=static_cast<MenuState>(menuIndex); }

bool GameEngine::useItemOnParty(int partyIndex,uint8_t itemId){
    if(partyIndex<0||partyIndex>=4||itemId!=0x20)return false;
    syncPartyToSave();
    int hp[4]{},mx[4]{};
    for(int i=0;i<4;++i){ hp[i]=state_.save.party[i].stats.hp; mx[i]=state_.save.party[i].stats.maxHp; }
    if(!inventory_.usePotion(partyIndex,hp,mx))return false;
    state_.save.party[partyIndex].stats.hp=hp[partyIndex];
    syncSaveToParty();
    syncInventoryToSave();
    return true;
}

bool GameEngine::equipWeapon(int partyIndex,uint8_t itemId){
    if(partyIndex<0||partyIndex>=4||inventory_.count(itemId)<=0)return false;
    party_.at(partyIndex).equipment.weapon=itemId;
    syncPartyToSave();
    return true;
}

bool GameEngine::equipArmor(int partyIndex,uint8_t itemId){
    if(partyIndex<0||partyIndex>=4||inventory_.count(itemId)<=0)return false;
    party_.at(partyIndex).equipment.armor=itemId;
    syncPartyToSave();
    return true;
}

int GameEngine::partyMp(int i) const { return (i < 0 || i >= 4) ? 0 : party_.at(i).mp; }
int GameEngine::partyMaxMp(int i) const { return (i < 0 || i >= 4) ? 0 : party_.at(i).maxMp; }
int GameEngine::spellMpCost(int id) const {
    const auto* spell = SpellSystem::find(static_cast<uint8_t>(id));
    return spell ? static_cast<int>(spell->mpCost) : 0;
}
int GameEngine::spellPower(int id) const {
    const auto* spell = SpellSystem::find(static_cast<uint8_t>(id));
    return spell ? static_cast<int>(spell->power) : 0;
}
bool GameEngine::spellIsHealing(int id) const {
    const auto* spell = SpellSystem::find(static_cast<uint8_t>(id));
    return spell ? spell->healing : false;
}

int GameEngine::partyAttack(int partyIndex) const { return (partyIndex<0||partyIndex>=4)?0:party_.at(partyIndex).attack(); }
int GameEngine::partyDefense(int partyIndex) const { return (partyIndex<0||partyIndex>=4)?0:party_.at(partyIndex).defense(); }

bool GameEngine::save(const std::string&path){
    syncPartyToSave();
    if(state_.save.mapId==100) exploration_.snapshotChests(state_.save.openedChests);
    syncInventoryToSave();
    const bool ok=saveSystem_.save(state_.save,path); if(ok) savePath_=path; return ok;
}

bool GameEngine::load(const std::string&path){
    SaveData d;
    if(!saveSystem_.load(d,path))return false;
    state_.save=d;
    syncSaveToParty();
    syncSaveToInventory();
    map_.load(d.mapId);
    if(d.mapId==100) exploration_.restoreChests(d.openedChests);
    state_.mode=GameMode::World;
    savePath_=path;
    return true;
}

int GameEngine::livingPartyCount()const{return party_.livingCount();}
int GameEngine::currentBattleActor()const{return state_.battle.currentActor;}
int GameEngine::selectedBattleEnemy()const{return state_.battle.selectedEnemy;}

} // namespace ff1


void ff1::GameEngine::clearBattleFx(){battleFxType_=0;battleFxValue_=0;battleFxTarget_=0;battleFxText_.clear();}

void ff1::GameEngine::clearReward(){ rewardPending_=false; }
