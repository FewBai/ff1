#pragma once
#include "ff1_types.h"

namespace ff1 {

class MenuSystem {
public:
    void open(GameState& game);
    void close(GameState& game);
    void next(GameState& game);
    void previous(GameState& game);
    MenuState state(const GameState& game) const { return game.menu; }
};

} // namespace ff1
