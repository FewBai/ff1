#include "map_system.h"
#include <algorithm>

namespace ff1 {

void MapSystem::reset() { buildPlaceholderMap(0); }

void MapSystem::load(int mapId) {
    buildPlaceholderMap(mapId);
}

void MapSystem::buildPlaceholderMap(int mapId) {
    map_ = TileMap{};
    map_.id = mapId;
    map_.width = 32;
    map_.height = 24;
    map_.tiles.assign(map_.width * map_.height, 0);
    map_.collision.assign(map_.width * map_.height, 0);

    // Border collision plus a small deterministic obstacle pattern.
    for (int y = 0; y < map_.height; ++y) {
        for (int x = 0; x < map_.width; ++x) {
            if (x == 0 || y == 0 || x == map_.width - 1 || y == map_.height - 1)
                map_.collision[y * map_.width + x] = 1;
            if ((x == 8 && y >= 5 && y <= 17) ||
                (y == 10 && x >= 12 && x <= 22))
                map_.collision[y * map_.width + x] = 1;
        }
    }
}

bool MapSystem::blocked(int x, int y) const {
    if (x < 0 || y < 0 || x >= map_.width || y >= map_.height) return true;
    return map_.collision[y * map_.width + x] != 0;
}

bool MapSystem::move(SaveData& save, int dx, int dy) {
    const int nx = save.playerX + std::clamp(dx, -1, 1);
    const int ny = save.playerY + std::clamp(dy, -1, 1);
    if (blocked(nx, ny)) return false;
    save.playerX = nx;
    save.playerY = ny;
    return true;
}

} // namespace ff1
