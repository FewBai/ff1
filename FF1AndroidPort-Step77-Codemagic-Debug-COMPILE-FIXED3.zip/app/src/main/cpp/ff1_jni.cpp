#include <jni.h>
#include "game_engine.h"
#include "gameplay/character_menu.h"
static ff1::GameEngine engine;
static std::string s(JNIEnv* env,jstring v){if(!v)return{};const char*c=env->GetStringUTFChars(v,nullptr);std::string r=c?c:"";if(c)env->ReleaseStringUTFChars(v,c);return r;}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_init(JNIEnv*,jclass){engine.reset();}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_update(JNIEnv*,jclass){engine.update();}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_move(JNIEnv*,jclass,jint x,jint y){engine.move(x,y);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getX(JNIEnv*,jclass){return engine.state().save.playerX;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getY(JNIEnv*,jclass){return engine.state().save.playerY;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getGil(JNIEnv*,jclass){return engine.state().save.gil;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getGameMode(JNIEnv*,jclass){return static_cast<int>(engine.state().mode);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getMenuState(JNIEnv*,jclass){return static_cast<int>(engine.state().menu);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyHp(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.state().save.party[i].stats.hp;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyMaxHp(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.state().save.party[i].stats.maxHp;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyLevel(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.state().save.party[i].stats.level;}
extern "C" JNIEXPORT jstring JNICALL Java_com_example_ff1android_NativeGame_getPartyName(JNIEnv*e,jclass,jint i){if(i<0||i>=4)return e->NewStringUTF("");return e->NewStringUTF(engine.state().save.party[i].name.c_str());}
extern "C" JNIEXPORT jstring JNICALL Java_com_example_ff1android_NativeGame_getPartyJob(JNIEnv*e,jclass,jint i){if(i<0||i>=4)return e->NewStringUTF("");return e->NewStringUTF(ff1::CharacterMenu::jobName(engine.state().save.party[i].job));}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyAttack(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.partyAttack(i);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyDefense(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.partyDefense(i);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyWeapon(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.state().save.party[i].equipment.weapon;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyArmor(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.state().save.party[i].equipment.armor;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getPartyXp(JNIEnv*,jclass,jint i){return(i<0||i>=4)?0:engine.state().save.party[i].stats.xp;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getItemCount(JNIEnv*,jclass,jint id){return engine.itemCount(static_cast<uint8_t>(id));}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getBattleState(JNIEnv*,jclass){return static_cast<int>(engine.state().battle.state);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getBattleActor(JNIEnv*,jclass){return engine.currentBattleActor();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_battleFxType(JNIEnv*,jclass){return engine.battleFxType();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_battleFxValue(JNIEnv*,jclass){return engine.battleFxValue();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_battleFxTarget(JNIEnv*,jclass){return engine.battleFxTarget();}
extern "C" JNIEXPORT jstring JNICALL Java_com_example_ff1android_NativeGame_battleFxText(JNIEnv*e,jclass){return e->NewStringUTF(engine.battleFxText().c_str());}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_battleRewardExp(JNIEnv*,jclass){return engine.battleRewardExp();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_battleRewardGil(JNIEnv*,jclass){return engine.battleRewardGil();}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_clearBattleFx(JNIEnv*,jclass){engine.clearBattleFx();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getSelectedEnemy(JNIEnv*,jclass){return engine.selectedBattleEnemy();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_getEnemyHp(JNIEnv*,jclass,jint i){return(i<0||i>=engine.state().battle.enemyCount)?0:engine.state().battle.enemies[i].hp;}
extern "C" JNIEXPORT jstring JNICALL Java_com_example_ff1android_NativeGame_getEnemyName(JNIEnv*env,jclass,jint i){if(i<0||i>=engine.state().battle.enemyCount)return env->NewStringUTF("");return env->NewStringUTF(engine.state().battle.enemies[i].name.c_str());}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_startBattle(JNIEnv*,jclass,jint seed){engine.startBattle(static_cast<uint32_t>(seed));}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_selectBattleActor(JNIEnv*,jclass,jint i){engine.selectBattleActor(i);}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_selectBattleEnemy(JNIEnv*,jclass,jint i){engine.selectBattleEnemy(i);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_attack(JNIEnv*,jclass){return engine.battleCommandAttack();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_battleUseItem(JNIEnv*,jclass,jint i){return engine.battleCommandItem(i);}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_runBattle(JNIEnv*,jclass){return engine.battleRun()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_battleCommandMagic(JNIEnv*,jclass,jint caster,jint spellId,jint target){return engine.battleCommandMagic(caster,spellId,target);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_partyMp(JNIEnv*,jclass,jint i){return engine.partyMp(i);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_partyMaxMp(JNIEnv*,jclass,jint i){return engine.partyMaxMp(i);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_spellMpCost(JNIEnv*,jclass,jint id){return engine.spellMpCost(id);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_spellPower(JNIEnv*,jclass,jint id){return engine.spellPower(id);}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_spellIsHealing(JNIEnv*,jclass,jint id){return engine.spellIsHealing(id)?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_openMenu(JNIEnv*,jclass){engine.openMenu();}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_closeMenu(JNIEnv*,jclass){engine.closeMenu();}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_menuNext(JNIEnv*,jclass){engine.menuNext();}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_menuPrevious(JNIEnv*,jclass){engine.menuPrevious();}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_menuSelect(JNIEnv*,jclass,jint i){engine.menuSelect(i);}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_useItem(JNIEnv*,jclass,jint i,jint id){return engine.useItemOnParty(i,static_cast<uint8_t>(id))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_equipArmor(JNIEnv*,jclass,jint i,jint id){return engine.equipArmor(i,static_cast<uint8_t>(id))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_equipWeapon(JNIEnv*,jclass,jint i,jint id){return engine.equipWeapon(i,static_cast<uint8_t>(id))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_save(JNIEnv*env,jclass,jstring path){return engine.save(s(env,path))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_load(JNIEnv*env,jclass,jstring path){return engine.load(s(env,path))?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_livingPartyCount(JNIEnv*,jclass){return engine.livingPartyCount();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_rewardLevelUps(JNIEnv*,jclass){return engine.rewardLevelUps();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_rewardCharacterXp(JNIEnv*,jclass,jint i){return engine.rewardCharacterXp(i);}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_rewardCharacterLevels(JNIEnv*,jclass,jint i){return engine.rewardCharacterLevels(i);}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_rewardPending(JNIEnv*,jclass){return engine.rewardPending()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT void JNICALL Java_com_example_ff1android_NativeGame_clearReward(JNIEnv*,jclass){engine.clearReward();}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_interact(JNIEnv*e,jclass){std::string m;bool ok=engine.interact(m);return ok?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_explorationEncounter(JNIEnv*,jclass){return engine.explorationEncounter()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_ff1android_NativeGame_chestOpened(JNIEnv*,jclass){return engine.chestOpened()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_chestGil(JNIEnv*,jclass){return engine.chestGil();}
extern "C" JNIEXPORT jint JNICALL Java_com_example_ff1android_NativeGame_chestItem(JNIEnv*,jclass){return engine.chestItem();}
extern "C" JNIEXPORT jstring JNICALL Java_com_example_ff1android_NativeGame_npcMessage(JNIEnv*e,jclass){return e->NewStringUTF(engine.npcMessage().c_str());}
