#include <jni.h>
#include <memory>
#include "../graphics/camera_resource_controller.h"
#include "../graphics/jni_resource_bridge.h"

namespace {
struct Handle {
    ff1::CameraResourceController controller;
};
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_ff1_android_Step45NativeResourceBridge_nativeCreate(
    JNIEnv*, jobject) {
    return reinterpret_cast<jlong>(new Handle());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_ff1_android_Step45NativeResourceBridge_nativeUpdate(
    JNIEnv*, jobject, jlong handle,
    jint left, jint top, jint right, jint bottom,
    jint dx, jint dy) {
    auto* h = reinterpret_cast<Handle*>(handle);
    if (!h) return 0;
    h->controller.update(left, top, right, bottom, dx, dy);
    return static_cast<jint>(h->controller.bridge().pending());
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_ff1_android_Step45NativeResourceBridge_nativePoll(
    JNIEnv* env, jobject, jlong handle, jint maxRequests) {
    auto* h = reinterpret_cast<Handle*>(handle);
    if (!h || maxRequests <= 0) return env->NewIntArray(0);

    std::vector<jint> data;
    data.reserve(static_cast<size_t>(maxRequests) * 2);

    ff1::JniResourceBridge bridge(h->controller.bridge());
    bridge.dispatch([&](int id, int priority) {
        data.push_back(static_cast<jint>(id));
        data.push_back(static_cast<jint>(priority));
    }, static_cast<size_t>(maxRequests));

    jintArray result = env->NewIntArray(static_cast<jsize>(data.size()));
    if (!data.empty())
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(data.size()), data.data());
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_ff1_android_Step45NativeResourceBridge_nativeDestroy(
    JNIEnv*, jobject, jlong handle) {
    delete reinterpret_cast<Handle*>(handle);
}
