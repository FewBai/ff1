#pragma once
#include "ff1_types.h"
#include <random>

namespace ff1 {

class BattleSystem {
public:
    void start(Battle& battle, const SaveData& save, uint32_t seed = 1);
    void attack(Battle& battle, int actorIndex, int enemyIndex);
    void enemyTurn(Battle& battle);
    bool victory(const Battle& battle) const;
    bool defeat(const Battle& battle) const;
    void finishVictory(Battle& battle, SaveData& save);

private:
    std::mt19937 rng_{1};
    int damage(int attack, int defense);
};

} // namespace ff1
