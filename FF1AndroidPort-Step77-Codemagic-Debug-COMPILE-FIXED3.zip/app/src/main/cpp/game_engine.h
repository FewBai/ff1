#pragma once
#include "ff1_types.h"
#include "map_system.h"
#include "battle_system.h"
#include "menu_system.h"
#include "encounter_system.h"
#include "gameplay/event_system.h"
#include "gameplay/inventory.h"
#include "gameplay/party_system.h"
#include "gameplay/reward_system.h"
#include "gameplay/battle_turns.h"
#include "gameplay/world_data.h"
#include "gameplay/map_transition.h"
#include "gameplay/chest_system.h"
#include "gameplay/dialogue_system.h"
#include "gameplay/save_system_v2.h"
#include "gameplay/exploration_runtime.h"
#include <string>

namespace ff1 {

class GameEngine {
public:
    GameEngine();
    void reset();
    void update();

    bool move(int dx,int dy);
    bool interact(std::string& message);
    bool explorationEncounter() const { return exploration_.encounterTriggered(); }
    void clearExplorationEncounter() { exploration_.clearEncounter(); }
    bool chestOpened() const { return exploration_.chestOpened(); }
    int chestGil() const { return exploration_.lastChestGil(); }
    int chestItem() const { return exploration_.lastChestItem(); }
    const std::string& npcMessage() const { return exploration_.lastNpcMessage(); }
    bool stepEncounter();

    void startBattle(uint32_t seed);
    void selectBattleActor(int actor);
    void selectBattleEnemy(int enemy);
    int battleCommandAttack();
    int battleCommandItem(int partyIndex);
    int battleCommandMagic(int caster, int spellId, int target);
    bool battleRun();

    void openMenu();
    void closeMenu();
    void menuNext();
    void menuPrevious();
    void menuSelect(int menuIndex);
    bool useItemOnParty(int partyIndex,uint8_t itemId);
    bool equipWeapon(int partyIndex,uint8_t itemId);
    bool equipArmor(int partyIndex,uint8_t itemId);
    int partyAttack(int partyIndex) const;
    int partyDefense(int partyIndex) const;

    bool save(const std::string& path);
    bool load(const std::string& path);

    int livingPartyCount() const;
    int currentBattleActor() const;
    int selectedBattleEnemy() const;
    const GameState& state() const { return state_; }
    const PartySystem& party() const { return party_; }
    int itemCount(uint8_t id) const { return inventory_.count(id); }
    int partyMp(int i) const;
    int partyMaxMp(int i) const;
    int spellMpCost(int id) const;
    int spellPower(int id) const;
    bool spellIsHealing(int id) const;
    int battleFxType() const { return battleFxType_; }
    int battleFxValue() const { return battleFxValue_; }
    int battleFxTarget() const { return battleFxTarget_; }
    const std::string& battleFxText() const { return battleFxText_; }
    int battleRewardExp() const { return battleRewardExp_; }
    int battleRewardGil() const { return battleRewardGil_; }
    int rewardLevelUps() const { return rewardLevelUps_; }
    int rewardCharacterXp(int i) const { return (i>=0&&i<4)?rewardCharacterXp_[i]:0; }
    int rewardCharacterLevels(int i) const { return (i>=0&&i<4)?rewardCharacterLevels_[i]:0; }
    bool rewardPending() const { return rewardPending_; }
    void clearReward();
    void clearBattleFx();

private:
    GameState state_{};
    MapSystem map_{};
    BattleSystem battle_{};
    MenuSystem menu_{};
    EncounterSystem encounter_{1};
    EventSystem events_{};
    Inventory inventory_{};
    MapTransitionSystem transitions_{};
    ChestSystem chests_{};
    DialogueSystem dialogue_{};
    PartySystem party_{};
    SaveSystemV2 saveSystem_{};
    ExplorationRuntime exploration_{};
    std::string savePath_;
    int battleFxType_=0,battleFxValue_=0,battleFxTarget_=0; std::string battleFxText_;
    int battleRewardExp_=0,battleRewardGil_=0;
    int rewardLevelUps_=0;
    int rewardCharacterXp_[4]{};
    int rewardCharacterLevels_[4]{};
    bool rewardPending_=false;

    void syncPartyToSave();
    void syncSaveToParty();
    void syncInventoryToSave();
    void syncSaveToInventory();
    void syncBattleToParty();
};

} // namespace ff1
