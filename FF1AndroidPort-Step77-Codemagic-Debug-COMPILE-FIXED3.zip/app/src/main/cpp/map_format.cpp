#include "map_format.h"

namespace ff1 {

bool validateMap(const DecodedMap& map) {
    if (map.width <= 0 || map.height <= 0) return false;
    const size_t n = static_cast<size_t>(map.width) * map.height;
    return map.tiles.size() == n && map.collision.size() == n;
}

TileMap makeRuntimeMap(const DecodedMap& map) {
    TileMap result;
    if (!validateMap(map)) return result;
    result.id = map.id;
    result.width = map.width;
    result.height = map.height;
    result.tiles = map.tiles;
    result.collision = map.collision;
    return result;
}

} // namespace ff1
