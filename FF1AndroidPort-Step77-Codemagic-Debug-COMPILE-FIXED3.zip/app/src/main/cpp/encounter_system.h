#pragma once
#include "ff1_types.h"
#include <random>

namespace ff1 {

class EncounterSystem {
public:
    explicit EncounterSystem(uint32_t seed = 1);

    bool step();
    int chooseEncounter(bool strongerArea);
    void reset(uint32_t seed);

private:
    std::mt19937 rng_;
    int steps_ = 0;
};

} // namespace ff1
