#include "menu_system.h"

namespace ff1 {

void MenuSystem::open(GameState& game) {
    game.mode = GameMode::Menu;
    game.menu = MenuState::Main;
}

void MenuSystem::close(GameState& game) {
    game.mode = GameMode::World;
}

void MenuSystem::next(GameState& game) {
    const int n = static_cast<int>(game.menu);
    game.menu = static_cast<MenuState>((n + 1) % 5);
}

void MenuSystem::previous(GameState& game) {
    const int n = static_cast<int>(game.menu);
    game.menu = static_cast<MenuState>((n + 4) % 5);
}

} // namespace ff1
