#include "encounter_system.h"
#include <algorithm>

namespace ff1 {

EncounterSystem::EncounterSystem(uint32_t seed) : rng_(seed) {}

void EncounterSystem::reset(uint32_t seed) {
    rng_.seed(seed);
    steps_ = 0;
}

bool EncounterSystem::step() {
    ++steps_;
    // Tunable placeholder until the exact FF1 encounter tables/formula are
    // migrated from the disassembly.
    std::uniform_int_distribution<int> roll(0, 255);
    return roll(rng_) < 18;
}

int EncounterSystem::chooseEncounter(bool strongerArea) {
    if (strongerArea) {
        std::uniform_int_distribution<int> roll(0, 99);
        return roll(rng_) < 70 ? 1 : 0;
    }
    return 0;
}

} // namespace ff1
