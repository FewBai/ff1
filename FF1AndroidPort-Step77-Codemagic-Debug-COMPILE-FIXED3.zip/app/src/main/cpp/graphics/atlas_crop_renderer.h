#pragma once
#include "canvas_atlas_renderer.h"
#include "map_render_types.h"
namespace ff1 {
class AtlasCropRenderer{
public:
 explicit AtlasCropRenderer(CanvasAtlasRenderer&r):renderer_(r){}
 template<class Canvas,class Provider>
 size_t renderChunk(Canvas& canvas,const VisibleChunk& chunk,const Camera& camera,Provider& bitmaps){
  size_t drawn=0;
  for(size_t i=0;i<chunk.count;++i){
   const auto&t=chunk.tiles[i]; auto*b=bitmaps.lookup(t.bitmapId);
   if(!b){renderer_.cacheMiss();renderer_.missingTile();continue;}
   renderer_.cacheHit();
   RectF src{(float)t.atlasX,(float)t.atlasY,(float)(t.atlasX+t.atlasW),(float)(t.atlasY+t.atlasH)};
   RectF dst=worldToScreen(camera,t.worldX,t.worldY,t.width,t.height);
   canvas.drawBitmap(*b,src,dst); renderer_.debug().overlay().recordDrawCall(); ++drawn;
  }
  return drawn;
 }
private: CanvasAtlasRenderer& renderer_;
};
}
