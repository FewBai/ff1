#pragma once
#include "map_tile_data.h"
#include "map_chunk_manager.h"
#include "tile_atlas_mapper.h"
#include "tile_batch_renderer.h"
#include <functional>
namespace ff1 {
class RealTileBatchBuilder {
public:
    RealTileBatchBuilder(const MapTileGrid& grid,const TileAtlasMapper& mapper,
                         int tileWidth,int tileHeight,int resourceId)
        : grid_(grid),mapper_(mapper),tileW_(tileWidth),tileH_(tileHeight),resourceId_(resourceId){}
    void build(const ChunkBounds& visible,TileBatchRenderer& out,
               int* missingTileIds=nullptr)const;
private:
    const MapTileGrid& grid_;
    const TileAtlasMapper& mapper_;
    int tileW_,tileH_,resourceId_;
};
}
