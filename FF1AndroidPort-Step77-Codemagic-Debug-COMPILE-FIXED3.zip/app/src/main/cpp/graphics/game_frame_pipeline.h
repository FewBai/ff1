#pragma once

#include "camera_resource_controller.h"
#include "android_canvas_bridge.h"
#include "frame_resource_pins.h"
#include "render_batch.h"
#include "frame_budget.h"
#include <functional>

namespace ff1 {

struct FrameStats {
    size_t requested = 0;
    size_t drawn = 0;
    size_t cacheMisses = 0;
    size_t droppedDraws = 0;
    size_t droppedPrefetch = 0;
};

class GameFramePipeline {
public:
    void setRenderer(CanvasAtlasRenderer renderer);

    FrameStats renderFrame(
        CameraRect camera,
        int dx,
        int dy,
        const RenderBatch& batch,
        const std::function<bool(int, int)>& request,
        const std::function<void(int)>& pin,
        const std::function<void(int)>& unpin,
        const std::function<void(const CanvasDrawCommand&)>& draw,
        FrameBudget budget = {});

    // Compatibility overload for the original Step 47 vector-based API.
    FrameStats renderFrame(
        CameraRect camera,
        int dx,
        int dy,
        const std::vector<SpriteDraw>& sprites,
        const std::function<bool(int, int)>& request,
        const std::function<void(const CanvasDrawCommand&)>& draw,
        FrameBudget budget = {});

private:
    CameraResourceController resources_;
    AndroidCanvasBridge canvas_;
    FrameResourcePins pins_;
    CanvasAtlasRenderer renderer_;
};

} // namespace ff1
