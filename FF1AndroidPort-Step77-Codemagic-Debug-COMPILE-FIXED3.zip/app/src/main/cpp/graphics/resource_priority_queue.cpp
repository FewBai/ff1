#include "resource_priority_queue.h"

namespace ff1 {

void ResourcePriorityQueue::enqueue(PrioritizedResourceRequest request) {
    queue_.push(std::move(request));
}

bool ResourcePriorityQueue::pop(PrioritizedResourceRequest& out) {
    if (queue_.empty()) return false;
    out = std::move(const_cast<PrioritizedResourceRequest&>(queue_.top()));
    queue_.pop();
    return true;
}

void ResourcePriorityQueue::clear() {
    queue_ = decltype(queue_)();
}

} // namespace ff1
