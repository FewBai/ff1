#pragma once
#include "debug_memory_counters.h"
#include <cstddef>
namespace ff1 {
class DebugMemoryRegistry {
public:
    void bitmapLoaded(size_t bytes){ bitmapBytes_+=bytes; ++bitmapEntries_; }
    void bitmapEvicted(size_t bytes){ bitmapBytes_=bytes>bitmapBytes_?0:bitmapBytes_-bytes; if(bitmapEntries_)--bitmapEntries_; }
    void atlasBytes(size_t bytes){ atlasBytes_=bytes; }
    void atlasRegionAdded(){ ++atlasRegions_; }
    void atlasRegionRemoved(){ if(atlasRegions_)--atlasRegions_; }
    DebugMemoryCounters snapshot() const { return {bitmapBytes_,atlasBytes_,bitmapEntries_,atlasRegions_}; }
private:
    size_t bitmapBytes_=0, atlasBytes_=0, bitmapEntries_=0, atlasRegions_=0;
};
}
