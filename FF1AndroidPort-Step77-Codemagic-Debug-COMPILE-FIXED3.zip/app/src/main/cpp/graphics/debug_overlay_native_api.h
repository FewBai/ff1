#pragma once
#include <cstddef>
#include <cstdint>
extern "C" {
void ff1_debug_begin_frame();
void ff1_debug_end_frame(double frameMs);
void ff1_debug_set_enabled(bool enabled);
bool ff1_debug_is_enabled();
void ff1_debug_set_memory(size_t bitmapBytes,size_t atlasBytes);
void ff1_debug_record_draw();
void ff1_debug_record_cache_hit();
void ff1_debug_record_cache_miss();
void ff1_debug_record_missing_tile();
void ff1_debug_set_tiles(size_t visible,size_t submitted);
double ff1_debug_fps();
double ff1_debug_frame_ms();
double ff1_debug_avg_ms();
double ff1_debug_worst_ms();
size_t ff1_debug_draw_calls();
size_t ff1_debug_cache_hits();
size_t ff1_debug_cache_misses();
size_t ff1_debug_missing_tiles();
size_t ff1_debug_visible_tiles();
size_t ff1_debug_submitted_tiles();
size_t ff1_debug_cache_bytes();
size_t ff1_debug_atlas_bytes();
bool ff1_debug_over_budget();
}
