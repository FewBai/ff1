#include "debug_overlay_formatter.h"
#include <iomanip>
#include <sstream>
namespace ff1 {
std::string DebugOverlayFormatter::format(const DebugOverlayStats& s) {
    if (!s.enabled) return {};
    std::ostringstream o;
    o << std::fixed << std::setprecision(1);
    o << "FPS " << s.fps
      << "  Frame " << s.frameMs << " ms"
      << "  Avg " << s.averageFrameMs << " ms"
      << "  Worst " << s.worstFrameMs << " ms\n";
    o << "Draw " << s.drawCalls
      << "  Cache H " << s.cacheHits
      << "  M " << s.cacheMisses << "\n";
    o << "Tiles " << s.visibleTiles << "/" << s.submittedTiles
      << "  Missing " << s.missingTileIds << "\n";
    o << "Cache " << (s.cacheBytes/1048576.0) << " MB"
      << "  Atlas " << (s.atlasBytes/1048576.0) << " MB";
    if (s.overBudget) o << "\nFRAME > 16.67 ms";
    return o.str();
}
}
