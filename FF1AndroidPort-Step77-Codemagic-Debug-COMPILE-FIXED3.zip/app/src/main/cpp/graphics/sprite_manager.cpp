#include "sprite_manager.h"

namespace ff1 {

void SpriteManager::clear() {
    animations_.clear();
    resources_.clear();
}

bool SpriteManager::registerAnimation(const SpriteAnimation& animation) {
    if (animation.id < 0 || animation.frames.empty()) return false;
    animations_[animation.id] = animation;
    return true;
}

const SpriteAnimation* SpriteManager::animation(int id) const {
    auto it = animations_.find(id);
    return it == animations_.end() ? nullptr : &it->second;
}

bool SpriteManager::registerResource(int id, const std::vector<uint8_t>& rgba,
                                     int width, int height) {
    if (id < 0 || width <= 0 || height <= 0) return false;
    const size_t expected =
        static_cast<size_t>(width) * static_cast<size_t>(height) * 4u;
    if (rgba.size() != expected) return false;
    resources_[id] = {rgba, width, height};
    return true;
}

const std::vector<uint8_t>* SpriteManager::resource(int id) const {
    auto it = resources_.find(id);
    return it == resources_.end() ? nullptr : &it->second.rgba;
}

} // namespace ff1
