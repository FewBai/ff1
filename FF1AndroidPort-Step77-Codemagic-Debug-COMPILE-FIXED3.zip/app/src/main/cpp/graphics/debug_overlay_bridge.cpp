#include "debug_overlay_bridge.h"
namespace ff1 {
void DebugOverlayBridge::beginFrame() {
    drawCalls_=cacheHits_=cacheMisses_=missingTileIds_=0;
    visibleTiles_=submittedTiles_=0;
}
void DebugOverlayBridge::recordDrawCall(){++drawCalls_;}
void DebugOverlayBridge::recordCacheHit(){++cacheHits_;}
void DebugOverlayBridge::recordCacheMiss(){++cacheMisses_;}
void DebugOverlayBridge::recordMissingTile(){++missingTileIds_;}
void DebugOverlayBridge::setTileCounts(size_t visible,size_t submitted){
    visibleTiles_=visible; submittedTiles_=submitted;
}
void DebugOverlayBridge::endFrame(double frameMs) {
    controller_.update(frameMs,drawCalls_,cacheHits_,cacheMisses_,
                        missingTileIds_,visibleTiles_,submittedTiles_,
                        memory_.bitmapCacheBytes,memory_.atlasBytes);
}
}
