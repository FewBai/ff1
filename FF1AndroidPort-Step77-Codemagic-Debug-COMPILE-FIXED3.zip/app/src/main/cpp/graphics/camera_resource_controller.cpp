#include "camera_resource_controller.h"

namespace ff1 {

void CameraResourceController::update(int left, int top, int right, int bottom,
                                      int cameraDx, int cameraDy) {
    bridge_.update({left, top, right, bottom}, cameraDx, cameraDy);
}

} // namespace ff1
