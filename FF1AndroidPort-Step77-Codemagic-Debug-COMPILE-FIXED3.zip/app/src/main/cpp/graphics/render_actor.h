#pragma once
#include "animation_player.h"
#include <string>
#include <vector>

namespace ff1 {

enum class RenderActorType {
    Player,
    Npc,
    Chest,
    Enemy,
    Effect
};

struct RenderActor {
    int id = 0;
    RenderActorType type = RenderActorType::Player;
    SpriteInstance sprite{};
    std::string label;
};

class RenderActorSystem {
public:
    void add(const RenderActor& actor);
    bool setAnimation(int actorId, const SpriteManager& manager, int animationId);
    void update(int deltaMs, const SpriteManager& manager);
    int frameIndex(int actorId) const;

private:
    struct RuntimeActor {
        RenderActor actor;
        AnimationPlayer player;
    };

    std::vector<RuntimeActor> actors_;
};

} // namespace ff1
