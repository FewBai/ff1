#pragma once
#include "camera_culling.h"
#include <vector>
#include <algorithm>
namespace ff1 {
struct PreloadChunk { int id; float x,y,w,h; };
class ChunkPreloader {
public:
 template<class F>
 size_t schedule(const std::vector<PreloadChunk>& chunks,const Camera& cam,
                 float vw,float vh,float radius,F&& load) {
  Viewport v=cameraViewport(cam,vw,vh);
  v.left-=radius;v.top-=radius;v.right+=radius;v.bottom+=radius;
  size_t n=0;
  for(const auto& c:chunks) if(intersects(v,c.x,c.y,c.w,c.h)){load(c.id);++n;}
  return n;
 }
};
}
