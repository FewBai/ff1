#include "step52_map_renderer.h"

namespace ff1 {

Step52MapStats Step52MapRenderer::render(
    const ChunkBounds& visible,
    TileMapRenderLoop& loop,
    const RenderPass& entities,
    const std::function<bool(int)>& bitmapReady,
    const std::function<void(const CanvasDrawCommand&)>& draw,
    size_t maxMap,
    size_t maxEntities) {

    Step52MapStats s{};
    builder_.build(visible, batch_, &s.missingTileIds);

    const TileMapFrameStats frame = loop.render(
        batch_, entities, bitmapReady, draw, maxMap, maxEntities);

    s.tiles = frame.map;
    return s;
}

} // namespace ff1
