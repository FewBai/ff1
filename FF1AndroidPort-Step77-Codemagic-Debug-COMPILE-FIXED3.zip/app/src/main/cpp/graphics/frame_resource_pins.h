#pragma once
#include <functional>
#include <unordered_set>
namespace ff1 {
class FrameResourcePins {
public:
 void begin(){next_.clear();}
 void pin(int id){next_.insert(id);}
 void end(const std::function<void(int)>& unpin){for(int id:pinned_)if(!next_.count(id)&&unpin)unpin(id);pinned_.swap(next_);}
 size_t count()const{return pinned_.size();}
private: std::unordered_set<int> pinned_,next_;
};
}
