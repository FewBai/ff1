#pragma once
#include "debug_render_frame.h"
#include <cstddef>
namespace ff1 {
class CanvasAtlasRendererDebug {
public:
    explicit CanvasAtlasRendererDebug(DebugRuntimeBridge& runtime):runtime_(runtime){}
    void beginFrame(){ frame_=new DebugRenderFrame(runtime_); }
    void endFrame(){ delete frame_; frame_=nullptr; }
    void recordDraw(){ if(frame_) frame_->recordDraw(); }
    void recordCacheHit(){ if(frame_) frame_->recordCacheHit(); }
    void recordCacheMiss(){ if(frame_) frame_->recordCacheMiss(); }
    void recordMissingTile(){ if(frame_) frame_->recordMissingTile(); }
    void setTiles(size_t v,size_t s){ if(frame_) frame_->setTiles(v,s); }
private:
    DebugRuntimeBridge& runtime_;
    DebugRenderFrame* frame_=nullptr;
};
}
