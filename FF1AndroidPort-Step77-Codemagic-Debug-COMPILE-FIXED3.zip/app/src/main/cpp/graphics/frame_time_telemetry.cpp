#include "frame_time_telemetry.h"
#include <algorithm>

namespace ff1 {

void FrameTimeTelemetry::record(double milliseconds, double budgetMs) {
    lastMs = milliseconds;
    worstMs = std::max(worstMs, milliseconds);
    ++frameCount;
    averageMs += (milliseconds - averageMs) / static_cast<double>(frameCount);
    if (milliseconds > budgetMs)
        ++overBudgetFrames;
}

} // namespace ff1
