#pragma once
#include "map_chunk_manager.h"
#include "resource_priority_queue.h"
#include <cstdint>
#include <vector>

namespace ff1 {

struct AndroidResourceRequest {
    int id = 0;
    int priority = 0;
};

class AndroidResourceBridge {
public:
    void update(const ChunkBounds& visible, int cameraDx, int cameraDy);
    bool poll(AndroidResourceRequest& out);
    size_t pending() const { return requests_.size(); }
    void clear();

private:
    uint64_t sequence_ = 0;
    MapChunkManager chunks_{256, 256};
    ResourcePriorityQueue queue_;
    std::vector<AndroidResourceRequest> requests_;
    size_t cursor_ = 0;
};

} // namespace ff1
