#include "chunk_tile_batch_builder.h"

namespace ff1 {

void ChunkTileBatchBuilder::build(
    const MapChunkManager& chunks,
    const ChunkBounds& visible,
    TileBatchRenderer& out,
    const std::function<int(int,int)>& atlasForTile) const {

    out.clear();
    const auto active = chunks.chunksForRect(visible, 0);

    const int chunkW = layout_.tileWidth * layout_.tilesPerChunkX;
    const int chunkH = layout_.tileHeight * layout_.tilesPerChunkY;

    for (const auto& c : active) {
        const int baseX = c.x * chunkW;
        const int baseY = c.y * chunkH;

        for (int ty = 0; ty < layout_.tilesPerChunkY; ++ty) {
            for (int tx = 0; tx < layout_.tilesPerChunkX; ++tx) {
                const int worldX = baseX + tx * layout_.tileWidth;
                const int worldY = baseY + ty * layout_.tileHeight;

                if (worldX + layout_.tileWidth <= visible.left ||
                    worldX >= visible.right ||
                    worldY + layout_.tileHeight <= visible.top ||
                    worldY >= visible.bottom) {
                    continue;
                }

                const int region = atlasForTile
                    ? atlasForTile(tx, ty)
                    : layout_.atlasRegionId;

                out.add({
                    layout_.resourceId,
                    region,
                    worldX,
                    worldY,
                    layout_.tileWidth,
                    layout_.tileHeight
                });
            }
        }
    }
}

} // namespace ff1
