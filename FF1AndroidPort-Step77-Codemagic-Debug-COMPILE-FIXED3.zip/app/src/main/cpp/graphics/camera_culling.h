#pragma once
#include "map_render_types.h"
namespace ff1 {
struct Viewport{float left,top,right,bottom;};
inline Viewport cameraViewport(const Camera& c,float w,float h){
 return {c.x,c.y,c.x+w/c.zoom,c.y+h/c.zoom};
}
inline bool intersects(const Viewport& v,float x,float y,float w,float h){
 return x+w>v.left && x<v.right && y+h>v.top && y<v.bottom;
}
}
