#include "android_canvas_bridge.h"
#include <utility>

namespace ff1 {

void AndroidCanvasBridge::setRenderer(CanvasAtlasRenderer renderer) {
    ownedRenderer_ = std::make_unique<CanvasAtlasRenderer>(std::move(renderer));
    renderer_ = ownedRenderer_.get();
}

void AndroidCanvasBridge::setCamera(CameraRect camera) {
    if (renderer_) renderer_->setCamera(camera);
}

size_t AndroidCanvasBridge::render(
    const std::vector<SpriteDraw>& sprites,
    const BitmapReady& ready,
    const std::function<void(const CanvasDrawCommand&)>& draw) {
    if (!renderer_ || !draw) return 0;

    const auto commands = renderer_->buildVisible(sprites);
    size_t drawn = 0;
    for (const auto& command : commands) {
        if (ready && !ready(command.resourceId)) {
            renderer_->cacheMiss();
            continue;
        }
        renderer_->cacheHit();
        draw(command);
        ++drawn;
    }
    return drawn;
}

} // namespace ff1
