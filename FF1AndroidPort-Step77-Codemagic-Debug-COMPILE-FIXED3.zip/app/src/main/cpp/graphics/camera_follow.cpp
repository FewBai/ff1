#include "camera_follow.h"
namespace ff1 {
void CameraFollow::setDeadZone(float l,float t,float r,float b){left_=l;top_=t;right_=r;bottom_=b;}
CameraFollowResult CameraFollow::update(float cx,float cy,float tx,float ty)const{
    CameraFollowResult o{cx,cy};
    const float rx=tx-cx, ry=ty-cy;
    if(rx<left_) o.x=tx-left_;
    else if(rx>right_) o.x=tx-right_;
    if(ry<top_) o.y=ty-top_;
    else if(ry>bottom_) o.y=ty-bottom_;
    return o;
}
}
