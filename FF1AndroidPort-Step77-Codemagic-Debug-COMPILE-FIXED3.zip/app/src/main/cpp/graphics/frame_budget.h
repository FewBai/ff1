#pragma once
#include <cstddef>
namespace ff1{struct FrameBudget{size_t maxDrawCommands=512,maxPrefetchRequests=32;};}
