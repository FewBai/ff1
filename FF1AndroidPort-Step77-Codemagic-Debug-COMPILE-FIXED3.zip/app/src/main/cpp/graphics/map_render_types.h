#pragma once
#include <cstddef>
namespace ff1 {
struct RectF{float left,top,right,bottom;};
struct Camera{float x=0,y=0,zoom=1;};
struct ChunkTile{int bitmapId,atlasX,atlasY,atlasW,atlasH;float worldX,worldY,width,height;};
struct VisibleChunk{const ChunkTile* tiles;size_t count;};
inline RectF worldToScreen(const Camera& c,float x,float y,float w,float h){
 return {(x-c.x)*c.zoom,(y-c.y)*c.zoom,(x-c.x+w)*c.zoom,(y-c.y+h)*c.zoom};
}
}
