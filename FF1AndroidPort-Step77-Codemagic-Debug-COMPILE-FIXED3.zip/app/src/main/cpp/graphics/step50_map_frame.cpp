#include "step50_map_frame.h"

namespace ff1 {

void Step50MapFrame::updatePlayer(
    float targetX, float targetY,
    float deltaSeconds, float moveSpeed) {

    player_.setTarget(targetX, targetY);
    player_.update(deltaSeconds, moveSpeed);
}

Step50FrameResult Step50MapFrame::render(
    const MapChunkManager& chunks,
    const ChunkBounds& visible,
    TileMapRenderLoop& loop,
    const RenderPass& entities,
    const std::function<bool(int)>& bitmapReady,
    const std::function<void(const CanvasDrawCommand&)>& draw,
    size_t maxMapCommands,
    size_t maxEntityCommands,
    double frameMilliseconds) {

    builder_.build(chunks, visible, mapTiles_);
    telemetry_.record(frameMilliseconds);

    Step50FrameResult result{};
    result.render = loop.render(
        mapTiles_, entities, bitmapReady, draw,
        maxMapCommands, maxEntityCommands);
    result.player = player_.current();
    result.telemetry = telemetry_;
    return result;
}

} // namespace ff1
