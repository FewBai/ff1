#pragma once
#include "debug_runtime_bridge.h"
namespace ff1 {
template<class Cache>
class BitmapCacheLookupDebug {
public:
    BitmapCacheLookupDebug(Cache& cache, DebugRuntimeBridge& runtime)
        : cache_(cache), runtime_(runtime) {}
    template<class Key>
    auto lookup(const Key& key) {
        auto result = cache_.find(key);
        if (result) runtime_.overlay().recordCacheHit();
        else runtime_.overlay().recordCacheMiss();
        return result;
    }
private:
    Cache& cache_;
    DebugRuntimeBridge& runtime_;
};
}
