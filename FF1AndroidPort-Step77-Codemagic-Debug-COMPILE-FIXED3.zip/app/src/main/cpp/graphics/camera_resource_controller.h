#pragma once
#include "android_resource_bridge.h"

namespace ff1 {

class CameraResourceController {
public:
    CameraResourceController() = default;

    void update(int left, int top, int right, int bottom,
                int cameraDx, int cameraDy);

    AndroidResourceBridge& bridge() { return bridge_; }

private:
    AndroidResourceBridge bridge_;
};

} // namespace ff1
