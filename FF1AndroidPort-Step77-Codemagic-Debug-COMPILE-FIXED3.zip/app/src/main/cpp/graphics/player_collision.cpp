#include "player_collision.h"
#include <cmath>
namespace ff1 {
bool PlayerCollision::blocked(float x,float y,const MapTileSource& source,int tileW,int tileH)const{
    MapTile t;
    if(!source.tileAtWorld((int)std::floor(x),(int)std::floor(y),tileW,tileH,t)) return true;
    return t.collision!=0;
}
PlayerPosition PlayerCollision::move(const PlayerPosition& c,float dx,float dy,
 const MapTileSource& source,int tileW,int tileH)const{
    PlayerPosition p=c;
    if(!blocked(c.x+dx,c.y,source,tileW,tileH)) p.x=c.x+dx;
    if(!blocked(p.x,c.y+dy,source,tileW,tileH)) p.y=c.y+dy;
    return p;
}
}
