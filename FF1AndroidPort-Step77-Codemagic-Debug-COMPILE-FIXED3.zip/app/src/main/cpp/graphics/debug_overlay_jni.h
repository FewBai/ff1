#pragma once
#include "debug_overlay_bridge.h"
namespace ff1 {
class DebugOverlayJni {
public:
    void publish(const DebugOverlayBridge& bridge) {
        latest_ = bridge.stats();
    }
    const DebugOverlayStats& latest() const { return latest_; }
private:
    DebugOverlayStats latest_{};
};
}
