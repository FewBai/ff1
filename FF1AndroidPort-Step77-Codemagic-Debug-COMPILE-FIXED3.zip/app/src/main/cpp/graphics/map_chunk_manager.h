#pragma once
#include "resource_priority_queue.h"
#include <cstdint>
#include <unordered_set>
#include <vector>

namespace ff1 {

struct ChunkCoord {
    int x = 0;
    int y = 0;

    bool operator==(const ChunkCoord& other) const {
        return x == other.x && y == other.y;
    }
};

struct ChunkCoordHash {
    size_t operator()(const ChunkCoord& c) const {
        const uint64_t x = static_cast<uint32_t>(c.x);
        const uint64_t y = static_cast<uint32_t>(c.y);
        return static_cast<size_t>((x << 32) ^ y);
    }
};

struct ChunkBounds {
    int left = 0;
    int top = 0;
    int right = 0;
    int bottom = 0;
};

class MapChunkManager {
public:
    MapChunkManager(int chunkWidth, int chunkHeight);

    ChunkCoord worldToChunk(int worldX, int worldY) const;
    std::vector<ChunkCoord> chunksForRect(const ChunkBounds& rect,
                                          int paddingChunks) const;

    void updateInterest(const ChunkBounds& visible,
                        int cameraDx,
                        int cameraDy,
                        ResourcePriorityQueue& requests);

    bool isActive(const ChunkCoord& c) const;
    bool isPrefetch(const ChunkCoord& c) const;

    const std::unordered_set<ChunkCoord, ChunkCoordHash>& active() const {
        return active_;
    }

    const std::unordered_set<ChunkCoord, ChunkCoordHash>& prefetch() const {
        return prefetch_;
    }

private:
    int chunkWidth_;
    int chunkHeight_;
    std::unordered_set<ChunkCoord, ChunkCoordHash> active_;
    std::unordered_set<ChunkCoord, ChunkCoordHash> prefetch_;
};

} // namespace ff1
