#pragma once
#include "canvas_atlas_renderer.h"
#include <functional>
#include <vector>
#include <cstddef>
namespace ff1 {
struct TileSprite {
 int resourceId=0, atlasRegionId=0, worldX=0, worldY=0, width=0, height=0;
};
struct TileBatchStats { size_t submitted=0, visible=0, cacheMisses=0, drawn=0; };
class TileBatchRenderer {
public:
 void clear();
 void add(const TileSprite& tile);
 const std::vector<TileSprite>& tiles() const { return tiles_; }
 TileBatchStats buildVisible(
  const CanvasAtlasRenderer& renderer,
  const std::function<bool(int)>& bitmapReady,
  const std::function<void(const CanvasDrawCommand&)>& draw,
  size_t maxCommands) const;
private:
 std::vector<TileSprite> tiles_;
};
}
