#include "debug_overlay_controller.h"
#include "debug_overlay_formatter.h"
#include <algorithm>
namespace ff1 {
void DebugOverlayController::update(double frameMs,size_t drawCalls,size_t cacheHits,
 size_t cacheMisses,size_t missingTileIds,size_t visibleTiles,size_t submittedTiles,
 size_t cacheBytes,size_t atlasBytes) {
    stats_.frameMs=std::max(0.0,frameMs);
    stats_.fps=stats_.frameMs>0.001 ? 1000.0/stats_.frameMs : 0.0;
    stats_.drawCalls=drawCalls;
    stats_.cacheHits=cacheHits;
    stats_.cacheMisses=cacheMisses;
    stats_.missingTileIds=missingTileIds;
    stats_.visibleTiles=visibleTiles;
    stats_.submittedTiles=submittedTiles;
    stats_.cacheBytes=cacheBytes;
    stats_.atlasBytes=atlasBytes;
    stats_.overBudget=stats_.frameMs>16.67;
    if (stats_.averageFrameMs==0.0) stats_.averageFrameMs=stats_.frameMs;
    else stats_.averageFrameMs += (stats_.frameMs-stats_.averageFrameMs)*0.1;
    stats_.worstFrameMs=std::max(stats_.worstFrameMs,stats_.frameMs);
}
std::string DebugOverlayController::text() const {
    return DebugOverlayFormatter::format(stats_);
}
}
