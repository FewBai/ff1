#pragma once
#include "tile_batch_renderer.h"
#include "render_pass.h"
namespace ff1 {
struct TileMapFrameStats { TileBatchStats map; size_t entitiesDrawn=0,totalDrawn=0; };
class TileMapRenderLoop {
public:
 void setRenderer(CanvasAtlasRenderer renderer);
 const CanvasAtlasRenderer& renderer() const { return renderer_; }
 TileMapFrameStats render(const TileBatchRenderer& map,const RenderPass& entities,
  const std::function<bool(int)>& bitmapReady,
  const std::function<void(const CanvasDrawCommand&)>& draw,
  size_t maxMapCommands,size_t maxEntityCommands);
private:
 CanvasAtlasRenderer renderer_;
};
}
