#include "map_tile_source.h"
namespace ff1 {
bool MapTileSource::tileAtWorld(int worldX,int worldY,int tileW,int tileH,MapTile& out)const{
    if(tileW<=0||tileH<=0) return false;
    const int x=worldX/tileW, y=worldY/tileH;
    if(x<0||y<0||x>=grid_.width()||y>=grid_.height()) return false;
    out=grid_.at(x,y); return true;
}
}
