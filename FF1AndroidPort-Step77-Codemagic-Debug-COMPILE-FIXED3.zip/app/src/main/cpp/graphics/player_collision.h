#pragma once
#include "map_tile_source.h"
namespace ff1 {
struct PlayerPosition { float x=0,y=0; };
class PlayerCollision {
public:
    PlayerPosition move(const PlayerPosition& current,float dx,float dy,
                        const MapTileSource& source,int tileW,int tileH)const;
private:
    bool blocked(float x,float y,const MapTileSource& source,int tileW,int tileH)const;
};
}
