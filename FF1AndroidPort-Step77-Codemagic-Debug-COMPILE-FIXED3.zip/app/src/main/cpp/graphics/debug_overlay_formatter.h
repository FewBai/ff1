#pragma once
#include "debug_overlay_stats.h"
#include <string>
namespace ff1 {
class DebugOverlayFormatter {
public:
    static std::string format(const DebugOverlayStats& s);
};
}
