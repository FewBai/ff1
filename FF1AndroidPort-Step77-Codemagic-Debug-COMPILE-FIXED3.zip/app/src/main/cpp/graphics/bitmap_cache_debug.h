#pragma once
#include "debug_runtime_bridge.h"
namespace ff1 {
class BitmapCacheDebug {
public:
    explicit BitmapCacheDebug(DebugRuntimeBridge* d=nullptr):debug_(d){}
    void attachDebug(DebugRuntimeBridge* d){debug_=d;}
    void onDecodeSuccess(size_t bytes){if(debug_) debug_->memory().bitmapLoaded(bytes);}
    void onEvict(size_t bytes){if(debug_) debug_->memory().bitmapEvicted(bytes);}
private:
    DebugRuntimeBridge* debug_;
};
}
