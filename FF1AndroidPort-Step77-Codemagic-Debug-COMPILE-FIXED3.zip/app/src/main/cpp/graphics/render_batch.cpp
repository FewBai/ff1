#include "render_batch.h"

namespace ff1 {

std::vector<SpriteDraw> RenderBatch::sortedVisible(
    const CanvasAtlasRenderer& renderer) const {
    auto sorted = items_;
    std::stable_sort(sorted.begin(), sorted.end(), [](const auto& a, const auto& b) {
        if (a.layer != b.layer) return static_cast<int>(a.layer) < static_cast<int>(b.layer);
        return a.z < b.z;
    });

    std::vector<SpriteDraw> visible;
    visible.reserve(sorted.size());
    for (const auto& item : sorted) {
        CanvasDrawCommand command;
        if (renderer.buildCommand(item.sprite, command)) visible.push_back(item.sprite);
    }
    return visible;
}

} // namespace ff1
