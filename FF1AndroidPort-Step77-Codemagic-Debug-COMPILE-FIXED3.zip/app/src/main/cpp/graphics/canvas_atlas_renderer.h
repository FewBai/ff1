#pragma once

#include "debug_runtime_bridge.h"
#include "texture_atlas.h"

#include <cstddef>
#include <utility>
#include <vector>

namespace ff1 {

struct CameraRect {
    float left = 0;
    float top = 0;
    float right = 0;
    float bottom = 0;
};

struct SpriteDraw {
    int resourceId = 0;
    int atlasRegionId = 0;
    int worldX = 0;
    int worldY = 0;
    int width = 0;
    int height = 0;
};

struct CanvasDrawCommand {
    int resourceId = 0;
    AtlasRegion src{};
    int screenX = 0;
    int screenY = 0;
    int dstWidth = 0;
    int dstHeight = 0;
};

class CanvasAtlasRenderer {
public:
    CanvasAtlasRenderer() = default;
    explicit CanvasAtlasRenderer(DebugRuntimeBridge& debug) : debug_(&debug) {}

    CanvasAtlasRenderer(const CanvasAtlasRenderer&) = default;
    CanvasAtlasRenderer& operator=(const CanvasAtlasRenderer&) = default;
    CanvasAtlasRenderer(CanvasAtlasRenderer&&) noexcept = default;
    CanvasAtlasRenderer& operator=(CanvasAtlasRenderer&&) noexcept = default;

    void setAtlas(int resourceId, TextureAtlas atlas);
    void setCamera(CameraRect camera) { camera_ = camera; }

    const CameraRect& camera() const { return camera_; }
    int atlasResourceId() const { return atlasResourceId_; }

    bool buildCommand(const SpriteDraw& sprite, CanvasDrawCommand& out) const;
    std::vector<CanvasDrawCommand> buildVisible(
        const std::vector<SpriteDraw>& sprites) const;

    void beginFrame();
    void endFrame(double frameMs);

    template<class Canvas, class Bitmap>
    void drawBitmap(Canvas& canvas, const Bitmap& bitmap, float x, float y) {
        canvas.drawBitmap(bitmap, x, y);
        if (debug_) debug_->overlay().recordDrawCall();
    }

    void cacheHit() { if (debug_) debug_->overlay().recordCacheHit(); }
    void cacheMiss() { if (debug_) debug_->overlay().recordCacheMiss(); }
    void missingTile() { if (debug_) debug_->overlay().recordMissingTile(); }
    void setVisibleTiles(size_t visible, size_t submitted) {
        if (debug_) debug_->overlay().setTileCounts(visible, submitted);
    }

    DebugRuntimeBridge& debug();
    const DebugRuntimeBridge& debug() const;

private:
    DebugRuntimeBridge* debug_ = nullptr;
    int atlasResourceId_ = 0;
    TextureAtlas atlas_;
    CameraRect camera_{};
};

} // namespace ff1
