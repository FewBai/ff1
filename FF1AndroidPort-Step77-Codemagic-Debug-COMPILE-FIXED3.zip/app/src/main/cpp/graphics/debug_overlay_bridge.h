#pragma once
#include "debug_overlay_controller.h"
#include "debug_memory_counters.h"
#include <string>
namespace ff1 {
class DebugOverlayBridge {
public:
    void beginFrame();
    void recordDrawCall();
    void recordCacheHit();
    void recordCacheMiss();
    void recordMissingTile();
    void setTileCounts(size_t visible,size_t submitted);
    void setMemoryCounters(const DebugMemoryCounters& memory) { memory_=memory; }
    void endFrame(double frameMs);
    void setEnabled(bool enabled) { controller_.setEnabled(enabled); }
    bool enabled() const { return controller_.enabled(); }
    const DebugOverlayStats& stats() const { return controller_.stats(); }
    std::string text() const { return controller_.text(); }
private:
    size_t drawCalls_=0, cacheHits_=0, cacheMisses_=0, missingTileIds_=0;
    size_t visibleTiles_=0, submittedTiles_=0;
    DebugMemoryCounters memory_{};
    DebugOverlayController controller_;
};
}
