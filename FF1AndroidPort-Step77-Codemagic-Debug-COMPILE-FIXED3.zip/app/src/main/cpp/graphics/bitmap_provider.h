#pragma once
#include <cstdint>

namespace ff1 {

class BitmapProvider {
public:
    virtual ~BitmapProvider() = default;
    virtual bool contains(std::int32_t id) const = 0;
    virtual bool ready(std::int32_t id) const = 0;
};

} // namespace ff1
