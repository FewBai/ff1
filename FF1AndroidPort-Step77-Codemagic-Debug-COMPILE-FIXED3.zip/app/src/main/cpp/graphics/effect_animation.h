#pragma once
#include "animation_player.h"

namespace ff1 {

enum class EffectType {
    AttackHit,
    MagicCast,
    Heal,
    ChestOpen,
    Fade
};

struct EffectInstance {
    EffectType type = EffectType::AttackHit;
    int x = 0;
    int y = 0;
    int animationId = 0;
    bool active = false;
    int elapsedMs = 0;
};

class EffectAnimationSystem {
public:
    void start(EffectInstance& effect, const SpriteManager& manager, int animationId);
    bool update(EffectInstance& effect, AnimationPlayer& player,
                const SpriteManager& manager, int deltaMs);
};

} // namespace ff1
