#include "step51_map_world.h"
namespace ff1 {
Step51WorldState Step51MapWorld::updateAndRender(
 const MapTileSource& tiles,const PlayerPosition& desiredMove,float dt,
 int tileW,int tileH,float cameraX,float cameraY,
 const MapChunkManager& chunks,const ChunkBounds& visible,
 TileMapRenderLoop& loop,const RenderPass& entities,
 const std::function<bool(int)>& bitmapReady,
 const std::function<void(const CanvasDrawCommand&)>& draw,
 size_t maxMap,size_t maxEntities,double frameMs){
 player_=collision_.move(player_,desiredMove.x*dt,desiredMove.y*dt,tiles,tileW,tileH);
 auto cam=cameraFollow_.update(cameraX,cameraY,player_.x,player_.y);
 Step51WorldState s{};
 s.player=player_; s.camera=cam;
 s.render = Step50FrameResult{};
 return s;
}
}
