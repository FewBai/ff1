#pragma once
#include <cstdint>
#include <cstddef>
#include <list>
#include <unordered_map>
#include <vector>
namespace ff1 {
struct CachedBitmap {
 int id=0,width=0,height=0; std::vector<uint8_t> rgba;
 size_t bytes()const{return rgba.size();}
};
class ResourceCache {
public:
 explicit ResourceCache(size_t maxBytes=4*1024*1024);
 bool put(CachedBitmap bitmap); const CachedBitmap* get(int id);
 bool contains(int id)const; void erase(int id); void clear();
 size_t bytesUsed()const{return bytesUsed_;}
 void setMaxBytes(size_t bytes);
private:
 struct Entry{CachedBitmap bitmap;std::list<int>::iterator lruIt;};
 void touch(Entry&); void evict();
 size_t maxBytes_,bytesUsed_=0; std::list<int> lru_;
 std::unordered_map<int,Entry> entries_;
};
}
