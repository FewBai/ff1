#pragma once
#include "real_tile_batch_builder.h"
#include "map_chunk_manager.h"
#include "tile_map_render_loop.h"
namespace ff1 {
struct Step52MapStats {
    TileBatchStats tiles;
    int missingTileIds=0;
};
class Step52MapRenderer {
public:
    Step52MapRenderer(const MapTileGrid& grid,const TileAtlasMapper& mapper,
                      int tileW,int tileH,int resourceId)
        : builder_(grid,mapper,tileW,tileH,resourceId){}
    Step52MapStats render(const ChunkBounds& visible,
                          TileMapRenderLoop& loop,
                          const RenderPass& entities,
                          const std::function<bool(int)>& bitmapReady,
                          const std::function<void(const CanvasDrawCommand&)>& draw,
                          size_t maxMap,size_t maxEntities);
private:
    RealTileBatchBuilder builder_;
    TileBatchRenderer batch_;
};
}
