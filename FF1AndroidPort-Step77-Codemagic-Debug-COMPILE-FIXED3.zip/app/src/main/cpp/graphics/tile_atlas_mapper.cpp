#include "tile_atlas_mapper.h"
namespace ff1 {
void TileAtlasMapper::set(uint16_t tileId,int atlasRegionId){regions_[tileId]=atlasRegionId;}
int TileAtlasMapper::regionFor(uint16_t tileId,int fallback)const{
    auto it=regions_.find(tileId);
    return it==regions_.end()?fallback:it->second;
}
bool TileAtlasMapper::contains(uint16_t tileId)const{return regions_.find(tileId)!=regions_.end();}
}
