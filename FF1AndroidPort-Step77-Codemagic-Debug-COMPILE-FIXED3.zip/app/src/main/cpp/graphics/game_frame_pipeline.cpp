#include "game_frame_pipeline.h"
#include <utility>

namespace ff1 {

void GameFramePipeline::setRenderer(CanvasAtlasRenderer renderer) {
    renderer_ = std::move(renderer);
    canvas_.setRenderer(renderer_);
}

FrameStats GameFramePipeline::renderFrame(
    CameraRect camera,
    int dx,
    int dy,
    const RenderBatch& batch,
    const std::function<bool(int, int)>& request,
    const std::function<void(int)>& pin,
    const std::function<void(int)>& unpin,
    const std::function<void(const CanvasDrawCommand&)>& draw,
    FrameBudget budget) {
    resources_.update(camera.left, camera.top, camera.right, camera.bottom, dx, dy);
    renderer_.setCamera(camera);

    FrameStats stats{};

    AndroidResourceRequest q;
    while (stats.requested < budget.maxPrefetchRequests && resources_.bridge().poll(q)) {
        ++stats.requested;
        if (request) request(q.id, q.priority);
    }
    while (resources_.bridge().poll(q)) ++stats.droppedPrefetch;

    pins_.begin();
    const auto sprites = batch.sortedVisible(renderer_);
    size_t kept = 0;

    for (const auto& sprite : sprites) {
        CanvasDrawCommand command;
        if (!renderer_.buildCommand(sprite, command)) continue;
        if (kept >= budget.maxDrawCommands) {
            ++stats.droppedDraws;
            continue;
        }
        ++kept;

        // A true cache hit is represented by the request callback returning true.
        // A false result means the bitmap must be requested/preloaded first.
        if (request && !request(command.resourceId, 0)) {
            ++stats.cacheMisses;
            continue;
        }

        pins_.pin(command.resourceId);
        if (pin) pin(command.resourceId);
        if (draw) draw(command);
        ++stats.drawn;
    }

    pins_.end(unpin);
    return stats;
}

FrameStats GameFramePipeline::renderFrame(
    CameraRect camera,
    int dx,
    int dy,
    const std::vector<SpriteDraw>& sprites,
    const std::function<bool(int, int)>& request,
    const std::function<void(const CanvasDrawCommand&)>& draw,
    FrameBudget budget) {
    RenderBatch batch;
    int z = 0;
    for (const auto& sprite : sprites) {
        batch.add({RenderLayer::Actor, z++, sprite});
    }
    return renderFrame(
        camera, dx, dy, batch, request,
        std::function<void(int)>(), std::function<void(int)>(), draw, budget);
}

} // namespace ff1
