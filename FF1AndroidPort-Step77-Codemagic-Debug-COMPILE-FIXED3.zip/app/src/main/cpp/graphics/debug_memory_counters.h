#pragma once
#include <cstddef>
namespace ff1 {
struct DebugMemoryCounters {
    size_t bitmapCacheBytes=0;
    size_t atlasBytes=0;
    size_t bitmapCacheEntries=0;
    size_t atlasRegions=0;
};
}
