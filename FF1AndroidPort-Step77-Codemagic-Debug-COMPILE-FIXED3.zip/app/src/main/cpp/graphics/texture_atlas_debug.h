#pragma once
#include "debug_memory_registry.h"
namespace ff1 {
class TextureAtlasDebug {
public:
    explicit TextureAtlasDebug(DebugMemoryRegistry* registry=nullptr):registry_(registry){}
    void attach(DebugMemoryRegistry* r){registry_=r;}
    void setStorageBytes(size_t bytes){if(registry_)registry_->atlasBytes(bytes);}
    void onRegionAdded(){if(registry_)registry_->atlasRegionAdded();}
    void onRegionRemoved(){if(registry_)registry_->atlasRegionRemoved();}
private:
    DebugMemoryRegistry* registry_;
};
}
