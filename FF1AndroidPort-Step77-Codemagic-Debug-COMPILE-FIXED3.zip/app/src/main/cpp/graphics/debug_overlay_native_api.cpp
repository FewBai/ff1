#include "debug_overlay_native_api.h"
#include "debug_overlay_bridge.h"
namespace {
ff1::DebugOverlayBridge g_bridge;
}
extern "C" {
void ff1_debug_begin_frame(){g_bridge.beginFrame();}
void ff1_debug_end_frame(double ms){g_bridge.endFrame(ms);}
void ff1_debug_set_enabled(bool e){g_bridge.setEnabled(e);}
bool ff1_debug_is_enabled(){return g_bridge.enabled();}
void ff1_debug_set_memory(size_t b,size_t a){g_bridge.setMemoryCounters({b,a,0,0});}
void ff1_debug_record_draw(){g_bridge.recordDrawCall();}
void ff1_debug_record_cache_hit(){g_bridge.recordCacheHit();}
void ff1_debug_record_cache_miss(){g_bridge.recordCacheMiss();}
void ff1_debug_record_missing_tile(){g_bridge.recordMissingTile();}
void ff1_debug_set_tiles(size_t v,size_t s){g_bridge.setTileCounts(v,s);}
double ff1_debug_fps(){return g_bridge.stats().fps;}
double ff1_debug_frame_ms(){return g_bridge.stats().frameMs;}
double ff1_debug_avg_ms(){return g_bridge.stats().averageFrameMs;}
double ff1_debug_worst_ms(){return g_bridge.stats().worstFrameMs;}
size_t ff1_debug_draw_calls(){return g_bridge.stats().drawCalls;}
size_t ff1_debug_cache_hits(){return g_bridge.stats().cacheHits;}
size_t ff1_debug_cache_misses(){return g_bridge.stats().cacheMisses;}
size_t ff1_debug_missing_tiles(){return g_bridge.stats().missingTileIds;}
size_t ff1_debug_visible_tiles(){return g_bridge.stats().visibleTiles;}
size_t ff1_debug_submitted_tiles(){return g_bridge.stats().submittedTiles;}
size_t ff1_debug_cache_bytes(){return g_bridge.stats().cacheBytes;}
size_t ff1_debug_atlas_bytes(){return g_bridge.stats().atlasBytes;}
bool ff1_debug_over_budget(){return g_bridge.stats().overBudget;}
}
