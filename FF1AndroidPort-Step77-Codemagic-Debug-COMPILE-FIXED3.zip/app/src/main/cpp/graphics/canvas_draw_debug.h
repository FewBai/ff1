#pragma once
#include "debug_runtime_bridge.h"
namespace ff1 {
class CanvasDrawDebug {
public:
    explicit CanvasDrawDebug(DebugRuntimeBridge& runtime):runtime_(runtime){}
    template<class Canvas,class Bitmap>
    void drawBitmap(Canvas& canvas,const Bitmap& bitmap,float x,float y){
        canvas.drawBitmap(bitmap,x,y);
        runtime_.overlay().recordDrawCall();
    }
private:
    DebugRuntimeBridge& runtime_;
};
}
