#include "map_chunk_manager.h"
#include <algorithm>

namespace ff1 {

MapChunkManager::MapChunkManager(int chunkWidth, int chunkHeight)
    : chunkWidth_(std::max(1, chunkWidth)),
      chunkHeight_(std::max(1, chunkHeight)) {}

ChunkCoord MapChunkManager::worldToChunk(int worldX, int worldY) const {
    auto floorDiv = [](int value, int divisor) {
        if (value >= 0) return value / divisor;
        return -static_cast<int>((-static_cast<long long>(value) +
                                  divisor - 1) / divisor);
    };
    return {floorDiv(worldX, chunkWidth_), floorDiv(worldY, chunkHeight_)};
}

std::vector<ChunkCoord> MapChunkManager::chunksForRect(
    const ChunkBounds& rect, int paddingChunks) const {
    const int pad = std::max(0, paddingChunks);
    const ChunkCoord a = worldToChunk(rect.left, rect.top);
    const ChunkCoord b = worldToChunk(std::max(rect.left, rect.right - 1),
                                      std::max(rect.top, rect.bottom - 1));

    std::vector<ChunkCoord> result;
    for (int y = a.y - pad; y <= b.y + pad; ++y)
        for (int x = a.x - pad; x <= b.x + pad; ++x)
            result.push_back({x, y});
    return result;
}

void MapChunkManager::updateInterest(const ChunkBounds& visible,
                                     int cameraDx, int cameraDy,
                                     ResourcePriorityQueue& requests) {
    active_.clear();
    prefetch_.clear();

    for (const auto& c : chunksForRect(visible, 0))
        active_.insert(c);

    for (const auto& c : chunksForRect(visible, 1))
        if (!active_.count(c))
            prefetch_.insert(c);

    // Queue a lightweight metadata request for each interested chunk.
    // The platform adapter can translate chunk coordinates into actual
    // texture/tile resources.
    uint64_t sequence = 0;
    for (const auto& c : active_) {
        ResourceRequest r;
        r.id = c.x * 100000 + c.y;
        requests.enqueue({ResourcePriority::Visible, sequence++, std::move(r)});
    }

    // Bias the one-chunk ring toward the current camera movement direction.
    for (const auto& c : prefetch_) {
        const bool forwardX = cameraDx > 0 && c.x > 0;
        const bool forwardY = cameraDy > 0 && c.y > 0;
        (void)forwardX;
        (void)forwardY;

        ResourceRequest r;
        r.id = c.x * 100000 + c.y;
        requests.enqueue({ResourcePriority::Prefetch, sequence++, std::move(r)});
    }
}

bool MapChunkManager::isActive(const ChunkCoord& c) const {
    return active_.count(c) != 0;
}

bool MapChunkManager::isPrefetch(const ChunkCoord& c) const {
    return prefetch_.count(c) != 0;
}

} // namespace ff1
