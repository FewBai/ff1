#include "chunk_lifecycle.h"

namespace ff1 {

void ChunkLifecycle::sync(const MapChunkManager& manager) {
    for (auto it = states_.begin(); it != states_.end();) {
        const ChunkCoord c = it->first;
        if (!manager.isActive(c) && !manager.isPrefetch(c))
            it = states_.erase(it);
        else
            ++it;
    }

    for (const auto& c : manager.prefetch())
        states_[c] = ChunkState::Prefetch;

    for (const auto& c : manager.active())
        states_[c] = ChunkState::Active;
}

ChunkState ChunkLifecycle::state(const ChunkCoord& c) const {
    auto it = states_.find(c);
    return it == states_.end() ? ChunkState::Cold : it->second;
}

size_t ChunkLifecycle::activeCount() const {
    size_t n = 0;
    for (const auto& p : states_)
        if (p.second == ChunkState::Active) ++n;
    return n;
}

size_t ChunkLifecycle::prefetchCount() const {
    size_t n = 0;
    for (const auto& p : states_)
        if (p.second == ChunkState::Prefetch) ++n;
    return n;
}

} // namespace ff1
