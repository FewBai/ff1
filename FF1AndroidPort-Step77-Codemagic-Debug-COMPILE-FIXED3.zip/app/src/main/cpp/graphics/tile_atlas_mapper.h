#pragma once
#include <cstdint>
#include <unordered_map>
namespace ff1 {
class TileAtlasMapper {
public:
    void set(uint16_t tileId, int atlasRegionId);
    int regionFor(uint16_t tileId, int fallback = -1) const;
    bool contains(uint16_t tileId) const;
    size_t size() const { return regions_.size(); }
private:
    std::unordered_map<uint16_t,int> regions_;
};
}
