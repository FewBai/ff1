#pragma once
#include "debug_frame_scope.h"
namespace ff1 {
class DebugRenderFrame {
public:
    explicit DebugRenderFrame(DebugRuntimeBridge& runtime):scope_(runtime){}
    DebugRuntimeBridge& runtime(){return scope_.runtime();}
    void recordDraw(){runtime().overlay().recordDrawCall();}
    void recordCacheHit(){runtime().overlay().recordCacheHit();}
    void recordCacheMiss(){runtime().overlay().recordCacheMiss();}
    void recordMissingTile(){runtime().overlay().recordMissingTile();}
    void setTiles(size_t visible,size_t submitted){runtime().overlay().setTileCounts(visible,submitted);}
private:
    DebugFrameScope scope_;
};
}
