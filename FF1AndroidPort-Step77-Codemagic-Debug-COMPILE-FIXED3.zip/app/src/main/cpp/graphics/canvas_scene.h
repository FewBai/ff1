#pragma once
#include "render_actor.h"
#include <vector>

namespace ff1 {

enum class Direction { Down, Left, Right, Up };

struct CanvasActorState {
    int actorId = 0;
    int worldX = 0;
    int worldY = 0;
    Direction direction = Direction::Down;
    bool moving = false;
    bool visible = true;
    int animationId = 0;
};

class CanvasScene {
public:
    void setActor(const CanvasActorState& state);
    void update(int deltaMs, const SpriteManager& sprites);
    const std::vector<CanvasActorState>& actors() const { return actors_; }

    static int animationFor(Direction direction, bool moving, bool chestOpen = false);

private:
    std::vector<CanvasActorState> actors_;
};

} // namespace ff1
