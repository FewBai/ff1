#pragma once
#include <cstdint>
#include <vector>
namespace ff1 {
struct MapTile {
    uint16_t tileId=0;
    uint8_t collision=0;
    uint8_t flags=0;
};
class MapTileGrid {
public:
    MapTileGrid(int width=0,int height=0):width_(width),height_(height),tiles_(width*height){}
    void resize(int width,int height){width_=width;height_=height;tiles_.assign(width*height,{});}
    int width()const{return width_;}
    int height()const{return height_;}
    MapTile& at(int x,int y){return tiles_.at(y*width_+x);}
    const MapTile& at(int x,int y)const{return tiles_.at(y*width_+x);}
private:
    int width_=0,height_=0;
    std::vector<MapTile> tiles_;
};
}
