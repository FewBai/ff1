#pragma once
#include <cstddef>
namespace ff1 {
struct DebugOverlayStats {
    double fps=0.0;
    double frameMs=0.0;
    double averageFrameMs=0.0;
    double worstFrameMs=0.0;
    size_t drawCalls=0;
    size_t cacheHits=0;
    size_t cacheMisses=0;
    size_t missingTileIds=0;
    size_t visibleTiles=0;
    size_t submittedTiles=0;
    size_t cacheBytes=0;
    size_t atlasBytes=0;
    bool overBudget=false;
    bool enabled=true;
};
}
