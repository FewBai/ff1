#pragma once

#include "canvas_atlas_renderer.h"
#include <functional>
#include <memory>
#include <vector>

namespace ff1 {

class AndroidCanvasBridge {
public:
    using BitmapReady = std::function<bool(int)>;

    // Owning overload, retained for the earlier Step 46/47 API.
    void setRenderer(CanvasAtlasRenderer renderer);

    void setCamera(CameraRect camera);
    size_t render(
        const std::vector<SpriteDraw>& sprites,
        const BitmapReady& ready,
        const std::function<void(const CanvasDrawCommand&)>& draw);

private:
    CanvasAtlasRenderer* renderer_ = nullptr;
    std::unique_ptr<CanvasAtlasRenderer> ownedRenderer_;
};

} // namespace ff1
