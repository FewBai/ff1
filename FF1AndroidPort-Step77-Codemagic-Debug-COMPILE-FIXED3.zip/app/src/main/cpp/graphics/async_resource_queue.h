#pragma once
#include "resource_cache.h"
#include <functional>
#include <queue>
namespace ff1 {
struct ResourceRequest {int id=0,width=0,height=0;std::vector<uint8_t> rgba;};
class AsyncResourceQueue {
public:
 using Loader=std::function<bool(const ResourceRequest&,CachedBitmap&)>;
 void enqueue(ResourceRequest r); size_t pending()const{return queue_.size();}
 size_t pump(ResourceCache& cache,const Loader& loader,size_t maxItems);
private: std::queue<ResourceRequest> queue_;
};
}
