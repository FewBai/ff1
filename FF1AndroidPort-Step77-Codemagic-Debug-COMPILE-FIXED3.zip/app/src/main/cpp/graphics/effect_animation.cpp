#include "effect_animation.h"

namespace ff1 {

void EffectAnimationSystem::start(EffectInstance& effect,
                                  const SpriteManager& manager,
                                  int animationId) {
    if (!manager.animation(animationId)) {
        effect.active = false;
        return;
    }
    effect.animationId = animationId;
    effect.elapsedMs = 0;
    effect.active = true;
    return;
}

bool EffectAnimationSystem::update(EffectInstance& effect, AnimationPlayer& player,
                                   const SpriteManager& manager, int deltaMs) {
    if (!effect.active) return false;
    if (player.animationId() != effect.animationId)
        player.setAnimation(manager, effect.animationId);

    player.update(deltaMs, manager);
    effect.elapsedMs += deltaMs;

    const auto* anim = manager.animation(effect.animationId);
    if (!anim || anim->frames.empty()) {
        effect.active = false;
        return false;
    }

    if (!anim->loop && player.frameIndex() ==
        static_cast<int>(anim->frames.size()) - 1) {
        effect.active = false;
    }
    return true;
}

} // namespace ff1
