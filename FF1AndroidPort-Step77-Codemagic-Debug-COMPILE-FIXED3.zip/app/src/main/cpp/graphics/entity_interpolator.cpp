#include "entity_interpolator.h"
#include <algorithm>
#include <cmath>

namespace ff1 {

void EntityInterpolator::snap(float x, float y) {
    current_ = {x, y};
    target_ = current_;
}

void EntityInterpolator::setTarget(float x, float y) {
    target_ = {x, y};
}

InterpolatedPosition EntityInterpolator::update(
    float deltaSeconds, float speedPixelsPerSecond) {

    if (deltaSeconds <= 0.0f || speedPixelsPerSecond <= 0.0f)
        return current_;

    const float dx = target_.x - current_.x;
    const float dy = target_.y - current_.y;
    const float distance = std::sqrt(dx * dx + dy * dy);

    if (distance <= 0.001f) {
        current_ = target_;
        return current_;
    }

    const float step = speedPixelsPerSecond * deltaSeconds;
    if (step >= distance) {
        current_ = target_;
    } else {
        current_.x += dx / distance * step;
        current_.y += dy / distance * step;
    }
    return current_;
}

} // namespace ff1
