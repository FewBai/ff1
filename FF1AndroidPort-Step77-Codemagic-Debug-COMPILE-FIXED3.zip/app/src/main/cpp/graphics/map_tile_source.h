#pragma once
#include "map_tile_data.h"
namespace ff1 {
class MapTileSource {
public:
    explicit MapTileSource(const MapTileGrid& grid):grid_(grid){}
    bool tileAtWorld(int worldX,int worldY,int tileW,int tileH,MapTile& out)const;
private:
    const MapTileGrid& grid_;
};
}
