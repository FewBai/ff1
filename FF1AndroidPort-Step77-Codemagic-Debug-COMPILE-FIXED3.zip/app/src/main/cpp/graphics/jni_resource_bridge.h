#pragma once
#include "android_resource_bridge.h"
#include <functional>
#include <vector>

namespace ff1 {

class JniResourceBridge {
public:
    using RequestSink = std::function<void(int resourceId, int priority)>;

    explicit JniResourceBridge(AndroidResourceBridge& bridge)
        : bridge_(bridge) {}

    size_t dispatch(RequestSink sink, size_t maxRequests);

private:
    AndroidResourceBridge& bridge_;
};

} // namespace ff1
