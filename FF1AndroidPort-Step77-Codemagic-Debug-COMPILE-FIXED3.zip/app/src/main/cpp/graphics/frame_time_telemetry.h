#pragma once
#include <cstddef>

namespace ff1 {

struct FrameTimeTelemetry {
    double lastMs = 0.0;
    double averageMs = 0.0;
    double worstMs = 0.0;
    size_t frameCount = 0;
    size_t overBudgetFrames = 0;

    void record(double milliseconds, double budgetMs = 16.67);
};

} // namespace ff1
