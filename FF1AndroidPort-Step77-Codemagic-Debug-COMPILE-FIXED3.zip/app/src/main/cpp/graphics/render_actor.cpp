#include "render_actor.h"

namespace ff1 {

void RenderActorSystem::add(const RenderActor& actor) {
    for (const auto& r : actors_) {
        if (r.actor.id == actor.id) return;
    }
    actors_.push_back({actor, {}});
}

bool RenderActorSystem::setAnimation(int actorId, const SpriteManager& manager,
                                     int animationId) {
    for (auto& r : actors_) {
        if (r.actor.id == actorId) {
            if (!manager.animation(animationId)) return false;
            r.actor.sprite.animationId = animationId;
            r.player.setAnimation(manager, animationId);
            return true;
        }
    }
    return false;
}

void RenderActorSystem::update(int deltaMs, const SpriteManager& manager) {
    for (auto& r : actors_)
        r.player.update(deltaMs, manager);
}

int RenderActorSystem::frameIndex(int actorId) const {
    for (const auto& r : actors_)
        if (r.actor.id == actorId) return r.player.frameIndex();
    return -1;
}

} // namespace ff1
