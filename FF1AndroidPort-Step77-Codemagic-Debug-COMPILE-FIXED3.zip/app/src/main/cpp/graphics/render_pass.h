#pragma once
#include "canvas_atlas_renderer.h"
#include <functional>
#include <vector>
#include <cstddef>
namespace ff1 {
enum class RenderPassLayer { Map=0, Actor=1, Effect=2, UI=3 };
struct RenderPassItem { RenderPassLayer layer=RenderPassLayer::Actor; int z=0; SpriteDraw sprite{}; };
class RenderPass {
public:
 void clear();
 void add(const RenderPassItem& item);
 size_t draw(const CanvasAtlasRenderer& renderer,
  const std::function<bool(int)>& bitmapReady,
  const std::function<void(const CanvasDrawCommand&)>& draw,
  size_t maxCommands) const;
private:
 std::vector<RenderPassItem> items_;
};
}
