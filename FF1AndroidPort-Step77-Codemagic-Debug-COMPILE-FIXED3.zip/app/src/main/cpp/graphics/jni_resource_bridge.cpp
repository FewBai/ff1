#include "jni_resource_bridge.h"

namespace ff1 {

size_t JniResourceBridge::dispatch(RequestSink sink, size_t maxRequests) {
    if (!sink) return 0;
    size_t count = 0;
    AndroidResourceRequest req;
    while (count < maxRequests && bridge_.poll(req)) {
        sink(req.id, req.priority);
        ++count;
    }
    return count;
}

} // namespace ff1
