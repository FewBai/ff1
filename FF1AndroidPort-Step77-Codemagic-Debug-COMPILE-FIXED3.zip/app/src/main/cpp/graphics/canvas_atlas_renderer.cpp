#include "canvas_atlas_renderer.h"

#include <cassert>

namespace ff1 {

void CanvasAtlasRenderer::setAtlas(int resourceId, TextureAtlas atlas) {
    atlasResourceId_ = resourceId;
    atlas_ = std::move(atlas);
}

bool CanvasAtlasRenderer::buildCommand(
    const SpriteDraw& sprite, CanvasDrawCommand& out) const {
    if (sprite.resourceId != atlasResourceId_) return false;
    if (sprite.width <= 0 || sprite.height <= 0) return false;

    const AtlasRegion* region = atlas_.region(sprite.atlasRegionId);
    if (!region) return false;

    const int screenWidth = static_cast<int>(camera_.right - camera_.left);
    const int screenHeight = static_cast<int>(camera_.bottom - camera_.top);
    const int screenX = sprite.worldX - static_cast<int>(camera_.left);
    const int screenY = sprite.worldY - static_cast<int>(camera_.top);

    if (screenX + sprite.width <= 0 || screenY + sprite.height <= 0 ||
        screenX >= screenWidth || screenY >= screenHeight) {
        return false;
    }

    out.resourceId = sprite.resourceId;
    out.src = *region;
    out.screenX = screenX;
    out.screenY = screenY;
    out.dstWidth = sprite.width;
    out.dstHeight = sprite.height;
    return true;
}

std::vector<CanvasDrawCommand> CanvasAtlasRenderer::buildVisible(
    const std::vector<SpriteDraw>& sprites) const {
    std::vector<CanvasDrawCommand> commands;
    commands.reserve(sprites.size());
    for (const auto& sprite : sprites) {
        CanvasDrawCommand command;
        if (buildCommand(sprite, command)) commands.push_back(command);
    }
    return commands;
}

void CanvasAtlasRenderer::beginFrame() {
    if (debug_) debug_->beginFrame();
}

void CanvasAtlasRenderer::endFrame(double frameMs) {
    if (debug_) debug_->endFrame(frameMs);
}

DebugRuntimeBridge& CanvasAtlasRenderer::debug() {
    assert(debug_ != nullptr);
    return *debug_;
}

const DebugRuntimeBridge& CanvasAtlasRenderer::debug() const {
    assert(debug_ != nullptr);
    return *debug_;
}

} // namespace ff1
