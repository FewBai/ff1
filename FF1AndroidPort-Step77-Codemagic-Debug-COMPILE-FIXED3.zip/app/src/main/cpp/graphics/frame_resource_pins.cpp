#include "frame_resource_pins.h"
