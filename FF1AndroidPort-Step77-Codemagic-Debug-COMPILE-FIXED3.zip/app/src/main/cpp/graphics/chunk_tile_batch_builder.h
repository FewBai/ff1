#pragma once
#include "map_chunk_manager.h"
#include "tile_batch_renderer.h"
#include <functional>

namespace ff1 {

struct ChunkTileLayout {
    int tileWidth = 16;
    int tileHeight = 16;
    int tilesPerChunkX = 16;
    int tilesPerChunkY = 16;
    int resourceId = 0;
    int atlasRegionId = 0;
};

class ChunkTileBatchBuilder {
public:
    explicit ChunkTileBatchBuilder(ChunkTileLayout layout) : layout_(layout) {}

    void build(const MapChunkManager& chunks,
               const ChunkBounds& visible,
               TileBatchRenderer& out,
               const std::function<int(int,int)>& atlasForTile = {}) const;

private:
    ChunkTileLayout layout_;
};

} // namespace ff1
