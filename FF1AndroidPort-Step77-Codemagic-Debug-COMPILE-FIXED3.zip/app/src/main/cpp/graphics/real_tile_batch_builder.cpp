#include "real_tile_batch_builder.h"
namespace ff1 {
void RealTileBatchBuilder::build(const ChunkBounds& visible,TileBatchRenderer& out,
                                 int* missingTileIds)const{
    out.clear();
    if(missingTileIds) *missingTileIds=0;
    const int left=visible.left/tileW_;
    const int top=visible.top/tileH_;
    const int right=(visible.right+tileW_-1)/tileW_;
    const int bottom=(visible.bottom+tileH_-1)/tileH_;
    for(int y=top;y<bottom;++y){
        for(int x=left;x<right;++x){
            if(x<0||y<0||x>=grid_.width()||y>=grid_.height()) continue;
            const auto& tile=grid_.at(x,y);
            const int region=mapper_.regionFor(tile.tileId,-1);
            if(region<0){
                if(missingTileIds) ++*missingTileIds;
                continue;
            }
            out.add({resourceId_,region,x*tileW_,y*tileH_,tileW_,tileH_});
        }
    }
}
}
