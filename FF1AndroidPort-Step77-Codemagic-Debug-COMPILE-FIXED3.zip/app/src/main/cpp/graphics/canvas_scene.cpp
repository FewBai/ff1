#include "canvas_scene.h"

namespace ff1 {

void CanvasScene::setActor(const CanvasActorState& state) {
    for (auto& a : actors_) {
        if (a.actorId == state.actorId) {
            a = state;
            return;
        }
    }
    actors_.push_back(state);
}

void CanvasScene::update(int, const SpriteManager&) {
    // Animation timing remains in AnimationPlayer/RenderActorSystem.
    // This scene layer only owns world-space render state.
}

int CanvasScene::animationFor(Direction direction, bool moving, bool chestOpen) {
    if (chestOpen) return 900; // reserved for one-shot chest-open animation
    if (!moving) {
        switch (direction) {
            case Direction::Down:  return 100;
            case Direction::Left:  return 110;
            case Direction::Right: return 120;
            case Direction::Up:    return 130;
        }
    }
    switch (direction) {
        case Direction::Down:  return 101;
        case Direction::Left:  return 111;
        case Direction::Right: return 121;
        case Direction::Up:    return 131;
    }
    return 100;
}

} // namespace ff1
