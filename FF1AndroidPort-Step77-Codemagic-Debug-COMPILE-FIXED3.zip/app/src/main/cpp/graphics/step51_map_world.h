#pragma once
#include "camera_follow.h"
#include "map_tile_source.h"
#include "player_collision.h"
#include "step50_map_frame.h"
namespace ff1 {
struct Step51WorldState {
    PlayerPosition player;
    CameraFollowResult camera;
    Step50FrameResult render;
};
class Step51MapWorld {
public:
    Step51WorldState updateAndRender(
        const MapTileSource& tiles,
        const PlayerPosition& desiredMove,
        float dt,
        int tileW,int tileH,
        float cameraX,float cameraY,
        const MapChunkManager& chunks,const ChunkBounds& visible,
        TileMapRenderLoop& loop,const RenderPass& entities,
        const std::function<bool(int)>& bitmapReady,
        const std::function<void(const CanvasDrawCommand&)>& draw,
        size_t maxMap,size_t maxEntities,double frameMs);
private:
    PlayerPosition player_{};
    PlayerCollision collision_;
    CameraFollow cameraFollow_;
};
}
