#pragma once
#include "debug_overlay_stats.h"
#include <string>
namespace ff1 {
class DebugOverlayController {
public:
    void setEnabled(bool enabled) { stats_.enabled=enabled; }
    bool enabled() const { return stats_.enabled; }
    void update(double frameMs,size_t drawCalls,size_t cacheHits,size_t cacheMisses,
                size_t missingTileIds,size_t visibleTiles,size_t submittedTiles,
                size_t cacheBytes=0,size_t atlasBytes=0);
    const DebugOverlayStats& stats() const { return stats_; }
    std::string text() const;
private:
    DebugOverlayStats stats_;
};
}
