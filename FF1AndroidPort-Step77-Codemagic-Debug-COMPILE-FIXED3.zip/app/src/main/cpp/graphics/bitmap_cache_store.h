#include <cstdint>
#pragma once
#include <unordered_map>
#include <cstddef>
namespace ff1 {
struct BitmapCacheEntry { int id=0; size_t bytes=0; bool ready=false; };
class BitmapCacheStore {
public:
    void erase(std::int32_t id) { entries_.erase(id); }
 bool contains(int id) const { return entries_.count(id)!=0; }
 bool ready(int id) const { auto it=entries_.find(id); return it!=entries_.end()&&it->second.ready; }
 bool publish(int id,size_t bytes){ entries_[id]={id,bytes,true}; return true; }
 size_t size() const{return entries_.size();}
 size_t bytes() const{size_t n=0;for(const auto&e:entries_)n+=e.second.bytes;return n;}
private: std::unordered_map<int,BitmapCacheEntry> entries_;

};
}
