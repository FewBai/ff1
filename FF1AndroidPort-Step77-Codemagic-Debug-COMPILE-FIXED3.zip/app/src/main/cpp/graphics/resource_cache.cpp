#include "resource_cache.h"
namespace ff1 {
ResourceCache::ResourceCache(size_t m):maxBytes_(m){}
void ResourceCache::touch(Entry&e){lru_.erase(e.lruIt);lru_.push_front(e.bitmap.id);e.lruIt=lru_.begin();}
bool ResourceCache::put(CachedBitmap b){
 if(b.id<0||b.width<=0||b.height<=0||b.bytes()>maxBytes_)return false;
 erase(b.id); lru_.push_front(b.id);
 entries_.emplace(b.id,Entry{std::move(b),lru_.begin()});
 bytesUsed_+=entries_.at(lru_.front()).bitmap.bytes(); evict();
 return contains(lru_.front());
}
const CachedBitmap* ResourceCache::get(int id){auto it=entries_.find(id);if(it==entries_.end())return nullptr;touch(it->second);return &it->second.bitmap;}
bool ResourceCache::contains(int id)const{return entries_.find(id)!=entries_.end();}
void ResourceCache::erase(int id){auto it=entries_.find(id);if(it==entries_.end())return;bytesUsed_-=it->second.bitmap.bytes();lru_.erase(it->second.lruIt);entries_.erase(it);}
void ResourceCache::clear(){entries_.clear();lru_.clear();bytesUsed_=0;}
void ResourceCache::setMaxBytes(size_t b){maxBytes_=b;evict();}
void ResourceCache::evict(){while(bytesUsed_>maxBytes_&&!lru_.empty())erase(lru_.back());}
}
