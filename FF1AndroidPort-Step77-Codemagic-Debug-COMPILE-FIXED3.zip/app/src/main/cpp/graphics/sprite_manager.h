#pragma once
#include "sprite_types.h"
#include <unordered_map>

namespace ff1 {

class SpriteManager {
public:
    void clear();
    bool registerAnimation(const SpriteAnimation& animation);
    const SpriteAnimation* animation(int id) const;
    bool registerResource(int id, const std::vector<uint8_t>& rgba,
                          int width, int height);
    const std::vector<uint8_t>* resource(int id) const;

private:
    struct Resource {
        std::vector<uint8_t> rgba;
        int width = 0;
        int height = 0;
    };

    std::unordered_map<int, SpriteAnimation> animations_;
    std::unordered_map<int, Resource> resources_;
};

} // namespace ff1
