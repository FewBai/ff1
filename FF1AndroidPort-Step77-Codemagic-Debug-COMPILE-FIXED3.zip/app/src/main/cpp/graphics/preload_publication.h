#pragma once
#include "bitmap_cache_store.h"
#include "debug_runtime_bridge.h"
namespace ff1 {
class PreloadPublication {
public:
 PreloadPublication(BitmapCacheStore& c,DebugRuntimeBridge& d):cache_(c),debug_(d){}
 bool publishDecoded(int id,size_t bytes){bool ok=cache_.publish(id,bytes);if(ok)debug_.memory().bitmapLoaded(bytes);return ok;}
private: BitmapCacheStore& cache_;DebugRuntimeBridge& debug_;
};
}
