#pragma once
#include "sprite_manager.h"

namespace ff1 {

class AnimationPlayer {
public:
    void setAnimation(const SpriteManager& manager, int animationId);
    void update(int deltaMs, const SpriteManager& manager);

    int frameIndex() const { return frameIndex_; }
    int animationId() const { return animationId_; }

private:
    int animationId_ = 0;
    int frameIndex_ = 0;
    int elapsedMs_ = 0;
};

} // namespace ff1
