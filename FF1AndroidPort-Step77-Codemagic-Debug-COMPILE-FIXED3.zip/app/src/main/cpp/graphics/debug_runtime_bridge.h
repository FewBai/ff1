#pragma once
#include "debug_memory_registry.h"
#include "debug_overlay_bridge.h"
namespace ff1 {
class DebugRuntimeBridge {
public:
    DebugMemoryRegistry& memory(){return memory_;}
    void beginFrame(){overlay_.beginFrame();}
    void endFrame(double ms){
        auto m=memory_.snapshot();
        overlay_.setMemoryCounters(m);
        overlay_.endFrame(ms);
    }
    DebugOverlayBridge& overlay(){return overlay_;}
private:
    DebugMemoryRegistry memory_;
    DebugOverlayBridge overlay_;
};
}
