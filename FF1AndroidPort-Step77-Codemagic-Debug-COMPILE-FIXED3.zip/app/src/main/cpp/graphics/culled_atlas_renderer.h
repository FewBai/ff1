#pragma once
#include "atlas_crop_renderer.h"
#include "camera_culling.h"
namespace ff1 {
class CulledAtlasRenderer{
public:
 explicit CulledAtlasRenderer(AtlasCropRenderer&r):atlas_(r){}
 template<class Canvas,class Provider>
 size_t render(Canvas& canvas,const VisibleChunk& chunk,const Camera& camera,
               float viewW,float viewH,Provider& provider,size_t& visible,size_t& submitted){
  visible=0;submitted=0;Viewport v=cameraViewport(camera,viewW,viewH);
  for(size_t i=0;i<chunk.count;++i){
   const auto&t=chunk.tiles[i];
   if(!intersects(v,t.worldX,t.worldY,t.width,t.height)) continue;
   ++visible;++submitted;
   VisibleChunk one{&t,1};
   atlas_.renderChunk(canvas,one,camera,provider);
  }
  return submitted;
 }
private:AtlasCropRenderer& atlas_;
};
}
