#include "tile_batch_renderer.h"
namespace ff1 {
void TileBatchRenderer::clear(){tiles_.clear();}
void TileBatchRenderer::add(const TileSprite& tile){tiles_.push_back(tile);}
TileBatchStats TileBatchRenderer::buildVisible(
 const CanvasAtlasRenderer& renderer,
 const std::function<bool(int)>& bitmapReady,
 const std::function<void(const CanvasDrawCommand&)>& draw,
 size_t maxCommands) const {
 TileBatchStats s{}; s.submitted=tiles_.size(); size_t emitted=0;
 for(const auto& tile:tiles_){
  CanvasDrawCommand c;
  SpriteDraw sp{tile.resourceId,tile.atlasRegionId,tile.worldX,tile.worldY,tile.width,tile.height};
  if(!renderer.buildCommand(sp,c)) continue;
  ++s.visible;
  if(emitted>=maxCommands) continue;
  if(bitmapReady && !bitmapReady(c.resourceId)){++s.cacheMisses;continue;}
  if(draw) draw(c);
  ++emitted; ++s.drawn;
 }
 return s;
}
}
