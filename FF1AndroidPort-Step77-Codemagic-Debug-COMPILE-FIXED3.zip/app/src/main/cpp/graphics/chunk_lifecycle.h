#pragma once
#include "map_chunk_manager.h"
#include <unordered_map>

namespace ff1 {

enum class ChunkState {
    Cold,
    Prefetch,
    Active
};

class ChunkLifecycle {
public:
    void sync(const MapChunkManager& manager);
    ChunkState state(const ChunkCoord& c) const;
    size_t activeCount() const;
    size_t prefetchCount() const;

private:
    std::unordered_map<ChunkCoord, ChunkState, ChunkCoordHash> states_;
};

} // namespace ff1
