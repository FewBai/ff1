#pragma once
#include <deque>
#include <unordered_set>
#include <functional>
#include <cstddef>
namespace ff1 {
class PreloadQueue {
public:
 explicit PreloadQueue(size_t capacity=32):capacity_(capacity){}
 bool request(int id){
  if(resident_.count(id)||queued_.count(id)||loading_.count(id)) return false;
  if(queue_.size()>=capacity_) queue_.pop_front();
  queue_.push_back(id);queued_.insert(id);return true;
 }
 bool pop(int& id){
  if(queue_.empty())return false;
  id=queue_.front();queue_.pop_front();queued_.erase(id);loading_.insert(id);return true;
 }
 void complete(int id){loading_.erase(id);resident_.insert(id);}
 bool resident(int id)const{return resident_.count(id)!=0;}
 size_t size()const{return queue_.size();}
private:
 size_t capacity_;std::deque<int> queue_;
 std::unordered_set<int> queued_,loading_,resident_;
};
}
