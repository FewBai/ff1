#include "texture_atlas.h"
namespace ff1 {
bool TextureAtlas::define(int id,int x,int y,int width,int height){
 if(id<0||x<0||y<0||width<=0||height<=0)return false;
 regions_[id]={id,x,y,width,height}; return true;
}
const AtlasRegion* TextureAtlas::region(int id)const{
 auto it=regions_.find(id); return it==regions_.end()?nullptr:&it->second;
}
void TextureAtlas::clear(){regions_.clear();}
}
