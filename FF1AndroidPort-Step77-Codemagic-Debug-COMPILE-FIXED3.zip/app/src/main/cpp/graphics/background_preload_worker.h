#pragma once
#include "preload_queue.h"
namespace ff1 {
class BackgroundPreloadWorker {
public:
 template<class Decode,class Ready>
 size_t drain(PreloadQueue& q,Decode&& decode,Ready&& ready,size_t budget){
  size_t n=0;int id;
  while(n<budget&&q.pop(id)){decode(id);ready(id);q.complete(id);++n;}
  return n;
 }
};
}
