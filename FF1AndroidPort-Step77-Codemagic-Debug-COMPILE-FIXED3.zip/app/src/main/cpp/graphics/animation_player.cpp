#include "animation_player.h"
#include <algorithm>

namespace ff1 {

void AnimationPlayer::setAnimation(const SpriteManager& manager, int animationId) {
    if (!manager.animation(animationId)) return;
    animationId_ = animationId;
    frameIndex_ = 0;
    elapsedMs_ = 0;
}

void AnimationPlayer::update(int deltaMs, const SpriteManager& manager) {
    const auto* anim = manager.animation(animationId_);
    if (!anim || anim->frames.empty() || deltaMs <= 0) return;

    elapsedMs_ += deltaMs;
    while (elapsedMs_ >= std::max(1, anim->frames[frameIndex_].durationMs)) {
        elapsedMs_ -= std::max(1, anim->frames[frameIndex_].durationMs);
        ++frameIndex_;
        if (frameIndex_ >= static_cast<int>(anim->frames.size())) {
            frameIndex_ = anim->loop
                ? 0
                : static_cast<int>(anim->frames.size()) - 1;
        }
    }
}

} // namespace ff1
