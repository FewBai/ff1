#pragma once
#include "bitmap_cache_store.h"
#include "bitmap_provider.h"

namespace ff1 {

// Native-side gate used by the Canvas renderer: a tile is submitted only
// when the Android Bitmap adapter reports a published/ready entry.
class RendererBitmapCache final : public BitmapProvider {
public:
    explicit RendererBitmapCache(BitmapCacheStore& store) : store_(store) {}

    bool contains(std::int32_t id) const override { return store_.contains(id); }
    bool ready(std::int32_t id) const override { return store_.ready(id); }

private:
    BitmapCacheStore& store_;
};

} // namespace ff1
