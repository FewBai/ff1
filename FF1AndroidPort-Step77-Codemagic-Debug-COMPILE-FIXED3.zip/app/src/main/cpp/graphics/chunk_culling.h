#pragma once
#include "camera_culling.h"
#include <vector>
namespace ff1 {
struct ChunkBounds{int id;float x,y,w,h;};
struct ChunkRef{ChunkBounds bounds;VisibleChunk tiles;};
class ChunkCuller{
public:
 template<class F>
 size_t forVisible(const std::vector<ChunkRef>& chunks,const Camera& camera,float vw,float vh,F&& fn) const{
  Viewport v=cameraViewport(camera,vw,vh);size_t n=0;
  for(const auto& c:chunks){
   if(!intersects(v,c.bounds.x,c.bounds.y,c.bounds.w,c.bounds.h))continue;
   fn(c);++n;
  }
  return n;
 }
};
}
