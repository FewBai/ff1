#pragma once
namespace ff1 {
struct CameraFollowResult { float x=0,y=0; };
class CameraFollow {
public:
    void setDeadZone(float left,float top,float right,float bottom);
    CameraFollowResult update(float cameraX,float cameraY,
                              float targetX,float targetY)const;
private:
    float left_=64,top_=48,right_=192,bottom_=144;
};
}
