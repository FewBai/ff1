#include "android_resource_bridge.h"

namespace ff1 {

void AndroidResourceBridge::update(const ChunkBounds& visible,
                                   int cameraDx, int cameraDy) {
    queue_.clear();
    requests_.clear();
    cursor_ = 0;

    chunks_.updateInterest(visible, cameraDx, cameraDy, queue_);

    PrioritizedResourceRequest item;
    while (queue_.pop(item)) {
        requests_.push_back({
            item.request.id,
            static_cast<int>(item.priority)
        });
    }
}

bool AndroidResourceBridge::poll(AndroidResourceRequest& out) {
    if (cursor_ >= requests_.size()) return false;
    out = requests_[cursor_++];
    return true;
}

void AndroidResourceBridge::clear() {
    queue_.clear();
    requests_.clear();
    cursor_ = 0;
}

} // namespace ff1
