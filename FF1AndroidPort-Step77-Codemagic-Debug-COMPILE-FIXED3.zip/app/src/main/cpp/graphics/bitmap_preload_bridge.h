#pragma once
#include "debug_runtime_bridge.h"
#include <functional>
namespace ff1 {
class BitmapPreloadBridge {
public:
 using Loader=std::function<void(int)>;
 BitmapPreloadBridge(DebugRuntimeBridge& d,Loader l):debug_(d),loader_(std::move(l)){}
 void request(int bitmapId){ loader_(bitmapId); }
private: DebugRuntimeBridge& debug_; Loader loader_;
};
}
