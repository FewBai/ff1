#include "tile_map_render_loop.h"
#include <utility>
namespace ff1 {
void TileMapRenderLoop::setRenderer(CanvasAtlasRenderer renderer){renderer_=std::move(renderer);}
TileMapFrameStats TileMapRenderLoop::render(
 const TileBatchRenderer& map,const RenderPass& entities,
 const std::function<bool(int)>& bitmapReady,
 const std::function<void(const CanvasDrawCommand&)>& draw,
 size_t maxMapCommands,size_t maxEntityCommands){
 TileMapFrameStats s{};
 s.map=map.buildVisible(renderer_,bitmapReady,draw,maxMapCommands);
 s.entitiesDrawn=entities.draw(renderer_,bitmapReady,draw,maxEntityCommands);
 s.totalDrawn=s.map.drawn+s.entitiesDrawn;
 return s;
}
}
