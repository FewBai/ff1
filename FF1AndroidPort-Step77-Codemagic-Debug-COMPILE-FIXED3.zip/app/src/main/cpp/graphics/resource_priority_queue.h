#pragma once
#include "async_resource_queue.h"
#include <queue>
#include <vector>

namespace ff1 {

enum class ResourcePriority {
    CurrentFrame = 0,
    Visible = 1,
    Prefetch = 2,
    Background = 3
};

struct PrioritizedResourceRequest {
    ResourcePriority priority = ResourcePriority::Background;
    uint64_t sequence = 0;
    ResourceRequest request;
};

class ResourcePriorityQueue {
public:
    void enqueue(PrioritizedResourceRequest request);
    size_t pending() const { return queue_.size(); }
    bool pop(PrioritizedResourceRequest& out);
    void clear();

private:
    struct Compare {
        bool operator()(const PrioritizedResourceRequest& a,
                        const PrioritizedResourceRequest& b) const {
            if (a.priority != b.priority)
                return static_cast<int>(a.priority) >
                       static_cast<int>(b.priority);
            return a.sequence > b.sequence;
        }
    };

    std::priority_queue<PrioritizedResourceRequest,
                        std::vector<PrioritizedResourceRequest>, Compare> queue_;
};

} // namespace ff1
