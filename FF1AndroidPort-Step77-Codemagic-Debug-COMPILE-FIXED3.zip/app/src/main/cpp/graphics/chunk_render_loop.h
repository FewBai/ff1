#pragma once
#include "chunk_culling.h"
#include "culled_atlas_renderer.h"
namespace ff1 {
class ChunkRenderLoop{
public:
 explicit ChunkRenderLoop(CulledAtlasRenderer&r):renderer_(r){}
 template<class Canvas,class Provider>
 size_t render(Canvas& canvas,const std::vector<ChunkRef>& chunks,const Camera& camera,
               float vw,float vh,Provider& provider,size_t& visibleTiles,size_t& submittedTiles){
  visibleTiles=submittedTiles=0;size_t chunksDrawn=0;
  culler_.forVisible(chunks,camera,vw,vh,[&](const ChunkRef& c){
   size_t v=0,s=0;renderer_.render(canvas,c.tiles,camera,vw,vh,provider,v,s);
   visibleTiles+=v;submittedTiles+=s;++chunksDrawn;
  }); return chunksDrawn;
 }
private:ChunkCuller culler_;CulledAtlasRenderer& renderer_;
};
}
