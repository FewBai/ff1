#pragma once
namespace ff1 {

struct InterpolatedPosition {
    float x = 0.0f;
    float y = 0.0f;
};

class EntityInterpolator {
public:
    void snap(float x, float y);
    void setTarget(float x, float y);
    InterpolatedPosition update(float deltaSeconds, float speedPixelsPerSecond);

    InterpolatedPosition current() const { return current_; }
    InterpolatedPosition target() const { return target_; }

private:
    InterpolatedPosition current_{};
    InterpolatedPosition target_{};
};

} // namespace ff1
