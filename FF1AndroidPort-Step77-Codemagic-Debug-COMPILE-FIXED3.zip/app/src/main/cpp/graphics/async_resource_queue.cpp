#include "async_resource_queue.h"
namespace ff1 {
void AsyncResourceQueue::enqueue(ResourceRequest r){queue_.push(std::move(r));}
size_t AsyncResourceQueue::pump(ResourceCache&c,const Loader&loader,size_t n){
 size_t done=0;while(done<n&&!queue_.empty()){auto r=std::move(queue_.front());queue_.pop();CachedBitmap b;if(loader&&loader(r,b))c.put(std::move(b));++done;}return done;
}
}
