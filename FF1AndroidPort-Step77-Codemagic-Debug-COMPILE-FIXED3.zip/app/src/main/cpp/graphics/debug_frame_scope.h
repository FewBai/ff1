#pragma once
#include "debug_runtime_bridge.h"
#include <chrono>
namespace ff1 {
class DebugFrameScope {
public:
    explicit DebugFrameScope(DebugRuntimeBridge& runtime):runtime_(runtime){
        start_=std::chrono::steady_clock::now();
        runtime_.beginFrame();
    }
    ~DebugFrameScope(){
        const auto end=std::chrono::steady_clock::now();
        const double ms=std::chrono::duration<double,std::milli>(end-start_).count();
        runtime_.endFrame(ms);
    }
    DebugRuntimeBridge& runtime(){return runtime_;}
private:
    DebugRuntimeBridge& runtime_;
    std::chrono::steady_clock::time_point start_;
};
}
