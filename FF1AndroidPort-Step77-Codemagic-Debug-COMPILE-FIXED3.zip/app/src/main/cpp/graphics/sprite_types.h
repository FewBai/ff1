#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace ff1 {

struct SpriteFrame {
    int resourceId = 0;
    int width = 16;
    int height = 16;
    int durationMs = 100;
};

struct SpriteAnimation {
    int id = 0;
    std::string name;
    std::vector<SpriteFrame> frames;
    bool loop = true;
};

struct SpriteInstance {
    int animationId = 0;
    int x = 0;
    int y = 0;
    bool visible = true;
    bool flipX = false;
};

} // namespace ff1
