#pragma once
#include "canvas_atlas_renderer.h"
#include <cstddef>
#include <vector>
namespace ff1 {
struct MapRenderItem {
    int bitmapId;
    float worldX, worldY;
    float screenX, screenY;
    bool cacheHit;
};
class MapRenderLoop {
public:
    explicit MapRenderLoop(CanvasAtlasRenderer& renderer):renderer_(renderer){}
    template<class Canvas,class BitmapProvider>
    void render(Canvas& canvas, BitmapProvider& bitmaps,
                size_t visibleTiles, size_t submittedTiles,
                double frameMs) {
        renderer_.beginFrame();
        size_t drawn=0;
        for (const auto& item : items_) {
            auto* bitmap=bitmaps.lookup(item.bitmapId);
            if (bitmap) {
                renderer_.cacheHit();
                renderer_.drawBitmap(canvas,*bitmap,item.screenX,item.screenY);
                ++drawn;
            } else {
                renderer_.cacheMiss();
                renderer_.missingTile();
            }
        }
        renderer_.setVisibleTiles(visibleTiles,submittedTiles);
        renderer_.endFrame(frameMs);
        lastDrawn_=drawn;
    }
    void setItems(const MapRenderItem* items,size_t count){items_=items?std::vector<MapRenderItem>(items,items+count):std::vector<MapRenderItem>{};}
    size_t lastDrawn() const{return lastDrawn_;}
private:
    CanvasAtlasRenderer& renderer_;
    std::vector<MapRenderItem> items_;
    size_t lastDrawn_=0;
};
}
