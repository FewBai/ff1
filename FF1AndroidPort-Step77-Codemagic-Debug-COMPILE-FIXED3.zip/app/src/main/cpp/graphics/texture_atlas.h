#pragma once
#include <unordered_map>
namespace ff1 {
struct AtlasRegion { int id=0,x=0,y=0,width=0,height=0; };
class TextureAtlas {
public:
 bool define(int id,int x,int y,int width,int height);
 const AtlasRegion* region(int id) const;
 void clear();
private: std::unordered_map<int,AtlasRegion> regions_;
};
}
