#include "render_pass.h"
#include <algorithm>
namespace ff1 {
void RenderPass::clear(){items_.clear();}
void RenderPass::add(const RenderPassItem& item){items_.push_back(item);}
size_t RenderPass::draw(const CanvasAtlasRenderer& renderer,
 const std::function<bool(int)>& bitmapReady,
 const std::function<void(const CanvasDrawCommand&)>& draw,
 size_t maxCommands) const {
 auto ordered=items_;
 std::stable_sort(ordered.begin(),ordered.end(),[](const auto&a,const auto&b){
  if(a.layer!=b.layer) return (int)a.layer<(int)b.layer;
  return a.z<b.z;
 });
 size_t count=0;
 for(const auto&item:ordered){
  if(count>=maxCommands) break;
  CanvasDrawCommand c;
  if(!renderer.buildCommand(item.sprite,c)) continue;
  if(bitmapReady && !bitmapReady(c.resourceId)) continue;
  if(draw) draw(c);
  ++count;
 }
 return count;
}
}
