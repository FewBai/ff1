#include "shop_system.h"

namespace ff1 {

bool ShopSystem::buyWeapon(uint8_t id, int& gil, Inventory& inventory) const {
    for (const auto& w : kWeapons) {
        if (w.id == id && gil >= w.price) {
            if (inventory.add(id, 1)) {
                gil -= w.price;
                return true;
            }
        }
    }
    return false;
}

bool ShopSystem::buyArmor(uint8_t id, int& gil, Inventory& inventory) const {
    for (const auto& a : kArmors) {
        if (a.id == id && gil >= a.price) {
            if (inventory.add(static_cast<uint8_t>(0x40 + id), 1)) {
                gil -= a.price;
                return true;
            }
        }
    }
    return false;
}

bool ShopSystem::buyPotion(int& gil, Inventory& inventory) const {
    constexpr int kPotionPrice = 40;
    constexpr uint8_t kPotionId = 0x20;
    if (gil < kPotionPrice) return false;
    if (!inventory.add(kPotionId, 1)) return false;
    gil -= kPotionPrice;
    return true;
}

} // namespace ff1
