#include "story_events.h"
namespace ff1 {
void StoryEventRunner::start(const std::vector<StoryCommand>& c){commands_=c;index_=0;waiting_=false;finished_=false;text_.clear();}
bool StoryEventRunner::advance(StoryState& s){
 if(finished_) return false;
 if(waiting_){waiting_=false; ++index_;}
 while(index_<commands_.size()){
  const auto& c=commands_[index_];
  switch(c.op){
   case StoryOp::Say: text_=c.text; waiting_=true; return true;
   case StoryOp::SetFlag: s.flags[c.key]=c.value!=0; ++index_; break;
   case StoryOp::GiveGil: s.gil+=c.value; ++index_; break;
   case StoryOp::GiveItem: s.items[c.value]++; ++index_; break;
   case StoryOp::RequireFlag:
    if(!s.flags[c.key]){ finished_=true; return true; }
    ++index_; break;
   case StoryOp::End: finished_=true; return true;
  }
 }
 finished_=true; return true;
}
}
