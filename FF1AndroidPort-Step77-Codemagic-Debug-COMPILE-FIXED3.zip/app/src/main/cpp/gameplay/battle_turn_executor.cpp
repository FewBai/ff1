#include "battle_turn_executor.h"
#include "status_system.h"
#include "battle_actions.h"

namespace ff1 {

void BattleTurnExecutor::reset() {
    phase_ = BattlePhase::Input;
    presentation_.clear();
    enemies_ = {};
}

void BattleTurnExecutor::setEnemies(const std::array<EnemyActor,4>& enemies) {
    enemies_ = enemies;
}

bool BattleTurnExecutor::execute(const BattleTurns& turns, PartySystem& party) {
    if (!turns.ready() || phase_ != BattlePhase::Input) return false;
    phase_ = BattlePhase::PlayerActions;

    for (int actor=0; actor<4; ++actor) {
        auto& c = party.at(actor);
        if (!c.active || c.hp <= 0 || !StatusSystem::canAct(c.status)) continue;
        const auto& cmd = turns.command(actor);

        if (cmd.command == BattleCommand::Attack) {
            int target = cmd.target;
            if (target < 0 || target >= 4 || !enemies_[target].alive) continue;
            auto result = BattleFormula::physical({c.attack(), enemies_[target].defense, false, true});
            enemies_[target].hp -= result.damage;
            presentation_.addLog({BattleLogType::Action, actor, target, result.damage,
                                  "Character attacks"});
            presentation_.addDamage(target, result.damage, result.critical);
            if (enemies_[target].hp <= 0) {
                enemies_[target].hp = 0;
                enemies_[target].alive = false;
                presentation_.addLog({BattleLogType::Defeat, actor, target, 0,
                                      "Enemy defeated"});
            }
        } else if (cmd.command == BattleCommand::Item) {
            auto result = BattleActions::useItem(
                party, actor, cmd.target, ItemEffect{cmd.itemId, 30, false});
            if (result.executed)
                presentation_.addLog({BattleLogType::Action, actor, result.target,
                                      result.value, "Item used"});
        } else if (cmd.command == BattleCommand::Magic) {
            auto result = BattleActions::castMagic(
                party, actor, cmd.target, MagicEffect{cmd.itemId, false},
                enemies_, presentation_);
            if (result.executed)
                presentation_.addLog({BattleLogType::Action, actor, result.target,
                                      result.value, "Magic cast"});
        }
    }

    bool anyEnemy = false;
    for (const auto& e : enemies_) if (e.alive) anyEnemy = true;
    if (!anyEnemy) {
        phase_ = BattlePhase::Victory;
        presentation_.addLog({BattleLogType::Victory,0,0,0,"Victory"});
        return true;
    }

    phase_ = BattlePhase::EnemyActions;
    enemyPhase(party);

    if (party.livingCount() == 0) {
        phase_ = BattlePhase::Defeat;
        presentation_.addLog({BattleLogType::Defeat,0,0,0,"Party defeated"});
    } else {
        phase_ = BattlePhase::Input;
    }
    return true;
}

void BattleTurnExecutor::enemyPhase(PartySystem& party) {
    for (int ei=0; ei<4; ++ei) {
        if (!enemies_[ei].alive) continue;
        int target=-1;
        for (int i=0;i<4;++i) {
            if (party.at(i).active && party.at(i).hp > 0) { target=i; break; }
        }
        if (target < 0) return;
        auto& c=party.at(target);
        AttackInput input{enemies_[ei].attack,c.defense(),false,true};
        auto result=BattleFormula::physical(input);
        c.hp -= result.damage;
        if (c.hp<0) c.hp=0;
        presentation_.addLog(BattleLogEntry{BattleLogType::Action,ei,target,result.damage,"Enemy attacks"});
        presentation_.addDamage(target,result.damage,false);
        if (c.hp==0) {
            StatusSystem::apply(c.status,Status::Dead);
            presentation_.addLog({BattleLogType::Defeat,ei,target,0,"Character defeated"});
        }
    }
}

} // namespace ff1
