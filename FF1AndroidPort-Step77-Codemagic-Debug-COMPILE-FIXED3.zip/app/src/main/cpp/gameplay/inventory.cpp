#include "inventory.h"
#include <algorithm>
namespace ff1 {
bool Inventory::add(uint8_t id,uint8_t amount){
    if(!id||!amount)return false;
    for(auto&s:slots_) {
        if(s.id==id && s.count<=99-amount){s.count+=amount;return true;}
    }
    for(auto&s:slots_) {
        if(!s.id){s.id=id;s.count=amount;return true;}
    }
    return false;
}
bool Inventory::remove(uint8_t id,uint8_t amount){
    for(auto&s:slots_) {
        if(s.id==id&&s.count>=amount){s.count-=amount;if(!s.count)s.id=0;return true;}
    }
    return false;
}
int Inventory::count(uint8_t id) const { int t=0; for(const auto&s:slots_) if(s.id==id)t+=s.count; return t; }
bool Inventory::usePotion(int targetIndex,int hp[4],const int maxHp[4]){
    constexpr uint8_t kPotion=0x20;
    if(targetIndex<0||targetIndex>=4||count(kPotion)<=0)return false;
    if(hp[targetIndex]>=maxHp[targetIndex])return false;
    if(!remove(kPotion,1))return false;
    hp[targetIndex]=std::min(maxHp[targetIndex],hp[targetIndex]+30);
    return true;
}
std::array<uint8_t,Inventory::kSlots> Inventory::snapshotCounts() const {
    std::array<uint8_t,kSlots> out{};
    for(int i=0;i<kSlots;++i) out[i]=slots_[i].count;
    return out;
}
void Inventory::restoreCounts(const std::array<uint8_t,kSlots>& counts){
    for(int i=0;i<kSlots;++i){
        slots_[i].id=counts[i]?static_cast<uint8_t>(i+1):0;
        slots_[i].count=counts[i];
    }
}
} // namespace ff1
