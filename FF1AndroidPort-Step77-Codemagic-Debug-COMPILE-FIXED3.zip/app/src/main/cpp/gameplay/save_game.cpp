#include "save_game.h"

namespace ff1 {

std::vector<uint8_t> SaveGame::encode(const SaveGameState& s) {
    std::vector<uint8_t> p;
    auto put32=[&](int v){
        uint32_t u=static_cast<uint32_t>(v);
        p.push_back(u&255); p.push_back((u>>8)&255);
        p.push_back((u>>16)&255); p.push_back((u>>24)&255);
    };
    put32(s.mapId); put32(s.x); put32(s.y); put32(s.gil);
    p.push_back(static_cast<uint8_t>(s.inventory.size()));
    p.insert(p.end(), s.inventory.begin(), s.inventory.end());
    return SaveSchema::wrap(p);
}

bool SaveGame::decode(const std::vector<uint8_t>& bytes, SaveGameState& s) {
    std::vector<uint8_t> p;
    if (!SaveSchema::unwrap(bytes,p) || p.size()<17) return false;
    auto get32=[&](size_t o)->int {
        uint32_t u=static_cast<uint32_t>(p[o]) |
            (static_cast<uint32_t>(p[o+1])<<8) |
            (static_cast<uint32_t>(p[o+2])<<16) |
            (static_cast<uint32_t>(p[o+3])<<24);
        return static_cast<int>(u);
    };
    s.mapId=get32(0); s.x=get32(4); s.y=get32(8); s.gil=get32(12);
    const size_t n=p[16];
    if (17+n!=p.size()) return false;
    s.inventory.assign(p.begin()+17,p.end());
    return true;
}

} // namespace ff1
