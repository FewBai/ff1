#pragma once
#include "party_system.h"
#include <array>
namespace ff1 {
struct BattleReward { int xp = 0; int gil = 0; };
struct RewardResult {
    int totalXp = 0;
    int totalGil = 0;
    int levelUps = 0;
    std::array<int,4> characterXp{};
    std::array<int,4> characterLevelUps{};
};
class RewardSystem {
public:
    static RewardResult apply(const BattleReward& reward, PartySystem& party, int& gil);
};
}
