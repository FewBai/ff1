#pragma once
#include "../ff1_types.h"

namespace ff1 {

class EquipmentSystem {
public:
    static int attackBonus(uint8_t weapon);
    static int defenseBonus(uint8_t armor, uint8_t shield, uint8_t helmet, uint8_t glove);
    static bool equip(Equipment& equipment, int slot, uint8_t itemId);
};

} // namespace ff1
