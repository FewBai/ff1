#include "battle_presentation.h"

namespace ff1 {

void BattlePresentation::clear() {
    log_.clear();
    damage_.clear();
}

void BattlePresentation::addLog(const BattleLogEntry& entry) {
    log_.push_back(entry);
}

void BattlePresentation::addDamage(int target, int amount, bool critical) {
    damage_.push_back({target, amount, critical});
}

} // namespace ff1
