#include "status_system.h"
namespace ff1 {
void StatusSystem::apply(Status& status, Status effect){ if(status!=Status::Dead) status=effect; }
bool StatusSystem::canAct(Status status){ return status!=Status::Dead && status!=Status::Paralyzed && status!=Status::Stone; }
bool StatusSystem::alive(Status status){ return status!=Status::Dead; }
} // namespace ff1
