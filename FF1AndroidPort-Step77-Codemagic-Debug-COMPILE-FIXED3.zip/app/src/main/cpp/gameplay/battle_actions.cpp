#include "battle_actions.h"
#include "battle_turn_executor.h"
#include "status_system.h"
#include <algorithm>

namespace ff1 {

ActionResult BattleActions::useItem(PartySystem& party, int actor, int target,
                                    const ItemEffect& effect) {
    if (actor < 0 || actor >= 4 || target < 0 || target >= 4) return {};
    auto& user = party.at(actor);
    auto& dst = party.at(target);
    if (!user.active || user.hp <= 0 || !dst.active) return {};

    if (effect.revive) {
        if (dst.hp > 0) return {};
        dst.hp = std::max(1, effect.healHp);
        dst.status = Status::Normal;
        return {true, dst.hp, target};
    }

    if (dst.hp >= dst.maxHp || effect.healHp <= 0) return {};
    int before = dst.hp;
    dst.hp = std::min(dst.maxHp, dst.hp + effect.healHp);
    return {true, dst.hp - before, target};
}

ActionResult BattleActions::castMagic(PartySystem& party, int actor, int target,
                                      const MagicEffect& effect,
                                      std::array<EnemyActor,4>& enemies,
                                      BattlePresentation& presentation) {
    if (actor < 0 || actor >= 4 || target < 0 || target >= 4) return {};
    auto& caster = party.at(actor);
    const SpellData* spell = SpellSystem::find(static_cast<uint8_t>(effect.spellId));
    if (!caster.active || caster.hp <= 0 || !spell || caster.mp < spell->mpCost)
        return {};

    caster.mp -= spell->mpCost;

    if (spell->healing || effect.healing) {
        auto& dst = party.at(target);
        if (!dst.active || dst.hp <= 0) return {};
        int before = dst.hp;
        dst.hp = std::min(dst.maxHp, dst.hp + static_cast<int>(spell->power));
        return {true, dst.hp - before, target};
    }

    if (!enemies[target].alive) return {};
    AttackInput input{
        static_cast<int>(spell->power) + caster.level,
        enemies[target].defense, false, true
    };
    auto result = BattleFormula::physical(input);
    enemies[target].hp = std::max(0, enemies[target].hp - result.damage);
    if (enemies[target].hp == 0) enemies[target].alive = false;

    presentation.addLog({BattleLogType::Action, actor, target,
                         result.damage, "Magic cast"});
    presentation.addDamage(target, result.damage, result.critical);
    if (!enemies[target].alive)
        presentation.addLog({BattleLogType::Defeat, actor, target, 0,
                             "Enemy defeated"});
    return {true, result.damage, target};
}

} // namespace ff1
