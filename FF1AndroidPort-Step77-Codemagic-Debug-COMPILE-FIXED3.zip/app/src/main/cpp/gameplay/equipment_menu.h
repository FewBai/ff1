#pragma once
#include "inventory.h"
#include "equipment_system.h"

namespace ff1 {

class EquipmentMenu {
public:
    static bool equipFromInventory(Equipment& equipment, Inventory& inventory,
                                    int slot, uint8_t itemId);
};

} // namespace ff1
