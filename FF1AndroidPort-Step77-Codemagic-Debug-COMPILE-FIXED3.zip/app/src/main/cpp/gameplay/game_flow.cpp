#include "game_flow.h"

namespace ff1 {

void GameFlow::reset() {
    state_ = FlowState::Boot;
}

} // namespace ff1
