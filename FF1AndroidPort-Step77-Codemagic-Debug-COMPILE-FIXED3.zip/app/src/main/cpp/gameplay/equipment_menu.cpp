#include "equipment_menu.h"

namespace ff1 {

bool EquipmentMenu::equipFromInventory(Equipment& equipment, Inventory& inventory,
                                       int slot, uint8_t itemId) {
    if (inventory.count(itemId) <= 0) return false;
    if (!EquipmentSystem::equip(equipment, slot, itemId)) return false;
    return true;
}

} // namespace ff1
