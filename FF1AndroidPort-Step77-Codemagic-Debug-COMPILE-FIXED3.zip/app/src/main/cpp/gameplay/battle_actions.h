#pragma once
#include "battle_formula.h"
#include "battle_presentation.h"
#include "party_system.h"
#include "spell_system.h"
#include <array>

namespace ff1 {

struct EnemyActor;

struct ItemEffect {
    int itemId = 0;
    int healHp = 0;
    bool revive = false;
};

struct MagicEffect {
    int spellId = 0;
    bool healing = false;
};

struct ActionResult {
    bool executed = false;
    int value = 0;
    int target = 0;
};

class BattleActions {
public:
    static ActionResult useItem(PartySystem& party, int actor, int target,
                                const ItemEffect& effect);
    static ActionResult castMagic(PartySystem& party, int actor, int target,
                                  const MagicEffect& effect,
                                  std::array<EnemyActor,4>& enemies,
                                  BattlePresentation& presentation);
};

} // namespace ff1
