#pragma once
#include <string>
#include <vector>

namespace ff1 {

enum class BattleLogType { Action, Damage, Miss, Defeat, Victory, Escape };

struct BattleLogEntry {
    BattleLogType type;
    int actor = 0;
    int target = 0;
    int value = 0;
    std::string text;
};

struct DamagePopup {
    int target = 0;
    int amount = 0;
    bool critical = false;
};

class BattlePresentation {
public:
    void clear();
    void addLog(const BattleLogEntry& entry);
    void addDamage(int target, int amount, bool critical);
    const std::vector<BattleLogEntry>& log() const { return log_; }
    const std::vector<DamagePopup>& damage() const { return damage_; }

private:
    std::vector<BattleLogEntry> log_;
    std::vector<DamagePopup> damage_;
};

} // namespace ff1
