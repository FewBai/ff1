#pragma once
#include <string>
namespace ff1 {
enum class InteractionKind { None, Dialogue, Chest, Warp };
struct InteractionState { InteractionKind kind=InteractionKind::None; int id=0; bool open=false; std::string text; };
}
