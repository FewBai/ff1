#pragma once
#include "inventory.h"

namespace ff1 {

class TownServices {
public:
    static void inn(int& gil, int price, int partyHp[4], const int maxHp[4]);
    static void clinic(int& gil, int price, int partyHp[4], const int maxHp[4]);
};

} // namespace ff1
