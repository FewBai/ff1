#pragma once
#include "battle_turns.h"

namespace ff1 {

enum class BattleUiMode {
    Commands,
    Targeting,
    Executing,
    Result
};

struct BattleUiState {
    BattleUiMode mode = BattleUiMode::Commands;
    int activeCharacter = 0;
    int selectedTarget = 0;
    bool targetAll = false;
};

class BattleUiController {
public:
    void reset();
    void nextCharacter();
    void selectTarget(int target);
    void beginTargeting();
    void beginExecution();
    void showResult();

    const BattleUiState& state() const { return state_; }

private:
    BattleUiState state_;
};

} // namespace ff1
