#pragma once
#include "world_data.h"
#include <string>

namespace ff1 {

class DataLoader {
public:
    static bool loadWorldText(const std::string& text, WorldData& world);
};

} // namespace ff1
