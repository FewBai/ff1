#include "battle_log.h"
#include <utility>

namespace ff1 {
void BattleLog::clear() { entries_.clear(); }
void BattleLog::add(BattleLogEntry entry) { entries_.push_back(std::move(entry)); }
const BattleLogEntry* BattleLog::latest() const {
    return entries_.empty() ? nullptr : &entries_.back();
}
} // namespace ff1
