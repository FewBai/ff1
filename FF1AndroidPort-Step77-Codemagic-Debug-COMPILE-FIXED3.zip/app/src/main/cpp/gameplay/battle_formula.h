#pragma once
#include <cstdint>

namespace ff1 {

struct AttackInput {
    int attack = 0;
    int targetDefense = 0;
    bool critical = false;
    bool hit = true;
};

struct AttackResult {
    int damage = 0;
    bool hit = false;
    bool critical = false;
};

class BattleFormula {
public:
    static AttackResult physical(const AttackInput& input);
    static int healing(int power, int casterLevel);
};

} // namespace ff1
