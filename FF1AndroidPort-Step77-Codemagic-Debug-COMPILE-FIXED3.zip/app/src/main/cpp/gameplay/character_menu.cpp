#include "character_menu.h"

namespace ff1 {
const char* CharacterMenu::jobName(CharacterClass j) {
    switch (j) {
        case CharacterClass::Fighter: return "Fighter";
        case CharacterClass::Thief: return "Thief";
        case CharacterClass::BlackBelt: return "BlackBelt";
        case CharacterClass::WhiteMage: return "WhiteMage";
    }
    return "Unknown";
}
CharacterMenuSnapshot CharacterMenu::snapshot(const PartySystem& p, int i) {
    CharacterMenuSnapshot s; if(i<0||i>=4) return s;
    const auto& c=p.at(i); s.index=i; s.job=jobName(c.job); s.level=c.level; s.xp=c.xp; s.nextXp=c.nextXp;
    s.hp=c.hp; s.maxHp=c.maxHp; s.mp=c.mp; s.maxMp=c.maxMp; s.attack=c.attack(); s.defense=c.defense();
    s.weapon=c.equipment.weapon; s.armor=c.equipment.armor; return s;
}
bool CharacterMenu::canEquip(const Character& c, uint8_t weapon, uint8_t armor) {
    // Data-driven restriction hook: starter IDs remain compatible with every job.
    // Future item tables can replace this without touching Android UI.
    if (weapon==0 && armor==0) return true;
    if (c.job==CharacterClass::BlackBelt && weapon!=0) return false;
    return true;
}
}
