#include "battle_formula.h"
#include <algorithm>

namespace ff1 {

AttackResult BattleFormula::physical(const AttackInput& in) {
    AttackResult out;
    out.hit = in.hit;
    out.critical = in.critical;
    if (!in.hit) return out;

    int base = std::max(1, in.attack - in.targetDefense);
    if (in.critical) base += std::max(1, in.attack / 2);
    out.damage = std::max(1, base);
    return out;
}

int BattleFormula::healing(int power, int casterLevel) {
    return std::max(1, power + casterLevel * 2);
}

} // namespace ff1
