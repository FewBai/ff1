#pragma once
#include "inventory.h"
#include <cstdint>
#include <vector>

namespace ff1 {

struct Chest {
    int id = 0;
    int mapId = 0;
    int x = 0;
    int y = 0;
    uint8_t itemId = 0;
    uint8_t count = 1;
    int gil = 0;
    bool opened = false;
};

class ChestSystem {
public:
    void add(const Chest& chest);
    bool open(int mapId, int x, int y, int& gil, Inventory& inventory);
    const std::vector<Chest>& all() const { return chests_; }
    std::vector<Chest>& mutableAll() { return chests_; }

private:
    std::vector<Chest> chests_;
};

} // namespace ff1
