#pragma once
#include <string>
#include <vector>

namespace ff1 {

struct Dialogue {
    int id = 0;
    std::vector<std::string> pages;
};

class DialogueSystem {
public:
    void open(const Dialogue& dialogue);
    bool next();
    bool active() const { return active_; }
    const std::string& text() const;

private:
    Dialogue dialogue_;
    int page_ = 0;
    bool active_ = false;
    static const std::string kEmpty;
};

} // namespace ff1
