#include "map_transition.h"

namespace ff1 {

void MapTransitionSystem::add(const Warp& warp) {
    warps_.push_back(warp);
}

bool MapTransitionSystem::tryWarp(int mapId, int x, int y,
                                  int& outMap, int& outX, int& outY) const {
    for (const auto& w : warps_) {
        if (w.fromMap == mapId && w.x == x && w.y == y) {
            outMap = w.toMap;
            outX = w.toX;
            outY = w.toY;
            return true;
        }
    }
    return false;
}

} // namespace ff1
