#pragma once
#include "party_system.h"

namespace ff1 {

enum class FlowState {
    Boot,
    PartyCreation,
    World,
    Town,
    Dungeon,
    Battle,
    Menu,
    Dialogue,
    GameOver
};

class GameFlow {
public:
    void reset();
    FlowState state() const { return state_; }
    void set(FlowState state) { state_ = state; }

private:
    FlowState state_ = FlowState::Boot;
};

} // namespace ff1
