#pragma once
#include <string>
#include <vector>
#include "chest_system.h"

namespace ff1 {

struct MapObject {
    int id = 0;
    int mapId = 0;
    int x = 0;
    int y = 0;
    std::string name;
    bool solid = false;
    int dialogueId = 0;
};

struct MapData {
    int id = 0;
    int width = 0;
    int height = 0;
    std::vector<uint8_t> collision;
    std::vector<MapObject> objects;
    std::vector<Chest> chests;
};

class WorldData {
public:
    void addMap(const MapData& map);
    const MapData* map(int id) const;
    const MapObject* objectAt(int mapId, int x, int y) const;

private:
    std::vector<MapData> maps_;
};

} // namespace ff1
