#pragma once
#include "ff1_types.h"
#include "inventory.h"
#include "chest_system.h"
#include "dialogue_system.h"
#include <string>

namespace ff1 {

struct RegionNpc { int id=0,x=0,y=0,dialogueId=0; std::string name; };

class ExplorationRuntime {
public:
    void reset();
    void restoreChests(const std::array<uint8_t,32>& bits);
    void snapshotChests(std::array<uint8_t,32>& bits) const;
    bool move(SaveData& save, int dx, int dy);
    bool interact(SaveData& save, Inventory& inventory, std::string& message);
    bool encounterTriggered() const { return encounterTriggered_; }
    void clearEncounter() { encounterTriggered_=false; }
    bool chestOpened() const { return chestOpened_; }
    int lastChestGil() const { return lastChestGil_; }
    uint8_t lastChestItem() const { return lastChestItem_; }
    const std::string& lastNpcMessage() const { return lastNpcMessage_; }
    int width() const { return 20; }
    int height() const { return 14; }

private:
    TileMap map_{};
    ChestSystem chests_{};
    std::vector<RegionNpc> npcs_{};
    int steps_=0;
    bool encounterTriggered_=false;
    bool chestOpened_=false;
    int lastChestGil_=0;
    uint8_t lastChestItem_=0;
    std::string lastNpcMessage_;
    void buildRegion();
};

} // namespace ff1
