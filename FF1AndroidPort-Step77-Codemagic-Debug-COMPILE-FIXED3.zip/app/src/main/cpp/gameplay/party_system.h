#pragma once
#include "../ff1_types.h"
#include <array>

namespace ff1 {

struct Character {
    CharacterClass job = CharacterClass::Fighter;
    int xp = 0;
    int nextXp = 40;
    int level = 1;
    Equipment equipment{};
    Status status = Status::Normal;
    int hp = 30;
    int maxHp = 30;
    int mp = 0;
    int maxMp = 0;
    int baseAttack = 5;
    int baseDefense = 2;
    bool active = true;

    int attack() const;
    int defense() const;
};

class PartySystem {
public:
    void reset();
    Character& at(int index);
    const Character& at(int index) const;
    int size() const { return 4; }
    int livingCount() const;
    bool addXp(int index, int amount);

    void fromSave(const std::array<PartyMember, 4>& party);
    void toSave(std::array<PartyMember, 4>& party) const;

private:
    std::array<Character, 4> party_{};
};

} // namespace ff1
