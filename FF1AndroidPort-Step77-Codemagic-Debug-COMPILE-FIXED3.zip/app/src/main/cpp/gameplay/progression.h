#pragma once
#include <array>
#include <cstdint>

namespace ff1 {

struct LevelStats {
    int level = 1;
    int xp = 0;
    int nextXp = 40;
};

class Progression {
public:
    static int xpForNextLevel(int level);
    static bool addXp(LevelStats& stats, int amount);
    static void healToMax(int& hp, int maxHp);
};

} // namespace ff1
