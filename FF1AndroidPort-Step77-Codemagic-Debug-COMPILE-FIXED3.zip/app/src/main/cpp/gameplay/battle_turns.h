#pragma once
#include <array>
#include "../ff1_types.h"
#include <cstdint>

namespace ff1 {



struct BattleCommandSlot {
    BattleCommand command = static_cast<BattleCommand>(255);
    int target = 0;
    int itemId = 0;
};

class BattleTurns {
public:
    void reset();
    bool setCommand(int actor, BattleCommand command, int target = 0, int itemId = 0);
    bool ready() const;
    const BattleCommandSlot& command(int actor) const;
    void clear();

private:
    std::array<BattleCommandSlot, 4> commands_{};
};

} // namespace ff1
