#include "exploration_runtime.h"
#include <algorithm>
#include <array>
namespace ff1 {
void ExplorationRuntime::buildRegion(){
    map_={}; map_.id=100; map_.width=20; map_.height=14;
    map_.collision.assign(map_.width*map_.height,0);
    for(int x=0;x<map_.width;++x){map_.collision[x]=1;map_.collision[(map_.height-1)*map_.width+x]=1;}
    for(int y=0;y<map_.height;++y){map_.collision[y*map_.width]=1;map_.collision[y*map_.width+map_.width-1]=1;}
    for(int x=5;x<15;++x) map_.collision[6*map_.width+x]=1;
    map_.collision[6*map_.width+10]=0;
    chests_=ChestSystem{}; chests_.add({1,100,4,4,0x20,2,100,false});
    npcs_={{1,8,4,1,"Guide"}};
}
void ExplorationRuntime::reset(){steps_=0;encounterTriggered_=false;chestOpened_=false;lastChestGil_=0;lastChestItem_=0;lastNpcMessage_.clear();buildRegion();}
bool ExplorationRuntime::move(SaveData& save,int dx,int dy){
    int nx=save.playerX+dx, ny=save.playerY+dy;
    if(nx<0||ny<0||nx>=map_.width||ny>=map_.height||map_.collision[ny*map_.width+nx]) return false;
    save.mapId=100; save.playerX=nx; save.playerY=ny; ++steps_;
    encounterTriggered_=(steps_%4==0); return true;
}
bool ExplorationRuntime::interact(SaveData& save,Inventory& inventory,std::string& message){
    message.clear(); chestOpened_=false; lastChestGil_=0; lastChestItem_=0; lastNpcMessage_.clear();
    int gil=save.gil;
    if(chests_.open(100,save.playerX,save.playerY,gil,inventory)){
        save.gil=gil; chestOpened_=true; lastChestGil_=100; lastChestItem_=0x20; message="CHEST: POTION x2 + 100 GIL"; return true;
    }
    for(const auto& n:npcs_) if(n.x==save.playerX&&n.y==save.playerY){lastNpcMessage_="Welcome, traveler. The road ahead is dangerous.";message=lastNpcMessage_;return true;}
    return false;
}
}


void ff1::ExplorationRuntime::restoreChests(const std::array<uint8_t,32>& bits){
    buildRegion();
    for(auto &c: chests_.mutableAll()) if(c.id>=0 && c.id<256) c.opened = (bits[c.id/8] & (1u<<(c.id%8)))!=0;
}
void ff1::ExplorationRuntime::snapshotChests(std::array<uint8_t,32>& bits) const{
    bits.fill(0);
    for(const auto &c: chests_.all()) if(c.opened && c.id>=0 && c.id<256) bits[c.id/8] |= static_cast<uint8_t>(1u<<(c.id%8));
}
