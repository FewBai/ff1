#pragma once
#include "../ff1_types.h"
#include <string>
namespace ff1 {
class SaveSystemV2 {
public:
    bool save(const SaveData& data,const std::string& path) const;
    bool load(SaveData& data,const std::string& path) const;
};
} // namespace ff1
