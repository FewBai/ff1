#pragma once
#include "save_schema.h"
#include <cstdint>
#include <string>
#include <vector>

namespace ff1 {

struct SaveGameState {
    int mapId = 0;
    int x = 0;
    int y = 0;
    int gil = 0;
    std::vector<uint8_t> inventory;
};

class SaveGame {
public:
    static std::vector<uint8_t> encode(const SaveGameState& state);
    static bool decode(const std::vector<uint8_t>& bytes, SaveGameState& state);
};

} // namespace ff1
