#include "reward_system.h"
namespace ff1 {
RewardResult RewardSystem::apply(const BattleReward& reward, PartySystem& party, int& gil) {
    RewardResult r;
    if (party.livingCount() == 0) return r;
    gil += reward.gil; r.totalGil = reward.gil;
    for (int i=0;i<party.size();++i) {
        auto& c=party.at(i);
        if (!c.active || c.hp<=0 || c.status==Status::Dead) continue;
        r.characterXp[i] = reward.xp;
        const int oldLevel=c.level;
        if (party.addXp(i,reward.xp)) {
            r.characterLevelUps[i]=c.level-oldLevel;
            r.levelUps += r.characterLevelUps[i];
        }
        r.totalXp += reward.xp;
    }
    return r;
}
}
