#include "progression.h"
#include <algorithm>

namespace ff1 {

int Progression::xpForNextLevel(int level) {
    return std::max(40, level * level * 40);
}

bool Progression::addXp(LevelStats& stats, int amount) {
    bool leveled = false;
    stats.xp += std::max(0, amount);
    while (stats.xp >= stats.nextXp) {
        stats.xp -= stats.nextXp;
        ++stats.level;
        stats.nextXp = xpForNextLevel(stats.level);
        leveled = true;
    }
    return leveled;
}

void Progression::healToMax(int& hp, int maxHp) {
    hp = std::max(0, maxHp);
}

} // namespace ff1
