#pragma once
#include "inventory.h"
#include "data_tables.h"

namespace ff1 {

class ShopSystem {
public:
    bool buyWeapon(uint8_t id, int& gil, Inventory& inventory) const;
    bool buyArmor(uint8_t id, int& gil, Inventory& inventory) const;
    bool buyPotion(int& gil, Inventory& inventory) const;
};

} // namespace ff1
