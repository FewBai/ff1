#include "town_services.h"
#include <algorithm>

namespace ff1 {

void TownServices::inn(int& gil, int price, int partyHp[4], const int maxHp[4]) {
    if (gil < price) return;
    gil -= price;
    for (int i = 0; i < 4; ++i) partyHp[i] = maxHp[i];
}

void TownServices::clinic(int& gil, int price, int partyHp[4], const int maxHp[4]) {
    if (gil < price) return;
    gil -= price;
    for (int i = 0; i < 4; ++i)
        partyHp[i] = std::min(maxHp[i], std::max(1, partyHp[i]));
}

} // namespace ff1
