#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace ff1 {

struct SaveHeader {
    uint32_t magic = 0x46463153; // "FF1S"
    uint16_t version = 2;
    uint16_t payloadSize = 0;
    uint32_t checksum = 0;
};

class SaveSchema {
public:
    static uint32_t checksum(const std::vector<uint8_t>& bytes);
    static std::vector<uint8_t> wrap(const std::vector<uint8_t>& payload);
    static bool unwrap(const std::vector<uint8_t>& file, std::vector<uint8_t>& payload);
};

} // namespace ff1
