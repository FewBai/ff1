#include "party_system.h"
#include "equipment_system.h"
#include <algorithm>

namespace ff1 {

int Character::attack() const {
    return baseAttack + level + EquipmentSystem::attackBonus(equipment.weapon);
}

int Character::defense() const {
    return baseDefense + level / 2 + EquipmentSystem::defenseBonus(
        equipment.armor, equipment.shield, equipment.helmet, equipment.glove);
}

void PartySystem::reset() {
    party_[0] = {CharacterClass::Fighter, 0, 40, 1, {}, Status::Normal, 30, 30, 0, 0, 7, 3, true};
    party_[1] = {CharacterClass::Thief, 0, 40, 1, {}, Status::Normal, 24, 24, 0, 0, 5, 2, true};
    party_[2] = {CharacterClass::BlackBelt, 0, 40, 1, {}, Status::Normal, 28, 28, 0, 0, 6, 1, true};
    party_[3] = {CharacterClass::WhiteMage, 0, 40, 1, {}, Status::Normal, 20, 20, 4, 4, 3, 1, true};
}

Character& PartySystem::at(int index) { return party_.at(static_cast<size_t>(index)); }
const Character& PartySystem::at(int index) const { return party_.at(static_cast<size_t>(index)); }

int PartySystem::livingCount() const {
    int count = 0;
    for (const auto& c : party_)
        if (c.active && c.hp > 0 && c.status != Status::Dead) ++count;
    return count;
}

bool PartySystem::addXp(int index, int amount) {
    if (index < 0 || index >= 4 || amount <= 0) return false;
    auto& c = party_[index];
    c.xp += amount;
    bool leveled = false;
    while (c.xp >= c.nextXp) {
        c.xp -= c.nextXp;
        ++c.level;
        c.nextXp = std::max(40, c.level * c.level * 40);
        c.maxHp += 4;
        c.hp = c.maxHp;
        c.baseAttack += 1;
        c.baseDefense += 1;
        if (c.maxMp) { ++c.maxMp; c.mp = c.maxMp; }
        leveled = true;
    }
    return leveled;
}

void PartySystem::fromSave(const std::array<PartyMember, 4>& party) {
    for (int i = 0; i < 4; ++i) {
        const auto& p = party[i];
        auto& c = party_[i];
        c.job = p.job;
        c.xp = p.stats.xp;
        c.nextXp = std::max(40, p.stats.nextXp);
        c.level = std::max(1, p.stats.level);
        c.equipment = p.equipment;
        c.status = p.status;
        c.hp = p.stats.hp;
        c.maxHp = p.stats.maxHp;
        c.mp = p.stats.mp;
        c.maxMp = p.stats.maxMp;
        c.baseAttack = p.stats.attack;
        c.baseDefense = p.stats.defense;
        c.active = p.alive;
    }
}

void PartySystem::toSave(std::array<PartyMember, 4>& party) const {
    static const char* names[4] = {"WARRIOR", "THIEF", "BLACKBELT", "WHITEMAGE"};
    for (int i = 0; i < 4; ++i) {
        const auto& c = party_[i];
        auto& p = party[i];
        p.name = names[i];
        p.job = c.job;
        p.stats = {c.level, c.hp, c.maxHp, c.mp, c.maxMp, c.baseAttack, c.baseDefense, c.xp, c.nextXp};
        p.equipment = c.equipment;
        p.status = c.status;
        p.alive = c.active && c.hp > 0 && c.status != Status::Dead;
    }
}

} // namespace ff1
