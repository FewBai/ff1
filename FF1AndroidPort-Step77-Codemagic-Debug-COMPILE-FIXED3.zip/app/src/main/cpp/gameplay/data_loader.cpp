#include "data_loader.h"
#include <sstream>

namespace ff1 {

bool DataLoader::loadWorldText(const std::string& text, WorldData& world) {
    // Minimal clean-room text adapter:
    // MAP id width height
    // OBJ id map x y solid dialogueId name
    // CHEST id map x y item count gil
    std::istringstream in(text);
    std::string tag;
    bool any = false;
    MapData current;
    bool haveMap = false;

    while (in >> tag) {
        if (tag == "MAP") {
            if (haveMap) world.addMap(current);
            current = {};
            in >> current.id >> current.width >> current.height;
            current.collision.assign(
                static_cast<size_t>(current.width * current.height), 0);
            haveMap = true; any = true;
        } else if (tag == "OBJ" && haveMap) {
            MapObject o;
            int solid = 0;
            in >> o.id >> o.mapId >> o.x >> o.y >> solid >> o.dialogueId >> o.name;
            o.solid = solid != 0;
            current.objects.push_back(o);
        } else if (tag == "CHEST" && haveMap) {
            Chest c;
            in >> c.id >> c.mapId >> c.x >> c.y
               >> c.itemId >> c.count >> c.gil;
            current.chests.push_back(c);
        } else {
            return false;
        }
    }
    if (haveMap) world.addMap(current);
    return any;
}

} // namespace ff1
