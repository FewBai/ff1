#pragma once
#include <cstdint>
namespace ff1 {
enum class SceneKind:uint8_t { Map, Battle };
enum class TransitionPhase:uint8_t { None, FadeOut, Loading, FadeIn };
struct SceneState { SceneKind kind=SceneKind::Map; int mapId=0; int x=0; int y=0; };
class SceneTransition {
public:
 void start(SceneState from, SceneState to);
 void tick(int frames=1);
 bool active() const { return phase_!=TransitionPhase::None; }
 bool ready() const { return phase_==TransitionPhase::FadeIn; }
 TransitionPhase phase() const{return phase_;}
 int alpha() const{return alpha_;}
 const SceneState& target() const{return target_;}
 void finish();
private: SceneState target_{}; TransitionPhase phase_=TransitionPhase::None; int alpha_=0; int timer_=0;
};
}
