#pragma once
#include <string>
#include <unordered_map>
#include <vector>

namespace ff1 {

enum class StoryOp { Say, SetFlag, GiveGil, GiveItem, RequireFlag, End };
struct StoryCommand { StoryOp op; std::string text; std::string key; int value = 0; };
struct StoryState { std::unordered_map<std::string,bool> flags; int gil = 0; std::unordered_map<int,int> items; };

class StoryEventRunner {
public:
    void start(const std::vector<StoryCommand>& commands);
    bool advance(StoryState& state);
    bool waitingForText() const { return waiting_; }
    bool finished() const { return finished_; }
    const std::string& text() const { return text_; }
private:
    std::vector<StoryCommand> commands_;
    size_t index_ = 0;
    bool waiting_ = false, finished_ = true;
    std::string text_;
};
}
