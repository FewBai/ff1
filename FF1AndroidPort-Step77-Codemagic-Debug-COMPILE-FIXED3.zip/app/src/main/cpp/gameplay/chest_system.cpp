#include "chest_system.h"

namespace ff1 {

void ChestSystem::add(const Chest& chest) {
    chests_.push_back(chest);
}

bool ChestSystem::open(int mapId, int x, int y, int& gil, Inventory& inventory) {
    for (auto& c : chests_) {
        if (!c.opened && c.mapId == mapId && c.x == x && c.y == y) {
            if (c.itemId && !inventory.add(c.itemId, c.count)) return false;
            gil += c.gil;
            c.opened = true;
            return true;
        }
    }
    return false;
}

} // namespace ff1
