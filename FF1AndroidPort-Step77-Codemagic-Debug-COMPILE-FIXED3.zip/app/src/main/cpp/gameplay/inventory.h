#pragma once
#include <array>
#include <cstdint>

namespace ff1 {
struct ItemStack { uint8_t id=0; uint8_t count=0; };
class Inventory {
public:
    static constexpr int kSlots=32;
    bool add(uint8_t id,uint8_t amount=1);
    bool remove(uint8_t id,uint8_t amount=1);
    int count(uint8_t id) const;
    bool usePotion(int targetIndex, int hp[4], const int maxHp[4]);
    std::array<uint8_t,kSlots> snapshotCounts() const;
    void restoreCounts(const std::array<uint8_t,kSlots>& counts);
private:
    std::array<ItemStack,kSlots> slots_{};
};
} // namespace ff1
