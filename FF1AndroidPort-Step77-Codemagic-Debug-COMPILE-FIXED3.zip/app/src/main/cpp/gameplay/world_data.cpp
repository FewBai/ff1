#include "world_data.h"

namespace ff1 {

void WorldData::addMap(const MapData& map) {
    maps_.push_back(map);
}

const MapData* WorldData::map(int id) const {
    for (const auto& m : maps_) if (m.id == id) return &m;
    return nullptr;
}

const MapObject* WorldData::objectAt(int mapId, int x, int y) const {
    const auto* m = map(mapId);
    if (!m) return nullptr;
    for (const auto& o : m->objects)
        if (o.x == x && o.y == y) return &o;
    return nullptr;
}

} // namespace ff1
