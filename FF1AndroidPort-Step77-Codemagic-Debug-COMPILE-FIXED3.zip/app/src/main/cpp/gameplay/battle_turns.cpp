#include "battle_turns.h"
#include <cstddef>

namespace ff1 {

void BattleTurns::reset() {
    for (auto& c : commands_) c = {};
}

bool BattleTurns::setCommand(int actor, BattleCommand command, int target, int itemId) {
    if (actor < 0 || actor >= 4) return false;
    commands_[static_cast<size_t>(actor)] = {command, target, itemId};
    return true;
}

bool BattleTurns::ready() const {
    for (const auto& c : commands_)
        if (c.command == static_cast<BattleCommand>(255)) return false;
    return true;
}

const BattleCommandSlot& BattleTurns::command(int actor) const {
    return commands_.at(static_cast<size_t>(actor));
}

void BattleTurns::clear() {
    reset();
}

} // namespace ff1
