#include "spell_system.h"
#include <algorithm>

namespace ff1 {

static constexpr std::array<SpellData, 4> kSpells{{
    {1, 2, 20, true},
    {2, 3, 30, true},
    {3, 4, 24, false},
    {4, 6, 40, false}
}};

const SpellData* SpellSystem::find(uint8_t id) {
    for (const auto& s : kSpells)
        if (s.id == id) return &s;
    return nullptr;
}

bool SpellSystem::cast(uint8_t id, int& mp, int& targetHp, int targetMaxHp) {
    const auto* spell = find(id);
    if (!spell || mp < spell->mpCost) return false;
    mp -= spell->mpCost;
    if (spell->healing)
        targetHp = std::min(targetMaxHp, targetHp + static_cast<int>(spell->power));
    else
        targetHp = std::max(0, targetHp - static_cast<int>(spell->power));
    return true;
}

} // namespace ff1
