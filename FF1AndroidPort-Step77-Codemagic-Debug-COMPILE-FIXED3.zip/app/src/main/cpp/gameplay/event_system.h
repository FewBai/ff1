#pragma once
#include <cstdint>
#include <vector>

namespace ff1 {

enum class EventOp : uint8_t {
    End = 0,
    Message = 1,
    GiveGil = 2,
    GiveItem = 3,
    HealParty = 4,
    StartBattle = 5,
    Warp = 6
};

struct Event {
    std::vector<uint8_t> code;
};

class EventSystem {
public:
    void setEvent(const Event& event);
    bool running() const { return pc_ < code_.size(); }
    EventOp step(int& gil, int& x, int& y, int& messageId,
                 uint8_t& itemId, int& itemCount, int& battleSeed);
    void reset();

private:
    std::vector<uint8_t> code_;
    size_t pc_ = 0;
};

} // namespace ff1
