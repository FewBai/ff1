#pragma once
#include <string>
#include <vector>

namespace ff1 {

enum class BattleLogType { Action, Damage, Heal, Status, Defeat, Victory, Escape };

struct BattleLogEntry {
    BattleLogType type;
    int actor = -1;
    int target = -1;
    int value = 0;
    std::string text;
};

class BattleLog {
public:
    void clear();
    void add(BattleLogEntry entry);
    const std::vector<BattleLogEntry>& entries() const { return entries_; }
    const BattleLogEntry* latest() const;

private:
    std::vector<BattleLogEntry> entries_;
};

} // namespace ff1
