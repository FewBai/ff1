#pragma once
#include "battle_turns.h"
#include "battle_formula.h"
#include "battle_presentation.h"
#include "party_system.h"
#include <array>

namespace ff1 {

struct EnemyActor {
    int hp = 20;
    int defense = 2;
    int attack = 4;
    bool alive = true;
};

enum class BattlePhase { Input, PlayerActions, EnemyActions, Victory, Defeat, Escaped };

class BattleTurnExecutor {
public:
    void reset();
    void setEnemies(const std::array<EnemyActor,4>& enemies);
    BattlePhase phase() const { return phase_; }
    bool execute(const BattleTurns& turns, PartySystem& party);
    const std::array<EnemyActor,4>& enemies() const { return enemies_; }
    const BattlePresentation& presentation() const { return presentation_; }

private:
    BattlePhase phase_ = BattlePhase::Input;
    std::array<EnemyActor,4> enemies_{};
    BattlePresentation presentation_;

    void enemyPhase(PartySystem& party);
};

} // namespace ff1
