#pragma once
#include "../ff1_types.h"

namespace ff1 {

class StatusSystem {
public:
    static void apply(Status& status, Status effect);
    static bool canAct(Status status);
    static bool alive(Status status);
};

} // namespace ff1
