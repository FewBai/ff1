#pragma once
#include <cstdint>

namespace ff1 {

enum class GameEventType : uint8_t {
    MapEntered,
    MapExited,
    PlayerMoved,
    Interacted,
    BattleStarted,
    BattleWon,
    BattleLost,
    LevelUp,
    ItemReceived,
    DialogueOpened,
    ChestOpened,
    SaveCompleted
};

struct GameEvent {
    GameEventType type;
    int a = 0;
    int b = 0;
    int c = 0;
};

} // namespace ff1
