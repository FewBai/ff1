#include "save_schema.h"

namespace ff1 {

uint32_t SaveSchema::checksum(const std::vector<uint8_t>& bytes) {
    uint32_t h = 2166136261u;
    for (uint8_t b : bytes) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

std::vector<uint8_t> SaveSchema::wrap(const std::vector<uint8_t>& payload) {
    SaveHeader h;
    h.payloadSize = static_cast<uint16_t>(payload.size());
    h.checksum = checksum(payload);

    std::vector<uint8_t> out(sizeof(SaveHeader) + payload.size());
    const auto* hp = reinterpret_cast<const uint8_t*>(&h);
    for (size_t i = 0; i < sizeof(SaveHeader); ++i) out[i] = hp[i];
    for (size_t i = 0; i < payload.size(); ++i) out[sizeof(SaveHeader)+i] = payload[i];
    return out;
}

bool SaveSchema::unwrap(const std::vector<uint8_t>& file, std::vector<uint8_t>& payload) {
    if (file.size() < sizeof(SaveHeader)) return false;
    SaveHeader h{};
    auto* hp = reinterpret_cast<uint8_t*>(&h);
    for (size_t i = 0; i < sizeof(SaveHeader); ++i) hp[i] = file[i];
    if (h.magic != 0x46463153 || h.version != 2) return false;
    if (sizeof(SaveHeader) + h.payloadSize != file.size()) return false;

    payload.assign(file.begin() + sizeof(SaveHeader), file.end());
    return checksum(payload) == h.checksum;
}

} // namespace ff1
