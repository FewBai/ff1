#include "dialogue_system.h"

namespace ff1 {

const std::string DialogueSystem::kEmpty;

void DialogueSystem::open(const Dialogue& dialogue) {
    dialogue_ = dialogue;
    page_ = 0;
    active_ = !dialogue_.pages.empty();
}

bool DialogueSystem::next() {
    if (!active_) return false;
    ++page_;
    if (page_ >= static_cast<int>(dialogue_.pages.size())) {
        active_ = false;
        return false;
    }
    return true;
}

const std::string& DialogueSystem::text() const {
    if (!active_ || page_ < 0 || page_ >= static_cast<int>(dialogue_.pages.size()))
        return kEmpty;
    return dialogue_.pages[page_];
}

} // namespace ff1
