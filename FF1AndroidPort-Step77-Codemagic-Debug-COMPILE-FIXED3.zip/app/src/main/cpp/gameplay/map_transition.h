#pragma once
#include <cstdint>
#include <vector>

namespace ff1 {

struct Warp {
    int fromMap = 0;
    int x = 0;
    int y = 0;
    int toMap = 0;
    int toX = 0;
    int toY = 0;
};

class MapTransitionSystem {
public:
    void add(const Warp& warp);
    bool tryWarp(int mapId, int x, int y, int& outMap, int& outX, int& outY) const;

private:
    std::vector<Warp> warps_;
};

} // namespace ff1
