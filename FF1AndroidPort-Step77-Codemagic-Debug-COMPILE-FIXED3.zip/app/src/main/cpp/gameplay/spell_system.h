#pragma once
#include <cstdint>
#include <array>

namespace ff1 {

struct SpellData {
    uint8_t id;
    uint8_t mpCost;
    uint16_t power;
    bool healing;
};

class SpellSystem {
public:
    static const SpellData* find(uint8_t id);
    static bool cast(uint8_t id, int& mp, int& targetHp, int targetMaxHp);
};

} // namespace ff1
