#include "save_system_v2.h"
#include "save_schema.h"
#include <fstream>
#include <iterator>
namespace ff1 {
static void put32(std::vector<uint8_t>&b,uint32_t v){for(int i=0;i<4;++i)b.push_back((v>>(i*8))&255);} 
static bool get32(const std::vector<uint8_t>&b,size_t& p,uint32_t& v){if(p+4>b.size())return false;v=0;for(int i=0;i<4;++i)v|=static_cast<uint32_t>(b[p++])<<(i*8);return true;}
static void put16(std::vector<uint8_t>&b,uint16_t v){b.push_back(v&255);b.push_back((v>>8)&255);} 
static bool get16(const std::vector<uint8_t>&b,size_t&p,uint16_t&v){if(p+2>b.size())return false;v=b[p++];v|=static_cast<uint16_t>(b[p++])<<8;return true;}
static void put8(std::vector<uint8_t>&b,uint8_t v){b.push_back(v);} 
static bool get8(const std::vector<uint8_t>&b,size_t&p,uint8_t&v){if(p>=b.size())return false;v=b[p++];return true;}
static void putStr(std::vector<uint8_t>&b,const std::string&s){put16(b,static_cast<uint16_t>(s.size()));b.insert(b.end(),s.begin(),s.end());}
static bool getStr(const std::vector<uint8_t>&b,size_t&p,std::string&s){uint16_t n; if(!get16(b,p,n)||p+n>b.size())return false;s.assign(reinterpret_cast<const char*>(&b[p]),n);p+=n;return true;}

bool SaveSystemV2::save(const SaveData&d,const std::string&path) const{
    std::vector<uint8_t> payload;
    put32(payload,d.mapId);put32(payload,d.playerX);put32(payload,d.playerY);put32(payload,d.gil);
    for(auto v:d.inventory) put8(payload,v);
    for(auto v:d.spells) put8(payload,v);
    for(auto v:d.openedChests) put8(payload,v);
    for(const auto&p:d.party){
        putStr(payload,p.name);put8(payload,static_cast<uint8_t>(p.job));
        put32(payload,p.stats.level);put32(payload,p.stats.hp);put32(payload,p.stats.maxHp);put32(payload,p.stats.mp);put32(payload,p.stats.maxMp);
        put32(payload,p.stats.attack);put32(payload,p.stats.defense);put32(payload,p.stats.xp);put32(payload,p.stats.nextXp);
        put8(payload,p.equipment.weapon);put8(payload,p.equipment.armor);put8(payload,p.equipment.shield);put8(payload,p.equipment.helmet);put8(payload,p.equipment.glove);
        put8(payload,static_cast<uint8_t>(p.status));put8(payload,p.alive?1:0);
    }
    auto file=SaveSchema::wrap(payload);
    std::ofstream out(path,std::ios::binary|std::ios::trunc);
    if(!out)return false;
    out.write(reinterpret_cast<const char*>(file.data()),static_cast<std::streamsize>(file.size()));
    return static_cast<bool>(out);
}

bool SaveSystemV2::load(SaveData&d,const std::string&path) const{
    std::ifstream in(path,std::ios::binary);
    if(!in)return false;
    std::vector<uint8_t> file((std::istreambuf_iterator<char>(in)),std::istreambuf_iterator<char>()),p;
    if(!SaveSchema::unwrap(file,p))return false;
    size_t pos=0;uint32_t v;
    if(!get32(p,pos,v))return false;
    d.mapId=static_cast<int>(v);
    if(!get32(p,pos,v))return false;
    d.playerX=static_cast<int>(v);
    if(!get32(p,pos,v))return false;
    d.playerY=static_cast<int>(v);
    if(!get32(p,pos,v))return false;
    d.gil=static_cast<int>(v);
    for(auto&x:d.inventory) if(!get8(p,pos,x))return false;
    for(auto&x:d.spells) if(!get8(p,pos,x))return false;
    for(auto&x:d.openedChests) if(!get8(p,pos,x))return false;
    for(auto&pm:d.party){
        uint8_t u;
        if(!getStr(p,pos,pm.name))return false;
        if(!get8(p,pos,u))return false;
        pm.job=static_cast<CharacterClass>(u);
        uint32_t vals[9];
        for(auto&z:vals) if(!get32(p,pos,z))return false;
        pm.stats.level=static_cast<int>(vals[0]);pm.stats.hp=static_cast<int>(vals[1]);pm.stats.maxHp=static_cast<int>(vals[2]);
        pm.stats.mp=static_cast<int>(vals[3]);pm.stats.maxMp=static_cast<int>(vals[4]);pm.stats.attack=static_cast<int>(vals[5]);
        pm.stats.defense=static_cast<int>(vals[6]);pm.stats.xp=static_cast<int>(vals[7]);pm.stats.nextXp=static_cast<int>(vals[8]);
        if(!get8(p,pos,pm.equipment.weapon))return false;
        if(!get8(p,pos,pm.equipment.armor))return false;
        if(!get8(p,pos,pm.equipment.shield))return false;
        if(!get8(p,pos,pm.equipment.helmet))return false;
        if(!get8(p,pos,pm.equipment.glove))return false;
        if(!get8(p,pos,u))return false;
        pm.status=static_cast<Status>(u);
        if(!get8(p,pos,u))return false;
        pm.alive=u!=0;
    }
    d.version=2;
    return pos==p.size();
}
} // namespace ff1
