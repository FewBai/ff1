#pragma once
#include "party_system.h"
#include <string>

namespace ff1 {

enum class CharacterMenuPage { Status, Equipment, Items, Magic };

struct CharacterMenuSnapshot {
    int index = 0;
    std::string name;
    std::string job;
    int level = 1;
    int xp = 0;
    int nextXp = 0;
    int hp = 0, maxHp = 0, mp = 0, maxMp = 0;
    int attack = 0, defense = 0;
    uint8_t weapon = 0, armor = 0;
};

class CharacterMenu {
public:
    static CharacterMenuSnapshot snapshot(const PartySystem& party, int index);
    static bool canEquip(const Character& c, uint8_t weapon, uint8_t armor);
    static const char* jobName(CharacterClass job);
};

} // namespace ff1
