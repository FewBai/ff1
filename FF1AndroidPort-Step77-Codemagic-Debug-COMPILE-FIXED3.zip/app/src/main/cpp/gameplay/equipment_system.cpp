#include "equipment_system.h"
namespace ff1 {
int EquipmentSystem::attackBonus(uint8_t weapon){switch(weapon){case 1:return 10;case 2:return 5;case 3:return 6;default:return 0;}}
int EquipmentSystem::defenseBonus(uint8_t armor,uint8_t shield,uint8_t helmet,uint8_t glove){return (armor?5:0)+(shield?2:0)+(helmet?1:0)+(glove?1:0);}
bool EquipmentSystem::equip(Equipment&e,int slot,uint8_t itemId){if(!itemId)return false;switch(slot){case 0:e.weapon=itemId;return true;case 1:e.armor=itemId;return true;case 2:e.shield=itemId;return true;case 3:e.helmet=itemId;return true;case 4:e.glove=itemId;return true;default:return false;}}
} // namespace ff1
