#include "scene_transition.h"
namespace ff1 {
void SceneTransition::start(SceneState,SceneState to){target_=to;phase_=TransitionPhase::FadeOut;alpha_=0;timer_=0;}
void SceneTransition::tick(int frames){for(int i=0;i<frames && phase_!=TransitionPhase::None;i++){++timer_; if(phase_==TransitionPhase::FadeOut){alpha_+=64;if(alpha_>=255){alpha_=255;phase_=TransitionPhase::Loading;timer_=0;}}else if(phase_==TransitionPhase::Loading){phase_=TransitionPhase::FadeIn;timer_=0;}else if(phase_==TransitionPhase::FadeIn){alpha_-=64;if(alpha_<=0){alpha_=0;phase_=TransitionPhase::None;}}}}
void SceneTransition::finish(){phase_=TransitionPhase::None;alpha_=0;}
}
