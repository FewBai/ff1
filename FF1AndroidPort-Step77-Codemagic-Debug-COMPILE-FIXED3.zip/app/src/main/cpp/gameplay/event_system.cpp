#include "event_system.h"

namespace ff1 {

void EventSystem::setEvent(const Event& event) {
    code_ = event.code;
    pc_ = 0;
}

void EventSystem::reset() {
    code_.clear();
    pc_ = 0;
}

EventOp EventSystem::step(int& gil, int& x, int& y, int& messageId,
                          uint8_t& itemId, int& itemCount, int& battleSeed) {
    if (!running()) return EventOp::End;
    const auto op = static_cast<EventOp>(code_[pc_++]);
    switch (op) {
        case EventOp::Message:
            if (pc_ < code_.size()) messageId = code_[pc_++];
            break;
        case EventOp::GiveGil:
            if (pc_ < code_.size()) gil += code_[pc_++];
            break;
        case EventOp::GiveItem:
            if (pc_ + 1 < code_.size()) {
                itemId = code_[pc_++];
                itemCount = code_[pc_++];
            }
            break;
        case EventOp::HealParty:
            break;
        case EventOp::StartBattle:
            if (pc_ < code_.size()) battleSeed = code_[pc_++];
            break;
        case EventOp::Warp:
            if (pc_ + 1 < code_.size()) {
                x = code_[pc_++];
                y = code_[pc_++];
            }
            break;
        case EventOp::End:
            pc_ = code_.size();
            break;
    }
    return op;
}

} // namespace ff1
