#include "battle_ui_state.h"

namespace ff1 {

void BattleUiController::reset() {
    state_ = {};
}

void BattleUiController::nextCharacter() {
    if (state_.activeCharacter < 3) ++state_.activeCharacter;
}

void BattleUiController::selectTarget(int target) {
    state_.selectedTarget = target;
    state_.mode = BattleUiMode::Commands;
}

void BattleUiController::beginTargeting() {
    state_.mode = BattleUiMode::Targeting;
}

void BattleUiController::beginExecution() {
    state_.mode = BattleUiMode::Executing;
}

void BattleUiController::showResult() {
    state_.mode = BattleUiMode::Result;
}

} // namespace ff1
