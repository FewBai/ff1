#include "battle_system.h"
#include "battle_formations.h"
#include "gameplay/battle_formula.h"
#include <algorithm>

namespace ff1 {

int BattleSystem::damage(int attack,int defense){ return BattleFormula::physical({attack,defense,false,true}).damage; }

void BattleSystem::start(Battle& battle,const SaveData&save,uint32_t seed){ rng_.seed(seed); battle=makeBattleFromFormation(static_cast<uint8_t>(seed%2),save); battle.currentActor=0;battle.selectedEnemy=0; }

void BattleSystem::attack(Battle& battle,int actorIndex,int enemyIndex){
    if(battle.state!=BattleState::PlayerCommand)return;
    if(actorIndex<0||actorIndex>=4||enemyIndex<0||enemyIndex>=battle.enemyCount)return;
    auto& actor=battle.party[actorIndex];auto& enemy=battle.enemies[enemyIndex];if(!actor.alive||!enemy.alive)return;
    enemy.hp=std::max(0,enemy.hp-damage(actor.attack,enemy.defense)); if(enemy.hp==0)enemy.alive=false;
    if(victory(battle)){battle.state=BattleState::Victory;return;}
    for(int i=actorIndex+1;i<4;++i) if(battle.party[i].alive){battle.currentActor=i;return;}
    enemyTurn(battle);if(battle.state==BattleState::PlayerCommand)battle.currentActor=0;
}

void BattleSystem::enemyTurn(Battle&battle){
    battle.state=BattleState::EnemyTurn;
    for(int i=0;i<battle.enemyCount;++i){auto&enemy=battle.enemies[i];if(!enemy.alive)continue;for(auto&target:battle.party)if(target.alive){target.hp=std::max(0,target.hp-damage(enemy.attack,target.defense));if(target.hp==0)target.alive=false;break;}}
    battle.state=defeat(battle)?BattleState::Defeat:BattleState::PlayerCommand;
}

bool BattleSystem::victory(const Battle&battle)const{for(int i=0;i<battle.enemyCount;++i)if(battle.enemies[i].alive)return false;return true;}
bool BattleSystem::defeat(const Battle&battle)const{for(const auto&p:battle.party)if(p.alive)return false;return true;}
void BattleSystem::finishVictory(Battle&battle,SaveData&save){if(battle.state!=BattleState::Victory)return;save.gil+=battle.gilReward;for(int i=0;i<4;++i){save.party[i].stats.hp=battle.party[i].hp;save.party[i].alive=battle.party[i].alive;}}

} // namespace ff1
