#pragma once
#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace ff1 {

enum class GameMode : uint8_t { World = 0, Map = 1, Battle = 2, Menu = 3 };
enum class MenuState : uint8_t { Main = 0, Status = 1, Items = 2, Magic = 3, Equipment = 4, SaveSlots = 5 };
enum class BattleState : uint8_t { None = 0, Start = 1, PlayerCommand = 2, EnemyTurn = 3, Victory = 4, Defeat = 5, Escaped = 6 };
enum class Direction : uint8_t { Up, Right, Down, Left };
enum class CharacterClass : uint8_t { Fighter, Thief, BlackBelt, WhiteMage };
enum class Status : uint8_t { Normal = 0, Poison, Blind, Paralyzed, Stone, Dead };

enum class BattleCommand : uint8_t { Attack = 0, Item = 1, Run = 2, Magic = 3 };

struct Stats {
    int level = 1;
    int hp = 30;
    int maxHp = 30;
    int mp = 0;
    int maxMp = 0;
    int attack = 1;
    int defense = 1;
    int xp = 0;
    int nextXp = 40;
};

struct Equipment {
    uint8_t weapon = 0;
    uint8_t armor = 0;
    uint8_t shield = 0;
    uint8_t helmet = 0;
    uint8_t glove = 0;
};

struct PartyMember {
    std::string name;
    CharacterClass job = CharacterClass::Fighter;
    Stats stats{};
    Equipment equipment{};
    Status status = Status::Normal;
    bool alive = true;
};

struct TileMap {
    int id = 0;
    int width = 32;
    int height = 24;
    std::vector<uint8_t> tiles;
    std::vector<uint8_t> collision;
};

struct BattleActor {
    std::string name;
    int hp = 1;
    int maxHp = 1;
    int attack = 1;
    int defense = 0;
    bool alive = true;
};

struct Battle {
    BattleState state = BattleState::None;
    std::array<BattleActor, 4> party{};
    std::array<BattleActor, 4> enemies{};
    int enemyCount = 0;
    int gilReward = 0;
    int expReward = 0;
    int currentActor = 0;
    int selectedEnemy = 0;
};

struct SaveData {
    uint32_t version = 2;
    int mapId = 0;
    int playerX = 16;
    int playerY = 12;
    int gil = 400;
    std::array<uint8_t, 32> inventory{};
    std::array<uint8_t, 16> spells{};
    std::array<uint8_t, 32> openedChests{};
    std::array<PartyMember, 4> party{};
};

struct GameState {
    GameMode mode = GameMode::World;
    MenuState menu = MenuState::Main;
    Direction facing = Direction::Down;
    SaveData save{};
    TileMap map{};
    Battle battle{};
};

} // namespace ff1
