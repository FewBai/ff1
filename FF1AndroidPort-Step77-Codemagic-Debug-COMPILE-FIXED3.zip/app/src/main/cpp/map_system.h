#pragma once
#include "ff1_types.h"

namespace ff1 {

class MapSystem {
public:
    void reset();
    void load(int mapId);
    bool blocked(int x, int y) const;
    bool move(SaveData& save, int dx, int dy);
    const TileMap& current() const { return map_; }

private:
    TileMap map_;
    void buildPlaceholderMap(int mapId);
};

} // namespace ff1
