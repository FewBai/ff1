#include "data_tables.h"

namespace ff1 {

const std::array<WeaponData, 4> kWeapons{{
    {0, "NONE",   0,   0,  0},
    {1, "SWORD",  40,  10, 10},
    {2, "DAGGER", 10,   5, 15},
    {3, "STAFF",  15,   6,  5}
}};

const std::array<ArmorData, 4> kArmors{{
    {0, "NONE",  0,  0},
    {1, "CLOTH", 10, 1},
    {2, "CHAIN", 60, 15},
    {3, "PLATE", 80, 24}
}};

const std::array<EnemyData, 4> kEnemies{{
    {0, "IMP",   18, 4, 4, 10, 6, 10},
    {1, "WOLF",  20, 5, 5, 12, 8, 20},
    {2, "GRIMP", 30, 8, 7, 14, 12, 30},
    {3, "ORC",   42, 10, 8, 16, 20, 50}
}};

const std::array<EncounterGroup, 2> kEncounters{{
    {0, {0, 0, 0, 0}, 2},
    {1, {1, 2, 0, 0}, 2}
}};

const EnemyData* findEnemy(uint8_t id) {
    for (const auto& e : kEnemies)
        if (e.id == id) return &e;
    return nullptr;
}

} // namespace ff1
