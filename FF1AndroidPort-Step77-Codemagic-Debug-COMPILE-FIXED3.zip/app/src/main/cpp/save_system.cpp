#include "save_system.h"
#include <fstream>

namespace ff1 {

static void writeString(std::ofstream& out, const std::string& s) {
    uint32_t n = static_cast<uint32_t>(s.size());
    out.write(reinterpret_cast<const char*>(&n), sizeof(n));
    out.write(s.data(), n);
}

static bool readString(std::ifstream& in, std::string& s) {
    uint32_t n = 0;
    if (!in.read(reinterpret_cast<char*>(&n), sizeof(n))) return false;
    if (n > 1024) return false;
    s.resize(n);
    return static_cast<bool>(in.read(s.data(), n));
}

bool SaveSystem::save(const SaveData& d, const std::string& path) const {
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;

    out.write(reinterpret_cast<const char*>(&d.version), sizeof(d.version));
    out.write(reinterpret_cast<const char*>(&d.mapId), sizeof(d.mapId));
    out.write(reinterpret_cast<const char*>(&d.playerX), sizeof(d.playerX));
    out.write(reinterpret_cast<const char*>(&d.playerY), sizeof(d.playerY));
    out.write(reinterpret_cast<const char*>(&d.gil), sizeof(d.gil));

    for (const auto& p : d.party) {
        writeString(out, p.name);
        out.write(reinterpret_cast<const char*>(&p.job), sizeof(p.job));
        out.write(reinterpret_cast<const char*>(&p.stats), sizeof(p.stats));
        out.write(reinterpret_cast<const char*>(&p.alive), sizeof(p.alive));
    }
    return static_cast<bool>(out);
}

bool SaveSystem::load(SaveData& d, const std::string& path) const {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;

    if (!in.read(reinterpret_cast<char*>(&d.version), sizeof(d.version))) return false;
    if (d.version != 1) return false;
    if (!in.read(reinterpret_cast<char*>(&d.mapId), sizeof(d.mapId))) return false;
    if (!in.read(reinterpret_cast<char*>(&d.playerX), sizeof(d.playerX))) return false;
    if (!in.read(reinterpret_cast<char*>(&d.playerY), sizeof(d.playerY))) return false;
    if (!in.read(reinterpret_cast<char*>(&d.gil), sizeof(d.gil))) return false;

    for (auto& p : d.party) {
        if (!readString(in, p.name)) return false;
        if (!in.read(reinterpret_cast<char*>(&p.job), sizeof(p.job))) return false;
        if (!in.read(reinterpret_cast<char*>(&p.stats), sizeof(p.stats))) return false;
        if (!in.read(reinterpret_cast<char*>(&p.alive), sizeof(p.alive))) return false;
    }
    return true;
}

} // namespace ff1
