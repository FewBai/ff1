# Step 31 — Android Character Menus

Implemented:
- unified STATUS / ITEMS / MAGIC / EQUIPMENT menu UI
- four-character selector shared by all menu pages
- native character name/job/ATK/DEF/equipment getters via JNI
- usable Potion from the Items page
- weapon/armor equipment actions routed to GameEngine
- menu state navigation and touch interaction
- Magic page reads spell MP/power data; battle remains the execution surface
- native regression test: STEP31_CHARACTER_MENU_UI_CORE_TEST_OK
