# Step 70 — Android GameView Map Render Pipeline

Per-frame pipeline:

Camera
-> Chunk AABB culling
-> visible chunk tile collection
-> visible-first ChunkPreloadScheduler
-> AndroidBitmapCache / BitmapProvider lookup
-> CanvasBitmapRenderer
-> Canvas.drawBitmap(src, dst)

A one-camera-size warmup margin preloads neighboring chunks without submitting
their tiles to Canvas. When the camera crosses a chunk boundary, the new chunk
becomes visible while its neighbors remain warm.

`MapFrameResult` exposes chunks tested/visible, visible tiles, cache hits/misses,
preload submissions, and actual draws.

Asset-neutral: only caller-provided Android resource IDs are used.
