# Step 73 — Bitmap Decode/Publication Thread Decoupling

This step separates background Bitmap decoding from frame-boundary cache publication.

## Pipeline

ChunkPreloader
→ bounded PreloadQueue
→ BitmapDecodeWorker (background)
→ BitmapPublicationQueue (bounded handoff)
→ BitmapPublicationBudget (per-frame count/bytes)
→ BitmapPublicationController
→ AndroidBitmapCache
→ Canvas renderer

## Changes

- `BitmapPublicationQueue`
  - bounded ownership-transfer queue
  - rejects new decoded Bitmaps when full
  - recycles queued Bitmaps during shutdown

- `BitmapPublicationController`
  - drains only a controlled amount at frame boundaries
  - publishes into `AndroidBitmapCache`
  - tracks published count/bytes

- `BitmapPublicationBudget`
  - normal: 2 Bitmaps / 1 MiB per frame
  - throttled pacing: 1 Bitmap / 256 KiB
  - recovery pacing: up to 2 Bitmaps / 2 MiB

- `AndroidBitmapPreloadBridge`
  - no longer posts every decoded Bitmap directly to the main Looper
  - decoded ownership moves to the bounded publication queue
  - exposes decode/rejection metrics

- `AndroidMapFramePipeline`
  - optionally drains the publication queue before drawing
  - publication pressure follows the Step 72 frame-pacing state

## Why

A burst of background decodes can otherwise cause many Bitmap cache insertions in one UI frame.
Step 73 spreads that work over frame boundaries, reducing allocation/publication spikes and
giving the frame-pacing layer a direct backpressure mechanism.

This does not claim to directly control GPU texture upload timing; Android hardware Canvas may
upload Bitmap resources lazily. The controlled boundary is CPU-side Bitmap publication/cache work.

No commercial Final Fantasy assets are bundled.
