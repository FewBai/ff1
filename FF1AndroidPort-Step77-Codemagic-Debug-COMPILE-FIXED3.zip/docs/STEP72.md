# Step 72 — Frame Pacing + Predictive Preload

## Frame pacing
Targets:
- 60 FPS: 16.67 ms
- 90 FPS: 11.11 ms
- 120 FPS: 8.33 ms

Render, preload and decode are tracked independently. Two consecutive
over-budget frames throttle preload; sustained healthy frames allow recovery.

## Predictive preload
`CameraVelocityPredictor` estimates camera movement and looks ahead several
frames. Chunks intersecting the predicted camera area are added to the preload
set without being submitted to Canvas early.

## Result
The renderer now reacts to frame pressure and can warm the map in the direction
the camera is actually moving, reducing visible cache misses during rapid travel.

Asset-neutral; no commercial FF1 assets are included.
