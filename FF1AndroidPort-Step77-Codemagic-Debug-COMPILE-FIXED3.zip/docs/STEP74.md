# Step 74 — Bitmap Memory Pool / Size-Class Reuse + GC Pressure Control

## Pipeline

Background decode
→ optional `BitmapPool.acquire()`
→ `BitmapFactory.Options.inBitmap`
→ BitmapPublicationQueue
→ per-frame publication budget
→ AndroidBitmapCache
→ Canvas renderer

## New components

- `BitmapSizeClass`
  - TINY ≤64 KiB
  - SMALL ≤256 KiB
  - MEDIUM ≤1 MiB
  - LARGE ≤4 MiB

- `BitmapPool`
  - reuses only mutable software Bitmaps
  - rejects HARDWARE bitmaps
  - bounded total bytes and per-class retention
  - erases reused Bitmap before handing it to decoding

- `BitmapDecodeReuseOptions`
  - prepares an `inBitmap` decode option when a compatible pooled Bitmap exists

- `BitmapGcPressureController`
  - implements `ComponentCallbacks2`
  - trims the pool first under pressure
  - progressively trims the decoded cache
  - clears both under critical/low-memory conditions

## Safety

Ownership is explicit:
1. pool owns a Bitmap while idle
2. decode owns it while `inBitmap` is used
3. publication queue owns a decoded result
4. cache owns a published Bitmap
5. renderer only borrows it for drawing

Do not recycle a Bitmap while it is in the publication queue or being drawn.

`inBitmap` reuse is intentionally limited to mutable software ARGB_8888 Bitmaps; this avoids
unsafe reuse across incompatible Android Bitmap configurations.

No commercial Final Fantasy assets are bundled.
