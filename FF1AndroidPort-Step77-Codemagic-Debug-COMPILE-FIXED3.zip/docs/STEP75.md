# Step 75 — RenderFrame Lifetime + Safe Bitmap References

## Problem

A cache eviction or memory-pressure trim must never recycle a Bitmap that a current
Canvas frame still references.

## New lifetime model

`RenderFrameManager`
→ `RenderFrameLease`
→ `BitmapCache.acquireForFrame()`
→ `Canvas.drawBitmap()`
→ release
→ frame close
→ `BitmapRetirementQueue.drain()`
→ physical recycle

## Components

- `RenderFrameLease`
  - frame-scoped borrow counts
  - rejects new borrows after close

- `RenderFrameManager`
  - tracks active frame leases
  - exposes active leases for eviction checks

- `BitmapRetirementQueue`
  - delays physical Bitmap recycling while any active frame borrows it

- `SafeCanvasBitmapRenderer`
  - acquires the Bitmap through the frame lease
  - checks `isRecycled`
  - releases the borrow after draw

- `AndroidBitmapCache`
  - can attach the render lifetime manager and retirement queue
  - provides `beginFrame()`, `endFrame()` and `acquireForFrame()`

## Result

Cache eviction and memory pressure can now request retirement without racing a
currently executing Canvas draw. The actual `Bitmap.recycle()` occurs only after
all active frame leases release the object.

No commercial Final Fantasy assets are bundled.
