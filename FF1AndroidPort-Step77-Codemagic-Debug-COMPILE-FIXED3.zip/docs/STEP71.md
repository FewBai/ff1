# Step 71 — Performance Layer

## Runtime controls
- `FramePerformanceMonitor`: frame time, smoothed frame time, FPS, slow-frame rate, cache hit rate.
- `AdaptivePreloadBudget`: dynamically adjusts preload work from 1..8 requests/frame.
- Slow frames or deep queues reduce preload work.
- Healthy frames with low cache hit rate allow preload budget to recover.
- `AndroidBitmapPreloadBridge` limits concurrent bitmap decoding with a semaphore.
- `ChunkPreloadScheduler` gives visible IDs strict priority and never submits unlimited work.
- `AndroidMapFramePipeline` records the resulting performance metrics.

## Goal
Keep Canvas rendering responsive during rapid camera movement instead of allowing
background bitmap decoding/preloading to consume the whole frame budget.

## Validation
Native adaptive-budget stress regression passed.
