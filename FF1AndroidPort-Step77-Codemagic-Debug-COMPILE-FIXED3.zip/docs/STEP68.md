# Step 68 — Renderer Bitmap Cache

## Pipeline
Chunk preload -> bounded PreloadQueue -> Kotlin BitmapDecodeWorker -> BitmapFactory.decodeResource()
-> actual Android Bitmap -> AndroidBitmapCache (LRU) -> AndroidBitmapProvider
-> CanvasBitmapRenderer -> Canvas.drawBitmap(src, dst).

## Memory pressure
`BitmapMemoryController` implements `ComponentCallbacks2` and reduces the cache budget
under Android memory pressure. Only entries removed from the cache are recycled.

## Scope
This remains asset-neutral. It does not include commercial Final Fantasy assets or ROM data.

## Test
`STEP68_RENDERER_BITMAP_CACHE_TEST_OK`
