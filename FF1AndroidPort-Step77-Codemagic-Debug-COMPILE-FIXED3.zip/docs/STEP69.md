# Step 69 — LRU BitmapCache + ChunkPreloadScheduler + Visible Render Loop

## Closed loop
1. Visible-area renderer submits visible bitmap IDs.
2. `ChunkPreloadScheduler` prioritizes visible IDs, then surrounding preload IDs.
3. Missing IDs call `AndroidBitmapPreloadBridge.request()`.
4. Background `BitmapFactory.decodeResource()` produces an actual `Bitmap`.
5. Publication inserts the Bitmap into `AndroidBitmapCache` (LRU).
6. `AndroidBitmapProvider` exposes the resident Bitmap.
7. `CanvasBitmapRenderer` calls `Canvas.drawBitmap(src, dst)`.
8. If an entry is evicted under the LRU/memory-pressure policy, the next frame sees a miss and schedules it again.

Visible rendering therefore no longer depends on a separate/manual cache warm-up step.

## Scope
Asset-neutral Android resource IDs only; no commercial Final Fantasy assets or ROM data are bundled.

## Validation
Native closed-loop regression: preload/publication -> cache hit -> eviction -> re-request/re-publication.
