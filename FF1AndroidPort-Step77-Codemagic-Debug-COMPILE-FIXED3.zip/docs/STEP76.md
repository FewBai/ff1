# Step 76 — RenderFrame Multi-Layer Batches + Bulk Bitmap References

## Goal

Unify map, objects, actors, effects and UI into one frame-level batch so each unique
Bitmap is acquired once and released once.

## Pipeline

Frame begin
→ collect MAP / OBJECTS / ACTORS / EFFECTS / UI draw items
→ unique Bitmap acquisition
→ layer + z sorting
→ Canvas.drawBitmap
→ batch clear
→ release all frame borrows
→ end frame
→ retirement queue drain

## Components

- `RenderLayer`
  - MAP
  - OBJECTS
  - ACTORS
  - EFFECTS
  - UI

- `RenderBatchItem`
  - Bitmap id
  - source/destination rectangles
  - layer and z order

- `RenderFrameBatch`
  - deduplicates Bitmap acquisition
  - provides ordered draw items
  - releases all acquired references together

- `LayeredCanvasRenderer`
  - renders the sorted batch

- `RenderFrameCoordinator`
  - owns the complete frame lifecycle
  - guarantees batch cleanup and frame close through `finally`

## Benefit

If 40 draw commands use only 8 unique Bitmaps, the frame now borrows those 8 Bitmaps
once instead of repeatedly acquiring/releasing the same references.

No commercial Final Fantasy assets are bundled.
