# Step 30 — Unified RPG HUD / Character Menu Backend

Added a UI-neutral character menu model shared by Status, Equipment, Items and Magic screens.

- Character snapshot: job, level, EXP, HP/MP, ATK/DEF, equipment IDs
- Job names for Fighter/Thief/BlackBelt/WhiteMage
- Equipment eligibility hook
- Native regression test
- CMake integration

Android can consume the same snapshot for a unified menu without duplicating game rules.
