# Step 66 — Bounded Background Preload Queue

Implemented:
- bounded preload queue
- request deduplication
- loading-state deduplication
- resident-state deduplication
- oldest queued request eviction when capacity is reached
- worker budget per drain
- decode → ready → resident transition

No preload task creates a renderer Draw Call.

Regression:
STEP66_PRELOAD_QUEUE_TEST_OK

Next Step 67:
- connect queue completion to the real BitmapCache
- perform Kotlin Bitmap decoding on a background executor
- marshal only cache publication back to the Android/main rendering boundary
