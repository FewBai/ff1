# FF1 Android Port — Step 77 Codemagic Debug Build

This project is prepared for cloud Android Debug APK builds.

## Build target

`app/build/outputs/apk/debug/app-debug.apk`

## Cloud build

Codemagic runs `codemagic.yaml`. The workflow:
1. Sets `local.properties` to the Android SDK supplied by Codemagic.
2. Downloads Gradle 8.13 into the temporary CI workspace.
3. Runs `assembleDebug`.
4. Publishes `app-debug.apk` as a build artifact.

No release keystore is required for this Debug build.

## Project base

The Android application is based on the previously validated FF1 project and overlays the Step 74–76 rendering/cache additions.

## Local build

A local machine with Android SDK, Java 17, and network access can use Gradle 8.13 directly:

`gradle --no-daemon assembleDebug`

