# Step 48 — Active Frame Pinning + Ordered Render Batch + Frame Budget

Added active-frame resource pin/unpin, Map → Actor → Effect → UI ordering,
bounded draw/prefetch work, cache-miss accounting, and camera propagation into
the renderer for every frame.

Frame flow:
Camera → Chunk requests → bounded prefetch → ordered visible batch
→ Bitmap cache hit → pin resource → Atlas crop → Canvas draw
→ unpin resources no longer needed by the next frame.

Native regression: STEP48_FRAME_BUDGET_PIN_TEST_OK

Next Step 49: Tile-map batch renderer + actor/effect layers + Android frame pacing.
