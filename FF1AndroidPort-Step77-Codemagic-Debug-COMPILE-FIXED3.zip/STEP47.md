# Step 47 — Complete Android Frame Rendering Loop

Pipeline:
Camera frame
 -> native Chunk interest update
 -> prioritized resource requests
 -> Kotlin BitmapCache/background decode
 -> cache hit check
 -> atlas region lookup
 -> world-to-screen transform
 -> Canvas.drawBitmap()

Added:
- GameFramePipeline
- frame statistics
- Kotlin Step47GameFrameRenderer
- cache-miss skipping without blocking the UI thread
- native regression test

Asset-neutral: no commercial FF1 assets are included.

Native test:
STEP47_GAME_FRAME_PIPELINE_TEST_OK

Next:
- active-resource pin/unpin per frame
- tile-map batch rendering
- actor/effect draw ordering
- frame-time budget and dropped-prefetch accounting
