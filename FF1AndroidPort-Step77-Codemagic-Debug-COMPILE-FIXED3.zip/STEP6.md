# Step 6 — RPG Gameplay Systems

Added to the clean-room runtime:

- progression / XP / level framework
- inventory stacks
- weapon/armor/potion shop interface
- bytecode-style event scripting interface
- spell definitions and MP casting
- inn/clinic service interfaces
- GameEngine event execution hook
- JNI event execution hook
- Android NativeGame API updated

The event system is deliberately generic. It can later consume decoded,
authorized event data without hard-wiring proprietary ROM bytes into the APK.

The public FF1 disassembly documents that the original project has complete
map object placement/movement/collision/event data and shop/inn/clinic logic,
while battle work is documented separately. citeturn0search0turn0search4

No commercial ROM, graphics, music, or extracted proprietary asset bundle is
included in this package.

Next target: replace placeholder formulas with independently implemented,
testable game rules; add party creation, equipment slots, status effects,
dialogue text abstraction, map transitions, and a proper Android save schema.
