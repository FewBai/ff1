# Step 45 — JNI Camera/Resource Bridge

Added:
- CameraResourceController
- bounded JNI request polling
- native JNI entry points for create/update/poll/destroy
- Kotlin Step45NativeResourceBridge
- Camera-frame -> C++ ChunkManager -> prioritized requests -> Kotlin
  Step44ResourceManager pipeline
- native regression test

The bridge remains asset-neutral. Android maps resource IDs to
authorized/user-owned assets.

Native test:
STEP45_JNI_BRIDGE_TEST_OK

Android build note:
The JNI source is compiled as part of the Android native target when the
Android NDK is configured. The Kotlin side loads the native library according
to the application's existing native-library setup.
