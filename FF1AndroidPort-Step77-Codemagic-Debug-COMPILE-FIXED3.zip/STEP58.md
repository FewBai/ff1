# Step 58 — Real Cache/Atlas Hooks + Renderer Frame Scope

The telemetry is now attached at the ownership and frame boundaries.

BitmapCache:
decode success → bitmap byte accounting
eviction → bitmap byte accounting

TextureAtlas:
storage allocation → atlas bytes
region add/remove → region accounting

Renderer:
DebugRenderFrame creates a frame scope
→ beginFrame()
→ real render work records counters
→ destructor/endFrame()
→ native debug snapshot

This is the first step where cache/atlas accounting and frame timing share
the same renderer frame lifetime.

Regression:
STEP58_REAL_RENDERER_FRAME_TEST_OK

Next Step 59:
- wire DebugRenderFrame into TileMapRenderLoop/CanvasAtlasRenderer itself
- count every actual Canvas draw command
- count actual BitmapCache hit/miss paths
- push the resulting snapshot through the Android Choreographer overlay
