# Step 40 — Android Canvas Sprite/Animation Integration

Added:
- asset-neutral CanvasScene world-space actor state
- four-direction idle/walk animation mapping
- chest-open animation reservation
- Android Canvas renderer bridge
- camera-relative actor drawing
- native regression test

The Android renderer deliberately uses placeholder geometry. It is ready to
consume Bitmap frames supplied by the app, but does not bundle FF1 ROM graphics.

Native test:
STEP40_CANVAS_SCENE_TEST_OK

Next:
- texture atlas and Bitmap cache
- asynchronous resource loading
- LRU resource eviction
- Android memory-pressure handling
- authorized/user-provided sprite sheet ingestion
