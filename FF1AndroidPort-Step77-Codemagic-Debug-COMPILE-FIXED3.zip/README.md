# FF1 Android Port — Step 3

A clean-room Android gameplay-core scaffold based on the architecture needed
to port the public NES FF1 disassembly. This project contains no Square Enix
ROM, graphics, music, or other proprietary game assets.

## Step 3 modules

### Native C++ core
- `ff1_types.h` — game state, party, map, battle and save structures
- `game_engine.*` — central state machine
- `map_system.*` — tile map, collision and movement
- `battle_system.*` — turn-based battle state machine
- `menu_system.*` — menu state navigation
- `save_system.*` — versioned binary save/load
- `ff1_jni.cpp` — Android JNI boundary

### Android layer
Kotlin calls the C++ engine through JNI, following Android's supported
NDK/CMake + JNI model.

## Current behavior

- Start with a four-member party.
- Move on a collision-enabled placeholder map.
- Enter the menu.
- Start a battle through the native engine.
- Attack enemies.
- Enemy turn and defeat/victory states.
- Award Gil and synchronize HP after victory.
- Save/load API is ready for Android app-private storage.

## What remains for an actual FF1 port

The engine interfaces are deliberately ready for real FF1 data, but the
placeholder map/enemy definitions are NOT claimed to be the complete original
game. The next work is data and logic migration from the public
`FF1Disassembly` project:

- RAM/state definitions from `variables.inc`
- constants from `Constants.inc`
- map/tile attribute formats
- battle formation data
- original event and menu rules
- original progression/data tables

The FF1Disassembly repository states that it is a fully commented,
documented, reassemblable disassembly of the US NES release, and specifically
documents `variables.inc`, tile attributes and battle formation formats.

Source:
https://github.com/Entroper/FF1Disassembly

## Android build prerequisites

Install Android Studio with:
- Android SDK
- NDK (Side by side)
- CMake

Then open this project and sync Gradle.

Build with:

    ./gradlew :app:assembleDebug

or Windows:

    gradlew.bat :app:assembleDebug

Android documentation:
https://developer.android.com/studio/projects/install-ndk
https://developer.android.com/studio/projects/add-native-code
