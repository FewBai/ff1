# Step 43 — Camera/Chunk Driven Resource Interest

Added:
- ResourcePriorityQueue with Visible/Prefetch/Background priorities
- MapChunkManager for world-to-chunk conversion and visible/prefetch sets
- ChunkLifecycle for Active → Prefetch → Cold transitions
- bounded interest requests suitable for the Android decode/cache layer
- native regression test
- CMake integration

The chunk system is asset-neutral. It produces resource-interest requests;
the Android adapter decides how those IDs map to authorized/user-owned
Bitmap or tile resources.

Native test:
STEP43_CHUNK_PREFETCH_TEST_OK

Next:
- Android/JNI bridge for chunk-interest requests
- camera-direction weighted prefetch
- viewport tile enumeration
- cache pin/unpin for active chunks
- end-to-end Android frame rendering
