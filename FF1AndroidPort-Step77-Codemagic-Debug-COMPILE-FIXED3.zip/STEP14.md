# Step 14 — Interactive UI / Four-Person Battle / Save Slots

Step 14 consolidates the gameplay core and improves the Android side:

- Continuous Android game tick
- World touch movement + D-pad
- Status / Items / Magic / Equipment / Save Slots tabs
- Four battle actors and enemy target selection
- Attack / Item / Run commands
- Potion use and enemy response
- Equipment action entry point
- Three manual save/load slots
- Android lifecycle autosave
- Full versioned native save of map, Gil, inventory, spells, party progression,
  status and equipment
- Battle HP is synchronized back into the party before reward processing
- Save/load state is handled by one V2 serializer boundary

This project is still a clean-room runtime with placeholder data rather than a
packaged commercial ROM or original copyrighted asset bundle.
