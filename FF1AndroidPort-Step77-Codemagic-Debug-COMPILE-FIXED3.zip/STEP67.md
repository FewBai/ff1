# Step 67 — Kotlin Bitmap Decode → Cache Publication

ChunkPreloader → bounded PreloadQueue → Kotlin BitmapDecodeWorker →
BitmapFactory.decodeResource() on a background executor → BitmapDecodeResult →
main-thread publication → BitmapCacheStore READY → renderer cache hit.

Decoding is off the rendering thread; duplicate pending requests are
suppressed; decoded byte size is captured; publication updates memory telemetry.

This is an asset-neutral Android resource adapter and does not bundle commercial
FF1 ROM/extracted assets.

Regression: STEP67_KOTLIN_BITMAP_PUBLICATION_TEST_OK

Next Step 68: connect published cache entries to the real renderer BitmapProvider,
then add memory-pressure eviction/recycle policy.
