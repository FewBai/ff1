# Step 7 — World/Event Gameplay Loop

This milestone adds the systems needed to connect maps into a real RPG loop:

- equipment slots and stat bonuses
- status-effect state machine
- multi-page dialogue abstraction
- map warp/transition table
- treasure chest state and rewards
- GameEngine APIs for warp/chests/dialogue
- JNI APIs for Android
- Android touch hooks for chest/warp testing

The public FF1 disassembly project states that map objects, NPC placement,
movement, collision and event data, shops/inns/clinics, treasure chests and
dialogue are documented in the source. The project also documents battle
formation formats and a RAM map. citeturn0search0turn0search1

This project intentionally keeps those interfaces data-driven rather than
shipping the commercial game's ROM/graphics/music. The next migration step
can populate the adapters from data the user is authorized to use.

Next:
- party creation and class restrictions
- proper equipment inventory linkage
- full dialogue/text encoding adapter
- map object/NPC definitions
- multi-map world/ship/airship state
- battle rewards wired into XP/levels
- automated C++ unit tests for all gameplay systems
