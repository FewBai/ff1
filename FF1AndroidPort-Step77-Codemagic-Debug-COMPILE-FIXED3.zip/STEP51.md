# Step 51 — Real Tile IDs + Collision + Camera Dead Zone

Added the first unified world-state layer:

MapTileGrid
→ MapTileSource
→ PlayerCollision
→ Player position
→ CameraFollow / Dead Zone
→ Step51MapWorld

Tile records now contain:
- tileId
- collision flag
- flags

The collision system performs axis-separated movement so blocked tiles stop
the player without cancelling free movement on the other axis.

The camera follows the player only when the player exits the configured
dead-zone rectangle.

Native regression:
STEP51_REAL_TILE_COLLISION_CAMERA_TEST_OK

Next Step 52:
- populate TileBatchRenderer from real MapTileGrid tile IDs
- map tile ID → atlas region lookup
- connect collision map and rendered map from the same data
- finish Step51MapWorld render integration
