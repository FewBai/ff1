# Step 23 — Playable Exploration Loop

Added a clean-room, data-driven sample region to validate the complete exploration loop:

- movement and collision
- NPC interaction/dialogue
- chest opening with item + Gil rewards
- encounter trigger after exploration steps
- map state stored in SaveData
- focused native regression test

The sample region is original placeholder content and does not contain commercial FF1 assets or text.

Next: connect this runtime directly to GameEngine/Android UI, then add the map/NPC/chest state to the persistent save schema.
