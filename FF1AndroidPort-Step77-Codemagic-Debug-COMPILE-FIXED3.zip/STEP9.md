# Step 9 — Battle Rewards → Progression → Save Boundary

This milestone connects the gameplay systems instead of leaving them as
independent modules.

Added:

- battle reward application
- EXP distribution to living party members
- Gil reward application
- level-up stat growth
- HP/MP refill on level-up
- GameEngine reward API
- JNI/Kotlin reward API
- versioned save-file header with checksum validation

The public FF1Disassembly README confirms that the project is a fully
commented, documented and reassemblable US NES FF1 disassembly, including a
RAM map and notes on battle formation formats. citeturn0search0

## Important

The reward numbers and growth rules in this Android runtime are still
implementation placeholders. They are not claimed to be an exact extraction
of Square Enix's original data.

## Next

Step 10 should focus on:
1. exact battle formulas from the documented source
2. exact enemy/formation adapters
3. party/equipment menus
4. map object/NPC tables
5. save/load of the expanded party state
6. a real Android playable smoke-test path
