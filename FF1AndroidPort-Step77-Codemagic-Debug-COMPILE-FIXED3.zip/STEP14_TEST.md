# Step 14 Native Verification

Verified in the working container with:

- `g++ -std=c++17 -Wall -Wextra -Werror`
- runtime gameplay regression test
- battle formula regression test
- end-to-end Step 14 smoke test (battle -> reward -> save -> load)

Result:

`STEP14_NATIVE_ALL_TESTS_OK`

This verifies the portable C++ core. It does not constitute a physical Android
device install test because this environment does not provide an Android
emulator/device runtime.
