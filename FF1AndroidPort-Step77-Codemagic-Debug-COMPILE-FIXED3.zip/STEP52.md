# Step 52 — Real Tile ID → Texture Atlas

This stage removes the test tile region selection.

Pipeline:

MapTileGrid
→ real Tile ID
→ TileAtlasMapper
→ Atlas Region
→ RealTileBatchBuilder
→ TileBatchRenderer
→ BitmapCache readiness
→ Texture Atlas
→ Canvas.drawBitmap()

The same MapTile record now supplies both:
- collision data
- rendered Tile ID

Unknown Tile IDs are counted instead of silently drawing an arbitrary region.

Native regression:
STEP52_REAL_TILE_ATLAS_MAPPING_TEST_OK

Step 53:
- expose the configured CanvasAtlasRenderer through TileMapRenderLoop
- complete Step52MapRenderer integration
- connect real player/NPC entities to the same world frame
- start Android debug overlay for cache/draw/frame telemetry
