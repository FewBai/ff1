# Step 8 — Playable Loop Integration

This step moves the project from a collection of gameplay subsystems toward a
single runtime loop.

Added:

- party/class runtime model
- level/XP-aware characters
- derived attack/defense from equipment
- GameFlow state machine
- typed gameplay event definitions
- native runtime unit-test target
- GameEngine ownership of PartySystem/GameFlow
- JNI party-living count

The FF1 disassembly is a complete, documented, reassemblable NES
disassembly; its README identifies `variables.inc` as a RAM map and
documents tile-attribute and battle-formation formats. citeturn0search0

## Native tests

Configure CMake with:

    -DFF1_BUILD_TESTS=ON

Then build `ff1_runtime_tests` and run it on the host.

## Scope

This is still a clean-room Android runtime. It does not package Square Enix
ROM data, original graphics, music, or other copyrighted asset bundles.

Next step:
- wire party stats into the battle actor state
- apply battle XP/rewards to party progression
- connect equipment/inventory to menu actions
- implement map object/NPC tables
- add save-schema versioning for the expanded party state
- add automated Android smoke tests
