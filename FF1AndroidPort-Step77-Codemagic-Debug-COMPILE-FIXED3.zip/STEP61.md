# Step 61 — Android Map Render Loop Integration

The renderer is now connected to a concrete map render-loop abstraction.

Per Android frame:
View.onDraw
→ AndroidMapRenderLoop
→ Native MapRenderLoop
→ CanvasAtlasRenderer
→ BitmapProvider lookup
→ Canvas.drawBitmap
→ renderer endFrame
→ Debug snapshot
→ Android overlay

The loop records:
- real bitmap lookup hit/miss
- actual draw count
- missing tiles
- visible/submitted tile counts
- frame duration

`DebugGameView` uses `postInvalidateOnAnimation()` so the map render loop
continues on Android's frame cadence.

Regression:
STEP61_MAP_RENDER_LOOP_TEST_OK

Next Step 62:
- connect Chunk visible-area enumeration and camera transform
- use the real BitmapCache/TextureAtlas crop data
- feed actual screen-space draw rectangles into CanvasAtlasRenderer
