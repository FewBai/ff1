# Step 18 — ITEM / MAGIC Real Execution

Implemented:
- Item action execution with HP recovery.
- Magic action execution using the existing spell table.
- MP cost consumption.
- Healing and damage spells.
- Target validation.
- Enemy defeat and damage presentation.
- Battle executor dispatches ATTACK / ITEM / MAGIC.
- Native regression test.

The default spell/item values are runtime test data; authorized game data can
replace the table without changing the battle UI or action interfaces.
