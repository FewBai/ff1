# Step 39 — Sprite / Animation Resource System

Restored from the existing Step 35 project and extended with an asset-neutral
graphics runtime.

Added:
- SpriteFrame / SpriteAnimation / SpriteInstance
- SpriteManager for validated RGBA resources and animations
- AnimationPlayer with loop/non-loop timing
- RenderActorSystem for player/NPC/chest/enemy/effect actors
- EffectAnimationSystem hooks for attack/magic/heal/chest/fade effects
- CMake integration
- Native regression test

No commercial FF1 ROM, extracted game graphics, music, or proprietary asset
bundle is included.

Native test result:
STEP39_SPRITE_ANIMATION_TEST_OK

Next:
- connect Android Canvas to SpriteManager/AnimationPlayer
- player four-direction movement animations
- NPC idle/walk animations
- chest-open animation
- battle effect animations
- texture atlas/cache integration
