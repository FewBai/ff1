# Step 4 — Open and Build

## Recommended

1. Install the current Android Studio.
2. Install:
   - Android SDK Platform 36
   - Android SDK Build-Tools
   - NDK (Side by side)
   - CMake 3.22.1
3. Open the `ff1-android-port` folder in Android Studio.
4. Let Gradle sync and download Gradle 8.13.
5. Select the `app` configuration.
6. Run on an emulator/device.

## Command line

If Gradle is installed:

    gradle :app:assembleDebug

The APK will be generated at:

    app/build/outputs/apk/debug/app-debug.apk

The included `gradlew`/`gradlew.bat` is a bootstrap helper rather than a
vendored Gradle wrapper JAR. Android Studio can regenerate a standard wrapper
from the IDE/Gradle installation if desired.

## Important

This is still a clean-room port framework. It contains placeholder map and
battle data. It does not contain the commercial FF1 ROM or Square Enix
graphics/music.

The next engineering step is importing legally usable FF1 data/logic into
the interfaces in `map_system.*`, `battle_system.*`, and `game_engine.*`.
