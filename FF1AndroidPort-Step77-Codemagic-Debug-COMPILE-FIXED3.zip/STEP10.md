# Step 10 — Battle/Save Integration Boundary

This step introduces a single, testable battle-formula layer and connects it
to the existing BattleSystem.

Added:

- `BattleFormula` physical attack calculation
- deterministic critical/miss behavior at the API boundary
- healing formula interface
- BattleSystem now calls the shared formula
- native regression test for normal/critical/miss cases
- existing Step 8 runtime test remains available
- versioned save header from Step 9 remains the persistence boundary

## Build native tests

Configure CMake with:

    -DFF1_BUILD_TESTS=ON

Build and run:

    ff1_runtime_tests
    ff1_battle_formula_test

## Data migration boundary

The public FF1Disassembly project describes itself as a fully commented,
documented and reassemblable US NES FF1 disassembly, with `variables.inc` as
a RAM map and notes covering tile attributes and battle formation data.
citeturn0search0

This project therefore keeps the Android runtime independent from the
commercial ROM/asset bundle. Authorized decoded data can be supplied through
the data adapters without changing the Android UI or core engine.

## Next

Step 11 should wire:
- exact enemy stats and formations supplied by authorized data
- hit/critical/defense behavior into BattleSystem
- party equipment/inventory menu actions
- save/load of party progression, inventory, equipment and map state
- Android startup -> new game -> field -> encounter -> battle -> reward ->
  save smoke test
