# Step 46 — Bitmap Cache → Texture Atlas → Camera → Canvas

Added:
- CanvasAtlasRenderer: atlas region lookup + world-to-screen camera transform
- AndroidCanvasBridge: cache-hit gate before drawing
- Kotlin Step46CanvasRenderer: BitmapCache lookup + Canvas.drawBitmap(src,dst)
- visible sprite filtering
- native regression test
- CMake integration

Runtime path:
Chunk prefetch -> Step44ResourceManager BitmapCache -> CanvasAtlasRenderer
atlas region -> camera world-to-screen transform -> AndroidCanvasBridge
-> Kotlin Canvas.drawBitmap()

Asset-neutral: no commercial FF1 graphics are included.

Native test:
STEP46_CANVAS_ATLAS_TEST_OK
