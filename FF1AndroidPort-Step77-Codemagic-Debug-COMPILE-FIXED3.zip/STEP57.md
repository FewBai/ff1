# Step 57 — Real Cache/Atlas Metrics + Android Frame Driver

Added a concrete runtime telemetry layer.

Bitmap cache accounting:
- loaded bitmap bytes
- evicted bitmap bytes
- cache entry count

Texture atlas accounting:
- backing byte size
- atlas region count

Both are composed by `DebugRuntimeBridge` and injected into the native
debug snapshot at frame end.

Android uses `Choreographer` through `DebugFrameDriver` to publish the
completed native snapshot to the overlay each frame.

Regression:
STEP57_REAL_CACHE_ATLAS_METRICS_TEST_OK

Next: wire these accounting hooks directly into the existing BitmapCache and
TextureAtlas implementations and bracket the real renderer frame.
