# Step 11 — Gameplay Wiring and Save/Equipment Boundary

Added:

- inventory-driven equipment menu API
- equipment -> inventory integration
- versioned save-game payload encoder/decoder
- map position + Gil + inventory persistence
- checksum validation through the Step 9 save schema

The public FF1Disassembly project is a fully commented/reassemblable US NES
disassembly and documents map/NPC/event systems, menus, shops, inns/clinics,
treasure chests and dialogue. It also includes a RAM map and battle formation
format notes. citeturn0search0turn0search5

This Android project remains a clean-room runtime and does not bundle the
commercial ROM or original copyrighted asset package.

Next: connect the Android save path to this versioned schema, serialize the
full party/equipment state, and build the first end-to-end smoke-test flow.
