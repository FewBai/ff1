# Step 64 — Chunk-Level Culling + Android Viewport

Added a two-stage culling path:

Android View width/height
→ Camera viewport
→ Chunk AABB culling
→ Tile culling
→ BitmapCache
→ Atlas crop
→ Canvas.drawBitmap

Entire off-screen chunks are skipped before tile enumeration.

Regression:
STEP64_CHUNK_CULLING_TEST_OK

Next Step 65:
- connect the real Android View dimensions to native renderer state
- add chunk visibility/preload radius
- preload chunks around the camera without submitting them for drawing
