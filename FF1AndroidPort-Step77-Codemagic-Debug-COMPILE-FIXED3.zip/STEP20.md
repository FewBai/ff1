# Step 20 — Battle presentation

Added transient battle feedback for damage, healing, defeat, victory and rewards; exposed through JNI and shown by the Android battle overlay.
