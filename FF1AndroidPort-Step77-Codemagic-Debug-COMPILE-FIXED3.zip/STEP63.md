# Step 63 — Chunk Visibility + Camera Culling

Implemented viewport-based world-space culling before Atlas/Canvas submission.

Pipeline:
Camera viewport → tile intersection → visible tile count → BitmapCache lookup
→ Atlas crop → world-to-screen → Canvas.drawBitmap.

Off-screen tiles never reach Canvas.drawBitmap.

Regression:
STEP63_CAMERA_CULLING_TEST_OK

Next Step 64:
- replace per-tile visible chunk input with real Chunk grid enumeration
- add chunk-level culling before tile-level culling
- integrate Android camera/viewport dimensions from the actual View
