package com.ff1.android

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.io.InputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class Step44ResourceManager(
    private val context: Context,
    maxCacheBytes: Int = (Runtime.getRuntime().maxMemory() / 8).toInt()
) : ComponentCallbacks2 {

    private val cache = object : LruCache<Int, Bitmap>(maxCacheBytes) {
        override fun sizeOf(key: Int, value: Bitmap): Int =
            value.allocationByteCount
    }

    private val executor: ExecutorService = Executors.newFixedThreadPool(2)
    private val loading = HashSet<Int>()
    private val lock = Any()

    fun get(id: Int): Bitmap? = synchronized(lock) { cache.get(id) }

    fun request(
        id: Int,
        priority: Int,
        assetPath: String,
        onReady: (Bitmap) -> Unit = {}
    ) {
        synchronized(lock) {
            if (cache.get(id) != null || !loading.add(id)) return
        }

        executor.execute {
            var bitmap: Bitmap? = null
            try {
                bitmap = decodeFully(assetPath)
                bitmap?.let {
                    synchronized(lock) { cache.put(id, it) }
                    onReady(it)
                }
            } finally {
                synchronized(lock) { loading.remove(id) }
            }
        }
    }

    private fun calculateSample(width: Int, height: Int): Int {
        var sample = 1
        while (width / (sample * 2) >= 512 &&
               height / (sample * 2) >= 512) sample *= 2
        return sample
    }

    fun trimFraction(fraction: Float) {
        synchronized(lock) {
            val target = (cache.maxSize() * fraction).toInt()
            cache.resize(target.coerceAtLeast(1))
        }
    }

    fun clear() = synchronized(lock) { cache.evictAll() }

    override fun onTrimMemory(level: Int) {
        when {
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ->
                trimFraction(0.25f)
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ->
                trimFraction(0.5f)
            level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN ->
                trimFraction(0.75f)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) = Unit
    override fun onLowMemory() = trimFraction(0.25f)

    fun shutdown() {
        executor.shutdownNow()
        clear()
    }
