package com.ff1.android.graphics

import android.graphics.Bitmap
import java.util.LinkedHashMap

/**
 * Main/render-thread owned LRU cache of actual Android Bitmap objects.
 * Publication and frame reads are serialized by the caller's render loop.
 */
class AndroidBitmapCache(
    private var maxBytes: Long
) {
    private val lru = object : LinkedHashMap<Int, Bitmap>(16, 0.75f, true) {}

    @Synchronized
    fun get(id: Int): Bitmap? = lru[id]

    @Synchronized
    fun put(id: Int, bitmap: Bitmap) {
        val old = lru.put(id, bitmap)
        if (old !== bitmap) old?.recycleIfSafe()
        trimToBytesLocked(maxBytes)
    }

    @Synchronized
    fun remove(id: Int): Bitmap? = lru.remove(id)

    @Synchronized
    fun trimToBytes(targetBytes: Long) {
        maxBytes = targetBytes.coerceAtLeast(0L)
        trimToBytesLocked(maxBytes)
    }

    @Synchronized
    fun clear() {
        val values = lru.values.toList()
        lru.clear()
        values.forEach { it.recycleIfSafe() }
    }

    @Synchronized
    fun size(): Int = lru.size

    @Synchronized
    fun bytes(): Long = lru.values.sumOf { it.allocationByteCount.toLong() }

    private fun trimToBytesLocked(target: Long) {
        val it = lru.entries.iterator()
        var total = lru.values.sumOf { bitmap -> bitmap.allocationByteCount.toLong() }
        while (total > target && it.hasNext()) {
            val entry = it.next()
            total -= entry.value.allocationByteCount.toLong()
            it.remove()
            entry.value.recycleIfSafe()
        }
    }

    private fun Bitmap.recycleIfSafe() {
        // Do not force recycle on hardware-backed immutable bitmaps.
        // Bitmap.isRecycled is checked before each render lookup.
        if (!isRecycled && !isMutable && config == Bitmap.Config.HARDWARE) return
        if (!isRecycled) recycle()
    }

    private var retirementQueue: BitmapRetirementQueue? = null
    private var frameManager: RenderFrameManager? = null

    fun attachRenderLifetime(manager: RenderFrameManager, retirement: BitmapRetirementQueue) {
        frameManager = manager
        retirementQueue = retirement
    }

    fun beginFrame(): RenderFrameLease = (frameManager ?: error("RenderFrameManager not attached")).beginFrame()

    fun endFrame(lease: RenderFrameLease) {
        frameManager?.endFrame(lease)
        retirementQueue?.drain(frameManager?.leases() ?: emptyList())
    }

    fun acquireForFrame(id: Int, lease: RenderFrameLease): android.graphics.Bitmap? {
        val bitmap = get(id) ?: return null
        return if (lease.borrow(bitmap)) bitmap else null
    }
}
