#include "canvas_atlas_renderer.h"
namespace ff1 {
void CanvasAtlasRenderer::beginFrame(){debug_.beginFrame();}
void CanvasAtlasRenderer::endFrame(double frameMs){debug_.endFrame(frameMs);}
}
