#pragma once
#include "debug_runtime_bridge.h"
#include <cstddef>
namespace ff1 {
class CanvasAtlasRenderer {
public:
    explicit CanvasAtlasRenderer(DebugRuntimeBridge& debug):debug_(debug){}
    void beginFrame();
    void endFrame(double frameMs);
    template<class Canvas,class Bitmap>
    void drawBitmap(Canvas& canvas,const Bitmap& bitmap,float x,float y){
        canvas.drawBitmap(bitmap,x,y);
        debug_.overlay().recordDrawCall();
    }
    void cacheHit(){debug_.overlay().recordCacheHit();}
    void cacheMiss(){debug_.overlay().recordCacheMiss();}
    void missingTile(){debug_.overlay().recordMissingTile();}
    void setVisibleTiles(size_t v,size_t s){debug_.overlay().setTileCounts(v,s);}
    DebugRuntimeBridge& debug(){return debug_;}
private:
    DebugRuntimeBridge& debug_;
};
}
