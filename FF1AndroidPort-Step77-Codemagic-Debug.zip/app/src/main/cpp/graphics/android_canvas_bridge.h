#pragma once
#include "canvas_atlas_renderer.h"
#include <functional>
namespace ff1 {
class AndroidCanvasBridge {
public:
 using BitmapReady=std::function<bool(int)>;
 void setRenderer(CanvasAtlasRenderer renderer);
 void setCamera(CameraRect camera);
 size_t render(const std::vector<SpriteDraw>& sprites,const BitmapReady&,const std::function<void(const CanvasDrawCommand&)>&);
private: CanvasAtlasRenderer renderer_;
};
}
