#pragma once
#include "canvas_atlas_renderer.h"
#include <algorithm>
#include <vector>
namespace ff1 {
enum class RenderLayer{Map=0,Actor=1,Effect=2,UI=3};
struct LayeredSprite{RenderLayer layer=RenderLayer::Actor;int z=0;SpriteDraw sprite{};};
class RenderBatch{public:void add(LayeredSprite x){items_.push_back(x);}std::vector<SpriteDraw> sortedVisible(const CanvasAtlasRenderer&r)const;private:std::vector<LayeredSprite>items_;};
}
