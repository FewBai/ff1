#pragma once
#include "camera_resource_controller.h"
#include "android_canvas_bridge.h"
#include "frame_resource_pins.h"
#include "render_batch.h"
#include "frame_budget.h"
#include <functional>
namespace ff1{struct FrameStats{size_t requested=0,drawn=0,cacheMisses=0,droppedDraws=0,droppedPrefetch=0;};class GameFramePipeline{public:void setRenderer(CanvasAtlasRenderer);FrameStats renderFrame(CameraRect,int,int,const RenderBatch&,const std::function<bool(int,int)>&,const std::function<void(int)>&,const std::function<void(int)>&,const std::function<void(const CanvasDrawCommand&)>&,FrameBudget={});private:CameraResourceController resources_;AndroidCanvasBridge canvas_;FrameResourcePins pins_;CanvasAtlasRenderer renderer_;};}
