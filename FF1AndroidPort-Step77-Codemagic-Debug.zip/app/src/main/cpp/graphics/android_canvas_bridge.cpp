#include "android_canvas_bridge.h"
#include <utility>
namespace ff1 {
void AndroidCanvasBridge::setRenderer(CanvasAtlasRenderer r){renderer_=std::move(r);}
void AndroidCanvasBridge::setCamera(CameraRect c){renderer_.setCamera(c);}
size_t AndroidCanvasBridge::render(const std::vector<SpriteDraw>&s,const BitmapReady&ready,const std::function<void(const CanvasDrawCommand&)>&draw){
 if(!draw)return 0; auto cmds=renderer_.buildVisible(s); size_t n=0;
 for(const auto&c:cmds){if(ready&&!ready(c.resourceId))continue;draw(c);++n;} return n;
}
}
